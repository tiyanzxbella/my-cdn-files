import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 7700,
    hmr: {
      overlay: false,
      clientPort: 443,
    },
    allowedHosts: [
      "tunnel.nvs.my.id",
    ],
    proxy: {
      "/api": {
	target: "https://api.hsoft.eu.cc/api",
	changeOrigin: true,
	secure: true,
	rewrite: (path) => path.replace(/^\/api/, ""),
      },
    },
  },
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
    dedupe: [
      "react",
      "react-dom",
      "react/jsx-runtime",
      "react/jsx-dev-runtime",
      "@tanstack/react-query",
      "@tanstack/query-core",
    ],
  },
}));
