export interface Anime {
  id: string;
  title: string;
  poster: string;
  cover: string;
  genre: string[];
  status: string;
  year: string;
  synopsis?: string;
  type?: string;
  views?: string;
  time?: string;
  airedStart?: string;
  latestEpisode?: string;
}

export interface Episode {
  id: string;
  number: string;
  title: string;
  isNew: boolean;
  image?: string;
}

export interface Stream {
  quality: string;
  url: string;
  server: string;
}

export interface Genre {
  id: string;
  name: string;
  image: string;
}

export interface Trailer {
  id: string;
  id_movie: string;
  url_youtube: string;
  title: string;
  image_cover: string;
}
