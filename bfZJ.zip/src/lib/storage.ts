import type { Anime } from "@/types/anime";

const HISTORY_KEY = "hsoft:history";
const FAV_KEY = "hsoft:favorites";

export interface HistoryItem {
  episodeId: string;
  animeId: string;
  episodeNumber: string;
  episodeTitle: string;
  animeTitle?: string;
  poster?: string;
  watchedAt: number;
  /** Last playback position in seconds */
  currentTime?: number;
  /** Total duration in seconds, when known */
  duration?: number;
}

function read<T>(key: string): T[] {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T[]) : [];
  } catch {
    return [];
  }
}

function write<T>(key: string, val: T[]) {
  try {
    localStorage.setItem(key, JSON.stringify(val));
    window.dispatchEvent(new CustomEvent(`hsoft:${key}`));
  } catch {
    /* ignore quota */
  }
}

// ---------- History ----------
export function getHistory(): HistoryItem[] {
  return read<HistoryItem>(HISTORY_KEY).sort((a, b) => b.watchedAt - a.watchedAt);
}

export function addHistory(item: Omit<HistoryItem, "watchedAt">) {
  const all = read<HistoryItem>(HISTORY_KEY);
  const prev = all.find((h) => h.episodeId === item.episodeId);
  const list = all.filter((h) => h.episodeId !== item.episodeId);
  list.unshift({
    // preserve previous progress if new item didn't include it
    currentTime: prev?.currentTime,
    duration: prev?.duration,
    ...item,
    watchedAt: Date.now(),
  });
  write(HISTORY_KEY, list.slice(0, 100));
}

/** Lightweight progress update — does not bump watchedAt to top each tick. */
export function updateHistoryProgress(
  episodeId: string,
  currentTime: number,
  duration?: number,
) {
  const list = read<HistoryItem>(HISTORY_KEY);
  const idx = list.findIndex((h) => h.episodeId === episodeId);
  if (idx === -1) return;
  list[idx] = {
    ...list[idx],
    currentTime,
    duration: duration ?? list[idx].duration,
  };
  write(HISTORY_KEY, list);
}

export function getHistoryItem(episodeId: string): HistoryItem | undefined {
  return read<HistoryItem>(HISTORY_KEY).find((h) => h.episodeId === episodeId);
}

export function removeHistory(episodeId: string) {
  write(HISTORY_KEY, read<HistoryItem>(HISTORY_KEY).filter((h) => h.episodeId !== episodeId));
}

export function clearHistory() {
  write(HISTORY_KEY, []);
}

// ---------- Favorites ----------
export type FavoriteItem = Pick<Anime, "id" | "title" | "poster" | "cover" | "year" | "status" | "genre"> & {
  addedAt: number;
};

export function getFavorites(): FavoriteItem[] {
  return read<FavoriteItem>(FAV_KEY).sort((a, b) => b.addedAt - a.addedAt);
}

export function isFavorite(id: string): boolean {
  return read<FavoriteItem>(FAV_KEY).some((f) => f.id === id);
}

export function toggleFavorite(anime: Omit<FavoriteItem, "addedAt">): boolean {
  const list = read<FavoriteItem>(FAV_KEY);
  const exists = list.find((f) => f.id === anime.id);
  if (exists) {
    write(FAV_KEY, list.filter((f) => f.id !== anime.id));
    return false;
  }
  list.unshift({ ...anime, addedAt: Date.now() });
  write(FAV_KEY, list);
  return true;
}

export function removeFavorite(id: string) {
  write(FAV_KEY, read<FavoriteItem>(FAV_KEY).filter((f) => f.id !== id));
}

// ---------- Subscribe (for live UI updates) ----------
export function subscribe(key: "history" | "favorites", cb: () => void): () => void {
  const evt = `hsoft:${key === "history" ? HISTORY_KEY : FAV_KEY}`;
  const handler = () => cb();
  window.addEventListener(evt, handler);
  window.addEventListener("storage", handler);
  return () => {
    window.removeEventListener(evt, handler);
    window.removeEventListener("storage", handler);
  };
}
