const WS_URL = "wss://hsoft-chat-production.up.railway.app";

export const MAX_USERNAME_LENGTH = 20;
export const MAX_MESSAGE_LENGTH = 500;
export const MAX_RECONNECT_ATTEMPTS = 5;
export const BASE_RECONNECT_DELAY = 2000;

export interface ChatMessage {
  id: number;
  username: string;
  message: string;
  timestamp: string;
}

export type ServerEvent =
  | { type: "history"; messages: ChatMessage[] }
  | { type: "new_message"; message: ChatMessage }
  | { type: "system"; message: string }
  | { type: "error"; message: string };

export type ConnectionState = "connecting" | "connected" | "disconnected" | "reconnecting";

export type EventHandler = {
  message: (msg: ChatMessage) => void;
  system: (msg: string) => void;
  error: (err: string) => void;
  connect: () => void;
  disconnect: () => void;
  stateChange: (state: ConnectionState) => void;
};

export function formatTimestamp(timestamp: string): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function isValidMessage(text: string): boolean {
  return text.trim().length > 0 && text.length <= MAX_MESSAGE_LENGTH;
}

export function isValidUsername(name: string): boolean {
  return name.trim().length > 0 && name.length <= MAX_USERNAME_LENGTH;
}

export class LiveChatClient {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private state: ConnectionState = "disconnected";
  private handlers: Partial<EventHandler> = {};

  connect(): void {
    if (this.ws?.readyState === WebSocket.OPEN) return;
    this.setState("connecting");
    try {
      this.ws = new WebSocket(WS_URL);
      this.ws.onopen = this.onOpen.bind(this);
      this.ws.onmessage = this.onMessage.bind(this);
      this.ws.onerror = this.onError.bind(this);
      this.ws.onclose = this.onClose.bind(this);
    } catch (err) {
      this.handleError(`Connection failed: ${err}`);
    }
  }

  send(username: string, message: string): void {
    if (!this.isConnected()) {
      this.handlers.error?.("Not connected");
      return;
    }
    if (!isValidUsername(username)) {
      this.handlers.error?.(`Username must be 1-${MAX_USERNAME_LENGTH} characters`);
      return;
    }
    if (!isValidMessage(message)) {
      this.handlers.error?.(`Message must be 1-${MAX_MESSAGE_LENGTH} characters`);
      return;
    }
    this.ws!.send(
      JSON.stringify({ type: "chat", username: username.trim(), message: message.trim() }),
    );
  }

  requestHistory(): void {
    if (this.isConnected()) {
      this.ws!.send(JSON.stringify({ type: "get_history" }));
    }
  }

  disconnect(): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectAttempts = 0;
    this.ws?.close();
    this.ws = null;
    this.setState("disconnected");
  }

  isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  getState(): ConnectionState {
    return this.state;
  }

  on<K extends keyof EventHandler>(event: K, handler: EventHandler[K]): void {
    this.handlers[event] = handler;
  }

  off<K extends keyof EventHandler>(event: K): void {
    delete this.handlers[event];
  }

  private setState(state: ConnectionState): void {
    this.state = state;
    this.handlers.stateChange?.(state);
  }

  private onOpen(): void {
    this.reconnectAttempts = 0;
    this.setState("connected");
    this.handlers.connect?.();
    this.requestHistory();
  }

  private onMessage(event: MessageEvent): void {
    try {
      const data = JSON.parse(event.data) as ServerEvent;
      switch (data.type) {
        case "history":
          data.messages.forEach((msg) => this.handlers.message?.(msg));
          break;
        case "new_message":
          this.handlers.message?.(data.message);
          break;
        case "system":
          this.handlers.system?.(data.message);
          break;
        case "error":
          this.handleError(data.message);
          break;
      }
    } catch (err) {
      this.handleError(`Parse error: ${err}`);
    }
  }

  private onError(): void {
    this.handleError("WebSocket error");
  }

  private onClose(): void {
    this.handlers.disconnect?.();
    this.attemptReconnect();
  }

  private handleError(message: string): void {
    console.error("[LiveChatClient]", message);
    this.handlers.error?.(message);
  }

  private attemptReconnect(): void {
    if (this.reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
      this.setState("disconnected");
      this.handleError("Max reconnect attempts reached");
      return;
    }
    this.setState("reconnecting");
    const delay = BASE_RECONNECT_DELAY * Math.pow(1.5, this.reconnectAttempts);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectAttempts++;
      this.connect();
    }, delay);
  }
}
