import type { Anime, Episode, Stream, Trailer, Genre } from "@/types/anime";

const BASE_URL = "https://api.hsoft.eu.cc/api";

async function apiFetch<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: "GET",
    credentials: "omit",
    mode: "cors",
    headers: {
      "Content-Type": "application/json",
    },
  });
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  const json = await res.json();
  if (json.error) throw new Error("API returned error");
  return json.data as T;
}

// ---------- Normalizers ----------
type RawAnime = {
  id: string;
  title: string;
  image_poster: string;
  image_cover: string;
  genre?: string;
  status?: string;
  year?: string;
  synopsis?: string;
  type?: string;
  views?: string;
  time?: string;
  aired_start?: string;
  latest_episode?: string;
  episode?: string;
};

export function normalizeAnime(raw: RawAnime): Anime {
  return {
    id: String(raw.id),
    title: raw.title,
    poster: raw.image_poster,
    cover: raw.image_cover,
    genre: raw.genre ? raw.genre.split(",").map((g) => g.trim()).filter(Boolean) : [],
    status: raw.status ?? "",
    year: raw.year ?? "",
    synopsis: raw.synopsis,
    type: raw.type,
    views: raw.views,
    time: raw.time,
    airedStart: raw.aired_start,
    latestEpisode: raw.latest_episode ?? raw.episode,
  };
}

type RawEpisode = {
  id: string;
  index: string;
  title: string;
  is_new: string | number;
  image?: string;
};

export function normalizeEpisode(raw: RawEpisode): Episode {
  return {
    id: String(raw.id),
    number: String(raw.index),
    title: raw.title,
    isNew: String(raw.is_new) === "1",
    image: raw.image,
  };
}

type RawServer = { quality: string; link: string; name: string };
export function normalizeStream(raw: RawServer): Stream {
  return { quality: raw.quality, url: raw.link, server: raw.name };
}

// ---------- Endpoints ----------
export interface HomeData {
  hot: Anime[];
  today: Anime[];
  popular: Anime[];
  waiting: Anime[];
  trailer: Trailer[];
  random: Anime[];
}

export async function getHome(day = "SELASA", limit = 16): Promise<HomeData> {
  const data = await apiFetch<{
    hot: RawAnime[];
    today: RawAnime[];
    popular: RawAnime[];
    waiting: RawAnime[];
    trailer: Trailer[];
    random: RawAnime[];
  }>(`/home/data?day=${day}&limit=${limit}`);
  return {
    hot: (data.hot ?? []).map(normalizeAnime),
    today: (data.today ?? []).map(normalizeAnime),
    popular: (data.popular ?? []).map(normalizeAnime),
    waiting: (data.waiting ?? []).map(normalizeAnime),
    trailer: data.trailer ?? [],
    random: (data.random ?? []).map(normalizeAnime),
  };
}

export async function searchAnime(opts: {
  keyword?: string;
  page?: number;
  genre_in?: string;
  sort?: string;
}): Promise<Anime[]> {
  const params = new URLSearchParams({
    page: String(opts.page ?? 0),
    sort: opts.sort ?? "views",
    keyword: opts.keyword ?? "",
  });
  if (opts.genre_in) params.set("genre_in", opts.genre_in);
  const data = await apiFetch<{ movie: RawAnime[] }>(`/explore/movie?${params.toString()}`);
  return (data.movie ?? []).map(normalizeAnime);
}

export async function getAnimeEpisodes(id: string, page = 0): Promise<Episode[]> {
  const data = await apiFetch<{ episode: RawEpisode[] }>(`/movie/episode/${id}?page=${page}`);
  return (data.episode ?? []).map(normalizeEpisode);
}

export interface AllEpisodesResult {
  episodes: Episode[];
  partial: boolean;
  pagesLoaded: number;
}

export async function getAllAnimeEpisodes(
  id: string,
  opts: { maxPages?: number; onProgress?: (eps: Episode[]) => void } = {},
): Promise<AllEpisodesResult> {
  const maxPages = opts.maxPages ?? 50;
  const all: Episode[] = [];
  let partial = false;
  let page = 0;
  for (; page < maxPages; page++) {
    try {
      const eps = await getAnimeEpisodes(id, page);
      if (!eps.length) break;
      all.push(...eps);
      opts.onProgress?.(all);
    } catch (err) {
      // Network/CORS failure mid-pagination — keep what we have
      partial = true;
      break;
    }
  }
  return { episodes: all, partial, pagesLoaded: page };
}

export async function getAnimeDetail(id: string): Promise<Anime | null> {
  // No dedicated detail endpoint — use search by id-less fallback
  // We rely on episode list for episodes; for header info, try search by id
  // The home/random arrays do contain detail; otherwise fallback to id-only stub.
  try {
    const list = await searchAnime({ keyword: "", page: 0 });
    const found = list.find((a) => a.id === id);
    if (found) return found;
  } catch {
    /* ignore */
  }
  return null;
}

export interface StreamData {
  episode: { id: string; title: string; index: string; id_movie: string };
  episode_next: { id: string } | null;
  servers: Stream[];
}

export async function getStream(episodeId: string): Promise<StreamData> {
  const data = await apiFetch<{
    episode: { id: string; title: string; index: string; id_movie: string };
    episode_next: { id: string } | null;
    server: RawServer[];
  }>(`/episode/streamnew/${episodeId}`);
  return {
    episode: data.episode,
    episode_next: data.episode_next,
    servers: (data.server ?? []).map(normalizeStream),
  };
}

export async function getGenres(): Promise<Genre[]> {
  const data = await apiFetch<{ genre: Genre[] }>(`/explore/genre`);
  return data.genre ?? [];
}

export async function getSchedule(day: string, limit = 32): Promise<Anime[]> {
  const data = await apiFetch<{ movie: RawAnime[] }>(
    `/schedule/data?day=${day.toLowerCase()}&limit=${limit}`,
  );
  return (data.movie ?? []).map(normalizeAnime);
}
