import { BottomNav } from "@/components/BottomNav";
import { HeroCarousel } from "@/components/HeroCarousel";
import { AnimeRow } from "@/components/AnimeRow";
import { useHome } from "@/hooks/useAnimeApi";
import { HeroSkeleton, RowSkeleton } from "@/components/Skeletons";
import { ErrorState } from "@/components/ErrorState";
import { Flame, Calendar, TrendingUp, Film, Clock } from "lucide-react";
import { GenreCarousel } from "@/components/GenreCarousel";

const Home = () => {
  const { data, isLoading, error, refetch } = useHome();

  return (
    <div className="min-h-screen bg-background pb-32">
      {isLoading && <HeroSkeleton />}
      {error && (
        <div className="pt-8">
          <ErrorState onRetry={() => refetch()} />
        </div>
      )}

      {data && data.hot.length > 0 && <HeroCarousel items={data.hot} />}

      <main className="space-y-10 pb-12 pt-8">
        {isLoading && (
          <>
            <RowSkeleton />
            <RowSkeleton />
            <RowSkeleton />
          </>
        )}

        {data && (
          <>
            <AnimeRow
              title="Hot Anime"
              icon={<Flame className="w-6 h-6 text-primary" />}
              items={data.hot}
            />
            <AnimeRow
              title="Today"
              icon={<Calendar className="w-6 h-6 text-primary" />}
              items={data.today}
            />
            <AnimeRow
              title="Popular"
              icon={<TrendingUp className="w-6 h-6 text-primary" />}
              items={data.popular}
            />

            {data.waiting?.length > 0 && (
              <AnimeRow
                title="Awaited"
                icon={<Clock className="w-6 h-6 text-primary" />}
                items={data.waiting}
              />
            )}

            <GenreCarousel />

            {data.trailer.length > 0 && (
              <section className="container space-y-4">
                <h2 className="text-xl md:text-2xl font-bold flex items-center gap-2">
                  <Film className="w-6 h-6 text-primary" />
                  Trailers
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
                  {data.trailer.slice(0, 6).map((t) => {
                    const ytId = extractYouTubeId(t.url_youtube);
                    if (!ytId) return null;
                    return (
                      <div
                        key={t.id}
                        className="flex flex-col rounded-xl overflow-hidden bg-card shadow-card border border-border"
                      >
                        <div className="aspect-video">
                          <iframe
                            className="w-full h-full"
                            src={`https://www.youtube.com/embed/${ytId}`}
                            title={t.title}
                            loading="lazy"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope"
                            allowFullScreen
                          />
                        </div>
                        <div className="p-3">
                          <h3 className="font-semibold line-clamp-1">{t.title}</h3>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}
          </>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

function extractYouTubeId(url: string): string | null {
  const match = url.match(
    /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|v\/))([a-zA-Z0-9_-]{11})/
  );
  return match ? match[1] : null;
}

export default Home;
