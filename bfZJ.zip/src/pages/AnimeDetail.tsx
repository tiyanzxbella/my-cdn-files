import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { BottomNav } from "@/components/BottomNav";
import { useAnime } from "@/hooks/useAnimeApi";
import { EpisodeList } from "@/components/EpisodeList";
import { ErrorState } from "@/components/ErrorState";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { searchAnime, type HomeData } from "@/lib/api";
import { Heart, ArrowLeft } from "lucide-react";
import { getFavorites, getHistory, isFavorite, subscribe, toggleFavorite } from "@/lib/storage";
import type { Anime } from "@/types/anime";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const AnimeDetail = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id = "" } = useParams<{ id: string }>();
  const queryClient = useQueryClient();
  const { data, isLoading, error, refetch } = useAnime(id);
  const episodes = data?.episodes;
  const partial = data?.partial;

  // 1. Meta from navigation state (fastest, fullest)
  const stateAnime = (location.state as { anime?: Anime } | null)?.anime;
  const stateMeta = stateAnime && stateAnime.id === id ? stateAnime : null;

  // 2. Meta from home query cache (hot/today/popular/random)
  const cachedMeta = useMemo<Anime | null>(() => {
    if (stateMeta) return stateMeta;
    const homeQueries = queryClient.getQueriesData<HomeData>({ queryKey: ["home"] });
    for (const [, home] of homeQueries) {
      if (!home) continue;
      const found =
        home.hot.find((a) => a.id === id) ??
        home.today.find((a) => a.id === id) ??
        home.popular.find((a) => a.id === id) ??
        home.random.find((a) => a.id === id);
      if (found) return found;
    }
    // Search caches
    const searchQueries = queryClient.getQueriesData<{ pages: Anime[][] } | Anime[]>({
      queryKey: ["search"],
    });
    for (const [, raw] of searchQueries) {
      if (!raw) continue;
      const lists = Array.isArray(raw) ? [raw] : raw.pages;
      for (const list of lists) {
        const found = list.find((a) => a.id === id);
        if (found) return found;
      }
    }
    // Topbar search cache
    const topbarQueries = queryClient.getQueriesData<Anime[]>({ queryKey: ["topbar-search"] });
    for (const [, list] of topbarQueries) {
      const found = list?.find((a) => a.id === id);
      if (found) return found;
    }
    return null;
  }, [id, stateMeta, queryClient]);

  // 3. Meta from favorites (rich) and history (poster + title only)
  const localMeta = useMemo<Partial<Anime> | null>(() => {
    const fav = getFavorites().find((f) => f.id === id);
    if (fav) {
      return {
        id: fav.id,
        title: fav.title,
        poster: fav.poster,
        cover: fav.cover,
        year: fav.year,
        status: fav.status,
        genre: fav.genre,
      };
    }
    const hist = getHistory().find((h) => h.animeId === id);
    if (hist?.animeTitle) {
      return { id, title: hist.animeTitle, poster: hist.poster ?? "" };
    }
    return null;
  }, [id]);

  // 4. Title hint to drive a targeted keyword search if we still lack data
  const titleHint = cachedMeta?.title ?? localMeta?.title ?? "";

  const { data: searchedMeta } = useQuery({
    queryKey: ["anime-meta-search", id, titleHint],
    queryFn: async () => {
      // Try keyword search using known title — far more likely to find the id
      if (titleHint) {
        const list = await searchAnime({ keyword: titleHint, page: 0 });
        const hit = list.find((a) => a.id === id);
        if (hit) return hit;
      }
      // Last resort: blind page 0 (rarely matches but kept for parity)
      const list = await searchAnime({ keyword: "", page: 0 });
      return list.find((a) => a.id === id) ?? null;
    },
    enabled: !!id && !cachedMeta,
    staleTime: 1000 * 60 * 10,
  });

  // Merge sources: cached/state > searched > local
  const meta: Partial<Anime> | null =
    cachedMeta ?? searchedMeta ?? (localMeta as Partial<Anime> | null);

  const title = meta?.title ?? `Anime #${id}`;
  const cover = meta?.cover;
  const poster = meta?.poster;

  const [fav, setFav] = useState(false);
  useEffect(() => {
    const refresh = () => setFav(isFavorite(id));
    refresh();
    return subscribe("favorites", refresh);
  }, [id]);

  const onFav = () => {
    if (!meta?.title) {
      toast.error("Loading anime info, try again in a moment");
      return;
    }
    const next = toggleFavorite({
      id,
      title: meta.title,
      poster: meta.poster ?? "",
      cover: meta.cover ?? "",
      year: meta.year ?? "",
      status: meta.status ?? "",
      genre: meta.genre ?? [],
    });
    setFav(next);
    toast(next ? "Added to favorites" : "Removed from favorites");
  };

  const metaLoading = !meta;

  return (
    <div className="min-h-screen bg-background pb-32">
      <div className="relative h-[50vh] min-h-[360px] w-full overflow-hidden">
        {cover ? (
          <img
            src={cover}
            alt={title}
            className="absolute inset-0 w-full h-full object-cover"
            onError={(e) => {
              if (poster) (e.currentTarget as HTMLImageElement).src = poster;
            }}
          />
        ) : poster ? (
          <img
            src={poster}
            alt={title}
            className="absolute inset-0 w-full h-full object-cover blur-xl scale-110 opacity-60"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-secondary to-background" />
        )}
        <div className="absolute inset-0 gradient-hero" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/50 to-transparent" />
        <Button
          type="button"
          variant="secondary"
          size="icon"
          onClick={() => navigate(-1)}
          className="absolute top-20 left-4 rounded-full backdrop-blur-md bg-background/60"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
      </div>

      <main className="container -mt-24 md:-mt-40 relative z-10 space-y-8">
        <div className="flex flex-col md:flex-row gap-6">
          {poster ? (
            <img
              src={poster}
              alt={title}
              className="w-40 md:w-56 rounded-xl shadow-card border border-border shrink-0"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = "/placeholder.svg";
              }}
            />
          ) : metaLoading ? (
            <Skeleton className="w-40 md:w-56 aspect-[2/3] rounded-xl shrink-0" />
          ) : null}
          <div className="space-y-3 pt-2 md:pt-12 flex-1 min-w-0">
            {metaLoading ? (
              <>
                <Skeleton className="h-10 w-3/4" />
                <Skeleton className="h-4 w-1/3" />
                <Skeleton className="h-20 w-full max-w-3xl" />
              </>
            ) : (
              <>
                <h1 className="text-3xl md:text-5xl font-bold leading-tight">{title}</h1>
                <div className="flex flex-wrap gap-2 items-center text-sm text-muted-foreground">
                  {meta?.year && <span>{meta.year}</span>}
                  {meta?.status && <span>• {meta.status}</span>}
                  {meta?.type && <span>• {meta.type}</span>}
                </div>
                {meta?.genre && meta.genre.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {meta.genre.map((g) => (
                      <span
                        key={g}
                        className="px-2.5 py-0.5 text-xs rounded-full bg-secondary border border-border"
                      >
                        {g}
                      </span>
                    ))}
                  </div>
                )}
                {meta?.synopsis && (
                  <p className="text-sm md:text-base text-muted-foreground max-w-3xl leading-relaxed">
                    {meta.synopsis}
                  </p>
                )}
              </>
            )}
            <div className="pt-2">
              <Button
                onClick={onFav}
                variant="outline"
                disabled={metaLoading}
                className={cn("gap-2", fav && "border-primary text-primary")}
              >
                <Heart className={cn("w-4 h-4", fav && "fill-current")} />
                {fav ? "Favorited" : "Add to Favorites"}
              </Button>
            </div>
          </div>
        </div>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Episodes</h2>
          {partial && episodes && episodes.length > 0 && (
            <div className="text-xs text-yellow-500/90 bg-yellow-500/10 border border-yellow-500/20 rounded-md px-3 py-2">
              Only partial episodes loaded. Some pages failed to fetch.
            </div>
          )}
          {isLoading && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
              {Array.from({ length: 10 }).map((_, i) => (
                <Skeleton key={i} className="h-20 rounded-lg" />
              ))}
            </div>
          )}
          {error && <ErrorState onRetry={() => refetch()} />}
          {episodes && <EpisodeList episodes={episodes} />}
        </section>
      </main>
      <BottomNav />
    </div>
  );
};

export default AnimeDetail;
