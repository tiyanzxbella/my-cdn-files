import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { BottomNav } from "@/components/BottomNav";
import { ErrorState } from "@/components/ErrorState";
import { Calendar } from "lucide-react";
import { cn } from "@/lib/utils";
import { getSchedule } from "@/lib/api";
import type { Anime } from "@/types/anime";

const DAYS = [
  { id: "MINGGU", short: "Sun" },
  { id: "SENIN", short: "Mon" },
  { id: "SELASA", short: "Tue" },
  { id: "RABU", short: "Wed" },
  { id: "KAMIS", short: "Thu" },
  { id: "JUMAT", short: "Fri" },
  { id: "SABTU", short: "Sat" },
];

const todayIdx = () => new Date().getDay(); // 0 = Sunday

// Build the dates for the current week starting Sunday
function weekDates(): Date[] {
  const today = new Date();
  const sunday = new Date(today);
  sunday.setDate(today.getDate() - today.getDay());
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(sunday);
    d.setDate(sunday.getDate() + i);
    return d;
  });
}

// Try to extract HH:MM from a string like "2026-04-28 21:00:10" or "21:00"
function extractTime(s?: string): string | null {
  if (!s) return null;
  const m = s.match(/(\d{1,2}):(\d{2})/);
  if (!m) return null;
  return `${m[1].padStart(2, "0")}:${m[2]}`;
}

function formatAired(s?: string): string {
  if (!s) return "";
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

const SchedulePage = () => {
  const navigate = useNavigate();
  const [activeIdx, setActiveIdx] = useState<number>(todayIdx());
  const dates = useMemo(weekDates, []);
  const day = DAYS[activeIdx].id;

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["schedule", day],
    queryFn: () => getSchedule(day, 32),
    staleTime: 1000 * 60 * 10,
  });

  // Sort items by extracted time (ascending), unknowns last
  const items = useMemo(() => {
    if (!data) return [];
    return [...data].sort((a, b) => {
      const ta = extractTime(a.time) ?? "99:99";
      const tb = extractTime(b.time) ?? "99:99";
      return ta.localeCompare(tb);
    });
  }, [data]);

  return (
    <div className="min-h-screen bg-background pb-32 pt-24">
      <main className="container space-y-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold flex items-center gap-3">
            <Calendar className="w-8 h-8 text-primary" />
            Schedule
          </h1>
          <p className="text-muted-foreground mt-1">Anime airing this week</p>
        </div>

        {/* Day selector */}
        <div className="flex justify-between gap-1 sm:gap-2 overflow-x-auto scrollbar-hide -mx-1 px-1">
          {DAYS.map((d, i) => {
            const date = dates[i];
            const isActive = i === activeIdx;
            return (
              <button
                key={d.id}
                type="button"
                onClick={() => setActiveIdx(i)}
                aria-pressed={isActive}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 shrink-0 w-14 sm:w-16 py-2 rounded-2xl transition-all",
                  isActive
                    ? "bg-secondary/60 border border-border"
                    : "hover:bg-secondary/40",
                )}
              >
                <span
                  className={cn(
                    "text-[11px] uppercase tracking-wide",
                    isActive ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  {d.short}
                </span>
                <span
                  className={cn(
                    "w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all",
                    isActive
                      ? "gradient-primary text-primary-foreground shadow-glow"
                      : "bg-secondary/60 text-foreground",
                  )}
                >
                  {date.getDate()}
                </span>
              </button>
            );
          })}
        </div>

        {/* Timeline */}
        {isLoading && <TimelineSkeleton />}
        {error && <ErrorState onRetry={() => refetch()} />}

        {!isLoading && !error && items.length === 0 && (
          <p className="text-center text-muted-foreground py-12">
            No anime scheduled.
          </p>
        )}

        {items.length > 0 && (
          <div className="relative pl-8 sm:pl-10">
            {/* vertical line */}
            <div className="absolute left-3 sm:left-4 top-2 bottom-2 w-px bg-border" />

            <ul className="space-y-5">
              {items.map((a) => (
                <TimelineItem
                  key={a.id}
                  anime={a}
                  onClick={() => navigate(`/anime/${a.id}`)}
                />
              ))}
            </ul>
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
};

const TimelineItem = ({
  anime,
  onClick,
}: {
  anime: Anime;
  onClick: () => void;
}) => {
  const time = extractTime(anime.time);
  const isNew = anime.time?.toLowerCase().includes("new");

  return (
    <li className="relative">
      {/* time label */}
      <div className="absolute -left-8 sm:-left-10 top-3 w-7 sm:w-9 text-right">
        <span
          className={cn(
            "text-[10px] sm:text-xs font-semibold tracking-tight",
            isNew ? "text-primary" : "text-muted-foreground",
          )}
        >
          {time ?? (isNew ? "NEW" : "—")}
        </span>
      </div>
      {/* dot */}
      <span
        className={cn(
          "absolute -left-[21px] sm:-left-[25px] top-4 w-3 h-3 rounded-full ring-4 ring-background",
          isNew ? "bg-primary shadow-glow" : "bg-muted-foreground/60",
        )}
      />

      <button
        type="button"
        onClick={onClick}
        className="group w-full flex gap-3 sm:gap-4 p-3 rounded-xl border border-border bg-card text-left transition-all hover:scale-[1.01] hover:shadow-glow hover:border-primary/40"
        style={{
          background:
            "linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--secondary) / 0.5) 100%)",
        }}
      >
        <div className="w-16 sm:w-20 aspect-[2/3] rounded-lg overflow-hidden bg-muted shrink-0">
          <img
            src={anime.poster}
            alt={anime.title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = "/placeholder.svg";
            }}
          />
        </div>

        <div className="min-w-0 flex-1 space-y-1.5">
          <h3 className="text-sm sm:text-base font-bold line-clamp-2 leading-tight">
            {anime.title}
          </h3>

          <div className="flex flex-wrap items-center gap-1.5">
            {anime.latestEpisode && (
              <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-primary/15 text-primary border border-primary/30">
                Latest Episode: {anime.latestEpisode}
              </span>
            )}
            {isNew && !anime.latestEpisode && (
              <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-primary text-primary-foreground">
                NEW
              </span>
            )}
          </div>

          {anime.genre.length > 0 && (
            <p className="text-xs text-muted-foreground line-clamp-1">
              {anime.genre.slice(0, 3).join(" • ")}
            </p>
          )}

          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
            {anime.airedStart && <span>Aired {formatAired(anime.airedStart)}</span>}
            {time && (
              <>
                {anime.airedStart && <span>•</span>}
                <span className={cn(isNew && "text-primary font-semibold")}>
                  {time}
                </span>
              </>
            )}
          </div>
        </div>
      </button>
    </li>
  );
};

const TimelineSkeleton = () => (
  <div className="relative pl-8 sm:pl-10">
    <div className="absolute left-3 sm:left-4 top-2 bottom-2 w-px bg-border" />
    <ul className="space-y-5">
      {Array.from({ length: 6 }).map((_, i) => (
        <li key={i} className="relative">
          <span className="absolute -left-[21px] sm:-left-[25px] top-4 w-3 h-3 rounded-full ring-4 ring-background bg-muted" />
          <div className="flex gap-3 p-3 rounded-xl border border-border bg-card">
            <div className="w-16 sm:w-20 aspect-[2/3] rounded-lg bg-muted animate-pulse" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-2/3 bg-muted rounded animate-pulse" />
              <div className="h-3 w-24 bg-muted rounded animate-pulse" />
              <div className="h-3 w-1/2 bg-muted rounded animate-pulse" />
            </div>
          </div>
        </li>
      ))}
    </ul>
  </div>
);

export default SchedulePage;
