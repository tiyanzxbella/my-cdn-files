import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { BottomNav } from "@/components/BottomNav";
import { useSearch } from "@/hooks/useAnimeApi";
import { AnimeCard } from "@/components/AnimeCard";
import { GridSkeleton } from "@/components/Skeletons";
import { ErrorState } from "@/components/ErrorState";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { GenreSlider } from "@/components/GenreSlider";

const SearchPage = () => {
  const [params, setParams] = useSearchParams();
  const initial = params.get("q") ?? "";
  const initialGenre = params.get("genre") ?? undefined;
  const initialPage = Number(params.get("page") ?? "0") || 0;
  const [input, setInput] = useState(initial);
  const [debounced, setDebounced] = useState(initial);
  const [genre, setGenre] = useState<string | undefined>(initialGenre);
  const [page, setPage] = useState(initialPage);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(input.trim()), 400);
    return () => clearTimeout(t);
  }, [input]);

  // Reset to page 0 whenever the query or genre changes
  useEffect(() => {
    setPage(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced, genre]);

  useEffect(() => {
    const next = new URLSearchParams(params);
    if (debounced) next.set("q", debounced);
    else next.delete("q");
    if (genre) next.set("genre", genre);
    else next.delete("genre");
    if (page > 0) next.set("page", String(page));
    else next.delete("page");
    setParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced, genre, page]);

  const { data, isLoading, isFetching, error, refetch } = useSearch(debounced, genre, page);

  const items = useMemo(() => data ?? [], [data]);
  const hasNext = items.length > 0;

  const goPrev = () => {
    if (page === 0) return;
    setPage((p) => Math.max(0, p - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const goNext = () => {
    if (!hasNext) return;
    setPage((p) => p + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background pb-32">
      <main className="container pt-24 space-y-6">
        <div className="space-y-3">
          <h1 className="text-3xl md:text-4xl font-bold">Search</h1>
          <div className="relative max-w-xl">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Search by anime title..."
              autoFocus
              className="pl-9 h-12 text-base bg-secondary/60"
            />
          </div>
          <GenreSlider value={genre} onChange={setGenre} />
        </div>

        {isLoading && <GridSkeleton />}
        {error && <ErrorState onRetry={() => refetch()} />}

        {!isLoading && items.length === 0 && (debounced || genre) && (
          <p className="text-center text-muted-foreground py-12">
            {debounced ? `No results for "${debounced}"` : "No results"}
          </p>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-5 items-stretch">
          {items.map((a) => (
            <AnimeCard key={a.id} anime={a} layout="grid" />
          ))}
        </div>

        {(items.length > 0 || page > 0) && (
          <div className="flex items-center justify-center gap-3 pt-4">
            <Button
              variant="secondary"
              onClick={goPrev}
              disabled={page === 0 || isFetching}
              className="rounded-full"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </Button>
            <span className="text-sm text-muted-foreground min-w-[80px] text-center">
              {isFetching ? (
                <Loader2 className="w-4 h-4 animate-spin inline" />
              ) : (
                <>Page {page + 1}</>
              )}
            </span>
            <Button
              variant="secondary"
              onClick={goNext}
              disabled={!hasNext || isFetching}
              className="rounded-full"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
};

export default SearchPage;
