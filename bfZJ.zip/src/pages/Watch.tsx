import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { BottomNav } from "@/components/BottomNav";
import { useAnime, useStream } from "@/hooks/useAnimeApi";
import { VideoPlayer } from "@/components/VideoPlayer";
import { ShareBar } from "@/components/ShareBar";
import { LiveChat } from "@/components/LiveChat";
import { EpisodeSlider } from "@/components/EpisodeSlider";
import { ErrorState } from "@/components/ErrorState";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { searchAnime, type HomeData } from "@/lib/api";
import {
  addHistory,
  getFavorites,
  getHistory,
  getHistoryItem,
  updateHistoryProgress,
} from "@/lib/storage";
import type { Anime } from "@/types/anime";

const Watch = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { episodeId = "" } = useParams<{ episodeId: string }>();
  const { data, isLoading, error, refetch } = useStream(episodeId);

  const animeId = data?.episode?.id_movie;

  // 1. Meta from query caches (home + search + topbar)
  const cachedMeta = useMemo<Anime | null>(() => {
    if (!animeId) return null;
    const homeQueries = queryClient.getQueriesData<HomeData>({ queryKey: ["home"] });
    for (const [, home] of homeQueries) {
      if (!home) continue;
      const found =
        home.hot.find((a) => a.id === animeId) ??
        home.today.find((a) => a.id === animeId) ??
        home.popular.find((a) => a.id === animeId) ??
        home.random.find((a) => a.id === animeId);
      if (found) return found;
    }
    const searchQueries = queryClient.getQueriesData<{ pages: Anime[][] } | Anime[]>({
      queryKey: ["search"],
    });
    for (const [, raw] of searchQueries) {
      if (!raw) continue;
      const lists = Array.isArray(raw) ? [raw] : raw.pages;
      for (const list of lists) {
        const found = list.find((a) => a.id === animeId);
        if (found) return found;
      }
    }
    const topbarQueries = queryClient.getQueriesData<Anime[]>({ queryKey: ["topbar-search"] });
    for (const [, list] of topbarQueries) {
      const found = list?.find((a) => a.id === animeId);
      if (found) return found;
    }
    return null;
  }, [animeId, queryClient, data?.episode?.id]);

  // 2. Local meta from favorites/history
  const localMeta = useMemo<Partial<Anime> | null>(() => {
    if (!animeId) return null;
    const fav = getFavorites().find((f) => f.id === animeId);
    if (fav) {
      return {
        id: fav.id,
        title: fav.title,
        poster: fav.poster,
        cover: fav.cover,
        year: fav.year,
        status: fav.status,
        genre: fav.genre,
      };
    }
    const hist = getHistory().find((h) => h.animeId === animeId);
    if (hist?.animeTitle) {
      return { id: animeId, title: hist.animeTitle, poster: hist.poster ?? "" };
    }
    return null;
  }, [animeId]);

  // 3. Targeted keyword search using known title
  const titleHint = cachedMeta?.title ?? localMeta?.title ?? "";
  const { data: searchedMeta } = useQuery({
    queryKey: ["anime-meta-search", animeId, titleHint],
    queryFn: async () => {
      if (titleHint) {
        const list = await searchAnime({ keyword: titleHint, page: 0 });
        const hit = list.find((a) => a.id === animeId);
        if (hit) return hit;
      }
      const list = await searchAnime({ keyword: "", page: 0 });
      return list.find((a) => a.id === animeId) ?? null;
    },
    enabled: !!animeId && !cachedMeta,
    staleTime: 1000 * 60 * 10,
  });

  const meta: Partial<Anime> | null =
    cachedMeta ?? searchedMeta ?? (localMeta as Partial<Anime> | null);

  const { data: animeData } = useAnime(animeId ?? "");
  const episodes = animeData?.episodes ?? [];

  // Read saved playback position once when episode loads
  const [initialTime, setInitialTime] = useState<number | undefined>(undefined);
  useEffect(() => {
    if (!data?.episode?.id) return;
    const prev = getHistoryItem(data.episode.id);
    setInitialTime(prev?.currentTime);
  }, [data?.episode?.id]);

  useEffect(() => {
    if (data?.episode && meta?.title) {
      addHistory({
        episodeId: data.episode.id,
        animeId: data.episode.id_movie,
        episodeNumber: data.episode.index,
        episodeTitle: data.episode.title,
        animeTitle: meta.title,
        poster: meta.poster,
      });
    }
  }, [data?.episode, meta?.title, meta?.poster]);

  // Throttled progress saver
  const handleProgress = useCallback(
    (currentTime: number, duration: number) => {
      const id = data?.episode?.id;
      if (!id) return;
      updateHistoryProgress(id, currentTime, duration);
    },
    [data?.episode?.id],
  );

  return (
    <div className="min-h-screen bg-background pb-32">
      <main className="container pt-24 space-y-6 max-w-6xl">
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => navigate(-1)}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </Button>
          {data?.episode && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => navigate(`/anime/${data.episode.id_movie}`)}
            >
              View anime
            </Button>
          )}
        </div>

        {isLoading && <Skeleton className="aspect-video w-full rounded-xl" />}
        {error && <ErrorState onRetry={() => refetch()} />}

        {data && (
          <>
            <VideoPlayer
              servers={data.servers}
              animeTitle={meta?.title}
              episodeIndex={data.episode.index}
              initialTime={initialTime}
              onProgress={handleProgress}
            />

            {episodes.length > 0 && (
              <EpisodeSlider episodes={episodes} currentEpisodeId={data.episode.id} />
            )}

            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold">
                  Episode {data.episode.index}
                </h1>
                <p className="text-sm text-muted-foreground">{data.episode.title}</p>
                {meta?.title && (
                  <p className="text-sm text-muted-foreground mt-0.5">{meta.title}</p>
                )}
              </div>
              {data.episode_next && (
                <Button
                  type="button"
                  onClick={() => navigate(`/watch/${data.episode_next!.id}`)}
                  className="gradient-primary border-0 gap-2"
                >
                  Next Episode <ChevronRight className="w-4 h-4" />
                </Button>
              )}
            </div>

            <ShareBar
              title={`${meta?.title ?? "Anime"} — Episode ${data.episode.index}`}
              text={data.episode.title}
              favorite={
                meta?.id && meta.title
                  ? {
                      id: meta.id,
                      title: meta.title,
                      poster: meta.poster ?? "",
                      cover: meta.cover ?? "",
                      year: meta.year ?? "",
                      status: meta.status ?? "",
                      genre: meta.genre ?? [],
                    }
                  : null
              }
            />

            <LiveChat />
          </>
        )}
      </main>
      <BottomNav />
    </div>
  );
};

export default Watch;

