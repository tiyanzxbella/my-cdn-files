import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BottomNav } from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { History as HistoryIcon, Play, Trash2, X } from "lucide-react";
import { clearHistory, getHistory, removeHistory, subscribe, type HistoryItem } from "@/lib/storage";

function formatTimestamp(sec: number) {
  if (!isFinite(sec) || sec <= 0) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

const HistoryPage = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<HistoryItem[]>([]);

  useEffect(() => {
    const refresh = () => setItems(getHistory());
    refresh();
    return subscribe("history", refresh);
  }, []);

  return (
    <div className="min-h-screen bg-background pb-32">
      <main className="container pt-24 space-y-6 max-w-5xl">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold flex items-center gap-3">
              <HistoryIcon className="w-8 h-8 text-primary" />
              Watch History
            </h1>
            <p className="text-muted-foreground mt-1">Recently watched episodes</p>
          </div>
          {items.length > 0 && (
            <Button variant="outline" size="sm" onClick={clearHistory} className="gap-2">
              <Trash2 className="w-4 h-4" />
              Clear
            </Button>
          )}
        </div>

        {items.length === 0 ? (
          <div className="py-24 text-center text-muted-foreground">
            <HistoryIcon className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No watch history yet.</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {items.map((it) => (
              <li
                key={it.episodeId}
                className="group flex items-center gap-4 p-3 rounded-xl bg-card border border-border hover:border-primary transition-colors"
              >
                <button
                  type="button"
                  onClick={() => navigate(`/watch/${it.episodeId}`)}
                  className="flex items-center gap-4 flex-1 min-w-0 text-left"
                >
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-lg bg-secondary overflow-hidden shrink-0 flex items-center justify-center">
                    {it.poster ? (
                      <img src={it.poster} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <Play className="w-6 h-6 text-muted-foreground" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold truncate">{it.animeTitle ?? "Anime"}</h3>
                    <p className="text-sm text-muted-foreground truncate">
                      Episode {it.episodeNumber}
                      {typeof it.currentTime === "number" && it.currentTime > 0 && (
                        <> • {formatTimestamp(it.currentTime)}</>
                      )}
                      {it.episodeTitle && it.episodeTitle !== `Episode ${it.episodeNumber}` && (
                        <> — {it.episodeTitle}</>
                      )}
                    </p>
                    {typeof it.currentTime === "number" && it.duration ? (
                      <div className="mt-1.5 h-1 w-full rounded-full bg-secondary overflow-hidden">
                        <div
                          className="h-full bg-primary"
                          style={{
                            width: `${Math.min(100, Math.max(0, (it.currentTime / it.duration) * 100))}%`,
                          }}
                        />
                      </div>
                    ) : null}
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(it.watchedAt).toLocaleString()}
                    </p>
                  </div>
                </button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeHistory(it.episodeId)}
                  aria-label="Remove from history"
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-4 h-4" />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </main>
      <BottomNav />
    </div>
  );
};

export default HistoryPage;
