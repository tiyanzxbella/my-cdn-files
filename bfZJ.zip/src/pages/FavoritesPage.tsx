import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BottomNav } from "@/components/BottomNav";
import { Heart, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getFavorites, removeFavorite, subscribe, type FavoriteItem } from "@/lib/storage";

const FavoritesPage = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    const refresh = () => setItems(getFavorites());
    refresh();
    return subscribe("favorites", refresh);
  }, []);

  return (
    <div className="min-h-screen bg-background pb-32">
      <main className="container pt-24 space-y-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold flex items-center gap-3">
            <Heart className="w-8 h-8 text-primary fill-current" />
            Favorites
          </h1>
          <p className="text-muted-foreground mt-1">Anime you saved</p>
        </div>

        {items.length === 0 ? (
          <div className="py-24 text-center text-muted-foreground">
            <Heart className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No favorites yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-5 items-stretch">
            {items.map((a) => (
              <div key={a.id} className="group relative h-full">
                <button
                  type="button"
                  onClick={() => navigate(`/anime/${a.id}`)}
                  className="flex flex-col w-full h-full text-left rounded-xl overflow-hidden bg-card shadow-card transition-all hover:scale-105 hover:shadow-glow"
                >
                  <div className="relative aspect-[2/3] bg-muted overflow-hidden">
                    {a.poster ? (
                      <img
                        src={a.poster}
                        alt={a.title}
                        loading="lazy"
                        className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    ) : (
                      <div className="absolute inset-0 gradient-primary opacity-30" />
                    )}
                    <div className="absolute inset-0 gradient-card opacity-90 pointer-events-none" />
                    <div className="absolute inset-x-0 bottom-0 p-3">
                      <h3 className="text-sm font-semibold line-clamp-2 min-h-[2.5rem]">{a.title}</h3>
                      {a.year && (
                        <p className="text-xs text-muted-foreground mt-0.5">{a.year}</p>
                      )}
                    </div>
                  </div>
                </button>
                <Button
                  variant="secondary"
                  size="icon"
                  onClick={() => removeFavorite(a.id)}
                  className="absolute top-2 right-2 w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                  aria-label="Remove from favorites"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
};

export default FavoritesPage;
