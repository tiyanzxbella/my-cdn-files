import { useNavigate } from "react-router-dom";
import { BottomNav } from "@/components/BottomNav";
import { useGenres } from "@/hooks/useAnimeApi";
import { GridSkeleton } from "@/components/Skeletons";
import { ErrorState } from "@/components/ErrorState";

const GenrePage = () => {
  const navigate = useNavigate();
  const { data, isLoading, error, refetch } = useGenres();

  return (
    <div className="min-h-screen bg-background pb-32">
      <main className="container pt-24 space-y-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Browse Genres</h1>
          <p className="text-muted-foreground mt-1">Pick a genre to discover new anime</p>
        </div>

        {isLoading && <GridSkeleton count={18} />}
        {error && <ErrorState onRetry={() => refetch()} />}

        {data && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {data.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => navigate(`/search?genre=${g.id}`)}
                className="group relative aspect-[16/9] rounded-xl overflow-hidden bg-card border border-border hover:border-primary hover:shadow-glow transition-all text-left"
              >
                {g.image ? (
                  <img
                    src={g.image}
                    alt={g.name}
                    loading="lazy"
                    className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-70 group-hover:scale-110 transition-all duration-500"
                  />
                ) : (
                  <div className="absolute inset-0 gradient-primary opacity-30" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
                <div className="absolute inset-0 flex items-end p-3">
                  <h3 className="font-bold text-base md:text-lg">{g.name}</h3>
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
};

export default GenrePage;
