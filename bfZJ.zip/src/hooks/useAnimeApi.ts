import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { getAllAnimeEpisodes, getAnimeEpisodes, getGenres, getHome, getStream, searchAnime } from "@/lib/api";

const DAYS = ["MINGGU", "SENIN", "SELASA", "RABU", "KAMIS", "JUMAT", "SABTU"];

export function useHome() {
  const today = DAYS[new Date().getDay()];
  return useQuery({
    queryKey: ["home", today],
    queryFn: () => getHome(today, 16),
    staleTime: 1000 * 60 * 5,
  });
}

export function useSearch(keyword: string, genre?: string, page = 0) {
  return useQuery({
    queryKey: ["search", keyword, genre ?? "", page],
    queryFn: () => searchAnime({ keyword, page, genre_in: genre }),
    placeholderData: keepPreviousData,
    staleTime: 1000 * 60,
  });
}

export function useAnime(id: string) {
  return useQuery({
    queryKey: ["anime", id, "all-episodes"],
    queryFn: async () => {
      const result = await getAllAnimeEpisodes(id);
      if (result.episodes.length === 0 && result.pagesLoaded === 0) {
        // Total failure — fallback to page 0 directly
        try {
          const eps = await getAnimeEpisodes(id, 0);
          return { episodes: eps, partial: true, pagesLoaded: 1 };
        } catch {
          throw new Error("Failed to load episodes");
        }
      }
      return result;
    },
    enabled: !!id,
    staleTime: 1000 * 60 * 5,
  });
}

export function useStream(episodeId: string) {
  return useQuery({
    queryKey: ["stream", episodeId],
    queryFn: () => getStream(episodeId),
    enabled: !!episodeId,
    staleTime: 1000 * 60,
  });
}

export function useGenres() {
  return useQuery({
    queryKey: ["genres"],
    queryFn: getGenres,
    staleTime: 1000 * 60 * 30,
  });
}
