import { Skeleton } from "./ui/skeleton";

export const RowSkeleton = () => (
  <div className="space-y-3">
    <Skeleton className="h-7 w-48 mx-4 sm:mx-6 lg:mx-8" />
    <div className="flex gap-4 overflow-hidden px-4 sm:px-6 lg:px-8">
      {Array.from({ length: 6 }).map((_, i) => (
        <Skeleton key={i} className="w-40 sm:w-44 md:w-48 aspect-[2/3] rounded-xl shrink-0" />
      ))}
    </div>
  </div>
);

export const GridSkeleton = ({ count = 12 }: { count?: number }) => (
  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-5">
    {Array.from({ length: count }).map((_, i) => (
      <Skeleton key={i} className="aspect-[2/3] rounded-xl" />
    ))}
  </div>
);

export const HeroSkeleton = () => (
  <Skeleton className="h-[70vh] min-h-[480px] w-full rounded-none" />
);
