import animein from "@/assets/animein-logo.png";

export const Footer = () => {
  return (
    <footer className="border-t border-border bg-background/60 backdrop-blur-sm mt-12">
      <div className="container py-8 pb-28 flex flex-col items-center gap-4 text-center">
        <a
          href="https://animeinweb.com"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 group"
          aria-label="Visit Animein"
        >
          <img
            src={animein}
            alt="Animein logo"
            width={48}
            height={48}
            loading="lazy"
            className="w-12 h-12 rounded-xl shadow-card transition-transform group-hover:scale-105"
          />
          <div className="text-left">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">
              Source
            </p>
            <p className="text-sm font-semibold group-hover:text-primary transition-colors">
              Thanks to Animein
            </p>
          </div>
        </a>
        <p className="text-xs text-muted-foreground max-w-md">
          All anime data, images, and streams are provided by{" "}
          <a
            href="https://animeinweb.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:underline"
          >
            Animein
          </a>
          . This site is a fan-made client and does not host any content.
        </p>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} · Built with ❤ for anime fans
        </p>
      </div>
    </footer>
  );
};
