import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { AnimeCard } from "./AnimeCard";
import type { Anime } from "@/types/anime";
import { Button } from "./ui/button";

interface AnimeRowProps {
  title: string;
  icon?: React.ReactNode;
  items: Anime[];
}

export const AnimeRow = ({ title, icon, items }: AnimeRowProps) => {
  const ref = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    const el = ref.current;
    if (!el) return;
    const amount = el.clientWidth * 0.85;
    el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  };

  if (!items.length) return null;

  return (
    <section className="space-y-3 group/row">
      <div className="container flex items-center justify-between">
        <h2 className="text-xl md:text-2xl font-bold flex items-center gap-2">
          {icon}
          {title}
        </h2>
        <div className="hidden md:flex gap-1 opacity-0 group-hover/row:opacity-100 transition-opacity">
          <Button size="icon" variant="secondary" onClick={() => scroll("left")}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button size="icon" variant="secondary" onClick={() => scroll("right")}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
      <div
        ref={ref}
        className="flex gap-4 overflow-x-auto scrollbar-hide px-4 sm:px-6 lg:px-8 pb-2 scroll-smooth"
      >
        {items.map((a) => (
          <AnimeCard key={a.id} anime={a} layout="row" />
        ))}
      </div>
    </section>
  );
};
