import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Play } from "lucide-react";
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";
import type { Anime } from "@/types/anime";

interface HeroCarouselProps {
  items: Anime[];
  intervalMs?: number;
}

export const HeroCarousel = ({ items, intervalMs = 4000 }: HeroCarouselProps) => {
  const navigate = useNavigate();
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  const slides = items.slice(0, 6);

  useEffect(() => {
    if (paused || slides.length < 2) return;
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % slides.length);
    }, intervalMs);
    return () => clearInterval(id);
  }, [paused, slides.length, intervalMs]);

  if (!slides.length) return null;

  return (
    <section
      className="relative h-[70vh] min-h-[480px] w-full overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      aria-roledescription="carousel"
    >
      {slides.map((anime, i) => (
        <div
          key={anime.id}
          aria-hidden={i !== index}
          className={cn(
            "absolute inset-0 transition-opacity duration-1000 ease-in-out",
            i === index ? "opacity-100" : "opacity-0 pointer-events-none",
          )}
        >
          <img
            src={anime.cover || anime.poster}
            alt={anime.title}
            className="absolute inset-0 w-full h-full object-cover"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = anime.poster;
            }}
          />
          <div className="absolute inset-0 gradient-hero" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/40 to-transparent" />

          <div className="relative h-full container flex items-end md:items-center pb-24 md:pb-0">
            <div className="max-w-2xl space-y-4">
              <div className="flex flex-wrap gap-2">
                {anime.genre.slice(0, 4).map((g) => (
                  <span
                    key={g}
                    className="px-2.5 py-0.5 text-xs rounded-full bg-secondary/80 backdrop-blur-sm border border-border"
                  >
                    {g}
                  </span>
                ))}
              </div>
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
                {anime.title}
              </h1>
              {anime.synopsis && (
                <p className="text-sm md:text-base text-muted-foreground line-clamp-3 max-w-xl">
                  {anime.synopsis}
                </p>
              )}
              <div className="pt-2">
                <Button
                  size="lg"
                  onClick={() => navigate(`/anime/${anime.id}`, { state: { anime } })}
                  className="gap-2 gradient-primary border-0 shadow-glow hover:opacity-90"
                >
                  <Play className="w-5 h-5 fill-current" />
                  Watch
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}

      {slides.length > 1 && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex gap-2">
          {slides.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={cn(
                "h-1.5 rounded-full transition-all",
                i === index ? "w-8 bg-primary" : "w-1.5 bg-foreground/40 hover:bg-foreground/70",
              )}
            />
          ))}
        </div>
      )}
    </section>
  );
};
