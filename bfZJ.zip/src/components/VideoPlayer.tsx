import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import type { Stream } from "@/types/anime";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Volume1,
  Maximize,
  Minimize,
  SkipForward,
  SkipBack,
  Settings,
  ExternalLink,
  AlertCircle,
  MonitorPlay,
  Home,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

// ─── Proxy ────────────────────────────────────────────────────────────────────
const PROXY_BASE = "https://vprx.yukikiyuctm.workers.dev";
const withProxy = (url: string) => `${PROXY_BASE}/${url}`;

// ─── Types ─────────────────────────────────────────────────────────────────────
interface VideoPlayerProps {
  servers: Stream[];
  animeTitle?: string;
  episodeIndex?: number | string;
  /** Resume position in seconds, applied once when source is ready. */
  initialTime?: number;
  /** Fired periodically while playing (about every 5s). */
  onProgress?: (currentTime: number, duration: number) => void;
}

// ─── Helpers ───────────────────────────────────────────────────────────────────
function formatTime(sec: number) {
  if (!isFinite(sec)) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function VolumeIcon({ volume, muted }: { volume: number; muted: boolean }) {
  if (muted || volume === 0) return <VolumeX className="w-4 h-4" />;
  if (volume < 0.5) return <Volume1 className="w-4 h-4" />;
  return <Volume2 className="w-4 h-4" />;
}

// ─── Component ─────────────────────────────────────────────────────────────────
export const VideoPlayer = ({ servers, animeTitle, episodeIndex, initialTime, onProgress }: VideoPlayerProps) => {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const volumeRef = useRef<HTMLDivElement>(null);
  const resumedRef = useRef(false);
  const lastReportRef = useRef(0);
  const initialTimeRef = useRef(initialTime);
  const onProgressRef = useRef(onProgress);
  useEffect(() => { initialTimeRef.current = initialTime; }, [initialTime]);
  useEffect(() => { onProgressRef.current = onProgress; }, [onProgress]);

  const [activeIdx, setActiveIdx] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverX, setHoverX] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [videoRatio, setVideoRatio] = useState(56.25); // default 16:9 (%)

  const active = servers[activeIdx];

  // ── Source loading ─────────────────────────────────────────────────────────
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !active) return;

    setError(null);
    setLoading(true);
    setPlaying(false);
    setCurrentTime(0);
    setDuration(0);
    resumedRef.current = false;

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    const proxiedUrl = withProxy(active.url);
    const isHls = active.url.includes(".m3u8");

    const handleError = () => {
      if (activeIdx < servers.length - 1) {
        setActiveIdx((i) => i + 1);
      } else {
        setError("All servers failed. Try opening in a new tab.");
        setLoading(false);
      }
    };

    if (isHls && Hls.isSupported()) {
      const hls = new Hls({ enableWorker: true });
      hlsRef.current = hls;
      hls.loadSource(proxiedUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setLoading(false);
        video.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_e, data) => {
        if (data.fatal) handleError();
      });
    } else {
      video.src = proxiedUrl;
      video.onloadeddata = () => {
        setLoading(false);
        video.play().catch(() => {});
      };
      video.onerror = handleError;
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [active, activeIdx, servers.length]);

  // ── Video events ───────────────────────────────────────────────────────────
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onTimeUpdate = () => {
      const t = video.currentTime;
      setCurrentTime(t);
      if (video.buffered.length > 0)
        setBuffered(video.buffered.end(video.buffered.length - 1));
      // Throttle progress reporting to ~5s
      const cb = onProgressRef.current;
      if (cb && video.duration && t - lastReportRef.current >= 5) {
        lastReportRef.current = t;
        cb(t, video.duration);
      }
    };
    const onDurationChange = () => setDuration(video.duration);
    const onVolumeChange = () => { setVolume(video.volume); setMuted(video.muted); };
    const onWaiting = () => setLoading(true);
    const onCanPlay = () => setLoading(false);
    const onLoadedMetadata = () => {
      if (video.videoWidth && video.videoHeight) {
        setVideoRatio((video.videoHeight / video.videoWidth) * 100);
      }
      // Resume to saved position once
      const it = initialTimeRef.current;
      if (!resumedRef.current && it && it > 5 && video.duration && it < video.duration - 10) {
        try {
          video.currentTime = it;
          lastReportRef.current = it;
        } catch { /* ignore */ }
        resumedRef.current = true;
      }
    };

    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("timeupdate", onTimeUpdate);
    video.addEventListener("durationchange", onDurationChange);
    video.addEventListener("volumechange", onVolumeChange);
    video.addEventListener("waiting", onWaiting);
    video.addEventListener("canplay", onCanPlay);
    video.addEventListener("loadedmetadata", onLoadedMetadata);
    return () => {
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("timeupdate", onTimeUpdate);
      video.removeEventListener("durationchange", onDurationChange);
      video.removeEventListener("volumechange", onVolumeChange);
      video.removeEventListener("waiting", onWaiting);
      video.removeEventListener("canplay", onCanPlay);
      video.removeEventListener("loadedmetadata", onLoadedMetadata);
    };
  }, []);

  // ── Fullscreen sync ────────────────────────────────────────────────────────
  useEffect(() => {
    const onChange = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  // ── Keyboard shortcuts ─────────────────────────────────────────────────────
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const video = videoRef.current;
      if (!video || (e.target as HTMLElement).tagName === "INPUT") return;
      switch (e.key) {
        case " ": case "k": e.preventDefault(); video.paused ? video.play() : video.pause(); break;
        case "ArrowRight": e.preventDefault(); video.currentTime = Math.min(video.currentTime + 10, video.duration); break;
        case "ArrowLeft": e.preventDefault(); video.currentTime = Math.max(video.currentTime - 10, 0); break;
        case "ArrowUp": e.preventDefault(); video.volume = Math.min(video.volume + 0.1, 1); break;
        case "ArrowDown": e.preventDefault(); video.volume = Math.max(video.volume - 0.1, 0); break;
        case "m": video.muted = !video.muted; break;
        case "f": toggleFullscreen(); break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  // ── Auto-hide controls ─────────────────────────────────────────────────────
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) setShowControls(false);
    }, 2800);
  }, []);

  // ── Actions ────────────────────────────────────────────────────────────────
  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    v.paused ? v.play() : v.pause();
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (v) v.muted = !v.muted;
  };

  const toggleFullscreen = () => {
    const el = containerRef.current;
    if (!el) return;
    if (!document.fullscreenElement) el.requestFullscreen();
    else document.exitFullscreen();
  };

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const v = videoRef.current;
    const bar = progressRef.current;
    if (!v || !bar || !duration) return;
    const rect = bar.getBoundingClientRect();
    v.currentTime = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)) * duration;
  };

  const handleProgressHover = (e: React.MouseEvent<HTMLDivElement>) => {
    const bar = progressRef.current;
    if (!bar || !duration) return;
    const rect = bar.getBoundingClientRect();
    setHoverTime(Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)) * duration);
    setHoverX(e.clientX - rect.left);
  };

  const handleVolumeClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const v = videoRef.current;
    const bar = volumeRef.current;
    if (!v || !bar) return;
    const rect = bar.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    v.volume = ratio;
    v.muted = ratio === 0;
  };

  const skip = (sec: number) => {
    const v = videoRef.current;
    if (v) v.currentTime = Math.max(0, Math.min(v.currentTime + sec, duration));
  };

  const changeRate = (rate: number) => {
    const v = videoRef.current;
    if (v) v.playbackRate = rate;
    setPlaybackRate(rate);
    setShowSettings(false);
  };

  const openInNewTab = () => {
    if (active?.url) window.open(withProxy(active.url), "_blank", "noopener,noreferrer");
  };

  const progressPct = duration ? (currentTime / duration) * 100 : 0;
  const bufferedPct = duration ? (buffered / duration) * 100 : 0;

  // ── Empty state ────────────────────────────────────────────────────────────
  if (!servers.length) {
    return (
      <div className="relative w-full rounded-2xl bg-[#0a0a0f] border border-white/5 overflow-hidden" style={{ paddingTop: "56.25%" }}>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white/30 space-y-3">
            <MonitorPlay className="w-10 h-10 mx-auto" />
            <p className="text-sm tracking-wider uppercase">No sources available</p>
          </div>
        </div>
      </div>
    );
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-3">
      <style>{`@keyframes marquee { 0% { transform: translateX(0) } 100% { transform: translateX(-50%) } }`}</style>
      {/* Player — rasio aspek mengikuti video asli, seperti YouTube */}
      <div
        ref={containerRef}
        className="relative w-full rounded-2xl overflow-hidden bg-black select-none"
        style={{
          paddingTop: `${videoRatio}%`,
          boxShadow: "0 0 0 1px rgba(255,255,255,0.06), 0 24px 64px rgba(0,0,0,0.7)",
          cursor: showControls ? "default" : "none",
        }}
        onMouseMove={resetHideTimer}
        onMouseLeave={() => {
          if (hideTimer.current) clearTimeout(hideTimer.current);
          if (videoRef.current && !videoRef.current.paused) setShowControls(false);
        }}
        onClick={(e) => {
          if ((e.target as HTMLElement).closest("[data-ctrl]")) return;
          togglePlay();
        }}
      >
        {/* Inner absolute fill — semua konten di dalam sini */}
        <div className="absolute inset-0">
        {/* Video — no controls attribute */}
        <video
          ref={videoRef}
          playsInline
          className="w-full h-full object-contain"
          crossOrigin="anonymous"
        />

        {/* ── Floating top bar ── */}
        <div
          data-ctrl
          className="absolute inset-x-3 top-3 transition-all duration-300 ease-out z-10"
          style={{
            opacity: showControls ? 1 : 0,
            transform: showControls ? "translateY(0)" : "translateY(-6px)",
            pointerEvents: showControls ? "auto" : "none",
          }}
        >
          <div
            className="flex items-center w-full rounded-2xl px-4 py-2.5"
            style={{
              background: "rgba(0,0,0,0.55)",
              backdropFilter: "blur(12px)",
              WebkitBackdropFilter: "blur(12px)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            {/* Kiri: nama website */}
            <span
              className="text-sm font-bold tracking-tight shrink-0"
              style={{ color: "hsl(var(--accent))" }}
            >
              hSoft
            </span>

            {/* Tengah: marquee judul */}
            <div className="flex-1 overflow-hidden mx-4">
              {animeTitle || episodeIndex ? (
                <div className="relative overflow-hidden">
                  <div
                    className="whitespace-nowrap text-xs text-white/60 inline-block"
                    style={{ animation: "marquee 18s linear infinite" }}
                  >
                    {animeTitle && <span className="font-medium text-white/80">{animeTitle}</span>}
                    {animeTitle && episodeIndex && <span className="mx-2 opacity-30">·</span>}
                    {episodeIndex && <span>Episode {episodeIndex}</span>}
                    <span className="mx-8 opacity-0">|</span>
                    {animeTitle && <span className="font-medium text-white/80">{animeTitle}</span>}
                    {animeTitle && episodeIndex && <span className="mx-2 opacity-30">·</span>}
                    {episodeIndex && <span>Episode {episodeIndex}</span>}
                  </div>
                </div>
              ) : (
                <span className="text-xs text-white/25 text-center block">—</span>
              )}
            </div>

            {/* Kanan: home */}
            <button
              onClick={() => navigate("/")}
              className="flex items-center justify-center w-7 h-7 rounded-xl text-white/50 hover:text-white hover:bg-white/10 transition-colors shrink-0"
              title="Home"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ── Center play/pause button ── */}
        {!loading && !error && (
          <div
            className="absolute inset-0 flex items-center justify-center pointer-events-none"
            style={{
              opacity: showControls ? 1 : 0,
              transition: "opacity 0.25s ease",
            }}
          >
            <button
              data-ctrl
              onClick={togglePlay}
              className="pointer-events-auto flex items-center justify-center rounded-full transition-all duration-200 hover:scale-110 active:scale-95"
              style={{
                width: 60,
                height: 60,
                background: "rgba(0,0,0,0.5)",
                backdropFilter: "blur(8px)",
                WebkitBackdropFilter: "blur(8px)",
                border: "1.5px solid rgba(255,255,255,0.18)",
                boxShadow: "0 4px 24px rgba(0,0,0,0.4)",
              }}
            >
              {playing
                ? <Pause className="w-6 h-6 fill-white stroke-none" />
                : <Play className="w-6 h-6 fill-white stroke-none ml-0.5" />}
            </button>
          </div>
        )}

        {/* Gradient vignette */}
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{
            opacity: showControls ? 1 : 0,
            background: "linear-gradient(to top, rgba(0,0,0,0.88) 0%, rgba(0,0,0,0.2) 25%, transparent 55%)",
          }}
        />

        {/* Spinner */}
        {loading && !error && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="relative w-11 h-11">
              <div className="absolute inset-0 rounded-full border-2 border-white/8" />
              <div
                className="absolute inset-0 rounded-full border-2 border-transparent animate-spin"
                style={{ animationDuration: "0.75s", borderTopColor: "hsl(var(--accent))" }}
              />
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black/80 backdrop-blur-sm">
            <AlertCircle className="w-9 h-9 text-red-400/70" />
            <p className="text-sm text-white/50 text-center max-w-xs leading-relaxed">{error}</p>
            <button
              onClick={openInNewTab}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/8 hover:bg-white/14 text-sm text-white/70 transition-colors border border-white/10"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Open in new tab
            </button>
          </div>
        )}

        {/* Controls */}
        <div
          data-ctrl
          className="absolute inset-x-0 bottom-0 transition-all duration-250 ease-out"
          style={{
            opacity: showControls ? 1 : 0,
            transform: showControls ? "translateY(0)" : "translateY(5px)",
            pointerEvents: showControls ? "auto" : "none",
          }}
        >
          {/* Progress */}
          <div className="px-4 pb-2.5">
            <div
              ref={progressRef}
              className="relative cursor-pointer group"
              style={{ height: "3px" }}
              onClick={seek}
              onMouseMove={handleProgressHover}
              onMouseLeave={() => setHoverTime(null)}
            >
              {/* Track bg */}
              <div className="absolute inset-0 rounded-full bg-white/15 group-hover:scale-y-[2.2] origin-bottom transition-transform duration-150" />
              {/* Buffered */}
              <div
                className="absolute top-0 left-0 h-full rounded-full bg-white/22 transition-[width] duration-300 pointer-events-none"
                style={{ width: `${bufferedPct}%` }}
              />
              {/* Played */}
              <div
                className="absolute top-0 left-0 h-full rounded-full pointer-events-none transition-[width] duration-75"
                style={{ width: `${progressPct}%`, backgroundColor: "hsl(var(--accent))" }}
              />
              {/* Thumb */}
              <div
                className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-lg pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity -ml-1.5"
                style={{ left: `${progressPct}%` }}
              />
              {/* Time tooltip */}
              {hoverTime !== null && (
                <div
                  className="absolute -top-7 -translate-x-1/2 px-1.5 py-0.5 rounded text-[11px] text-white bg-black/75 backdrop-blur-sm pointer-events-none whitespace-nowrap"
                  style={{ left: hoverX }}
                >
                  {formatTime(hoverTime)}
                </div>
              )}
            </div>
          </div>

          {/* Buttons row */}
          <div className="flex items-center gap-1 px-3 pb-3">
            {/* Play/Pause */}
            <button
              onClick={togglePlay}
              className="flex items-center justify-center w-8 h-8 rounded-lg text-white hover:bg-white/10 transition-colors"
            >
              {playing
                ? <Pause className="w-[15px] h-[15px] fill-white stroke-none" />
                : <Play className="w-[15px] h-[15px] fill-white stroke-none ml-0.5" />}
            </button>

            {/* Skip -10 */}
            <button
              onClick={() => skip(-10)}
              className="flex items-center justify-center w-8 h-8 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              title="-10s"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            {/* Skip +10 */}
            <button
              onClick={() => skip(10)}
              className="flex items-center justify-center w-8 h-8 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              title="+10s"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            {/* Volume */}
            <div className="flex items-center gap-1 group/vol">
              <button
                onClick={toggleMute}
                className="flex items-center justify-center w-8 h-8 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              >
                <VolumeIcon volume={volume} muted={muted} />
              </button>
              <div
                ref={volumeRef}
                className="w-0 overflow-hidden group-hover/vol:w-[60px] transition-[width] duration-200 ease-out cursor-pointer py-2"
                onClick={handleVolumeClick}
              >
                <div className="relative h-[3px] w-[60px] rounded-full bg-white/20">
                  <div
                    className="absolute top-0 left-0 h-full rounded-full bg-white/90 transition-[width] duration-75"
                    style={{ width: `${muted ? 0 : volume * 100}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Time */}
            <span className="text-[12px] text-white/45 tabular-nums ml-1.5 leading-none">
              {formatTime(currentTime)}
              <span className="mx-1 opacity-50">/</span>
              {formatTime(duration)}
            </span>

            <div className="flex-1" />

            {/* Settings */}
            <div className="relative">
              <button
                onClick={() => setShowSettings((s) => !s)}
                className="flex items-center justify-center w-8 h-8 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
                title="Playback speed"
              >
                <Settings
                  className="w-4 h-4 transition-transform duration-200"
                  style={{ transform: showSettings ? "rotate(60deg)" : "none" }}
                />
              </button>
              {showSettings && (
                <div className="absolute bottom-10 right-0 z-50 bg-[#0f0f18]/95 backdrop-blur-md border border-white/10 rounded-xl overflow-hidden shadow-2xl min-w-[136px]">
                  <div className="px-3 py-2 text-[10px] text-white/25 uppercase tracking-widest border-b border-white/5">
                    Speed
                  </div>
                  {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 2].map((r) => (
                    <button
                      key={r}
                      onClick={() => changeRate(r)}
                      className={`w-full text-left px-3 py-1.5 text-[13px] transition-colors ${
                        playbackRate === r
                          ? "bg-white/5"
                          : "text-white/60 hover:text-white hover:bg-white/5"
                      }`}
                      style={playbackRate === r ? { color: "hsl(var(--accent))" } : {}}
                    >
                      {r === 1 ? "Normal" : `${r}×`}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* New tab */}
            <button
              onClick={openInNewTab}
              className="flex items-center justify-center w-8 h-8 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              title="Open in new tab"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </button>

            {/* Fullscreen */}
            <button
              onClick={toggleFullscreen}
              className="flex items-center justify-center w-8 h-8 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              title={fullscreen ? "Exit fullscreen" : "Fullscreen"}
            >
              {fullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>
        </div>
        {/* end inner absolute */}
      </div>

      {/* Server selector */}
      <div className="flex flex-wrap gap-2 items-center">
        <span className="text-[11px] text-white/25 uppercase tracking-widest mr-1">Source</span>
        {servers.map((s, idx) => (
          <button
            key={`${s.server}-${idx}`}
            onClick={() => setActiveIdx(idx)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 ${
              idx === activeIdx
                ? "text-white shadow-md"
                : "bg-white/5 text-white/45 hover:bg-white/10 hover:text-white/75 border border-white/6"
            }`}
            style={idx === activeIdx ? { backgroundColor: "hsl(var(--accent))", boxShadow: "0 2px 12px hsl(var(--accent) / 0.35)" } : {}}
          >
            {s.server}
            {s.quality && (
              <span className={`ml-1.5 text-[10px] ${idx === activeIdx ? "opacity-65" : "opacity-45"}`}>
                {s.quality}
              </span>
            )}
          </button>
        ))}
	{/*
        <button
          onClick={openInNewTab}
          className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] text-white/35 hover:text-white/60 bg-white/4 hover:bg-white/8 border border-white/6 transition-all duration-150"
        >
          <ExternalLink className="w-3 h-3" />
          New tab
        </button>
	*/}
      </div>
    </div>
  );
};

