import { forwardRef, memo } from "react";
import { useNavigate } from "react-router-dom";
import type { Anime } from "@/types/anime";
import { Play, Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface AnimeCardProps {
  anime: Anime;
  size?: "sm" | "md" | "lg";
  /** "row" = fixed width for horizontal carousels. "grid" = full width to fit parent grid cell. */
  layout?: "row" | "grid";
}

const AnimeCardInner = forwardRef<HTMLButtonElement, AnimeCardProps>(
  ({ anime, size = "md", layout = "row" }, ref) => {
    const navigate = useNavigate();
    const widths = {
      sm: "w-32 sm:w-36",
      md: "w-40 sm:w-44 md:w-48",
      lg: "w-48 sm:w-56 md:w-64",
    };
    return (
      <button
        ref={ref}
        type="button"
        onClick={() => navigate(`/anime/${anime.id}`, { state: { anime } })}
        aria-label={anime.title}
        className={cn(
          "group relative flex flex-col overflow-hidden rounded-xl bg-card shadow-card transition-all duration-300 hover:scale-105 hover:shadow-glow hover:z-10 text-left h-full",
          layout === "row" ? cn("shrink-0", widths[size]) : "w-full",
        )}
      >
        <div className="relative aspect-[2/3] overflow-hidden bg-muted shrink-0">
          <img
            src={anime.poster}
            alt={anime.title}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = "/placeholder.svg";
            }}
          />
          <div className="absolute inset-0 gradient-card opacity-90 pointer-events-none" />
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center shadow-glow">
              <Play className="w-4 h-4 text-primary-foreground fill-current" />
            </div>
          </div>
          {anime.views && Number(anime.views) > 100000 && (
            <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-md bg-background/70 backdrop-blur-sm text-xs">
              <Star className="w-3 h-3 fill-primary text-primary" />
              <span className="font-medium">Hot</span>
            </div>
          )}
          <div className="absolute inset-x-0 bottom-0 p-3 space-y-1">
            <h3 className="text-sm font-semibold line-clamp-2 text-foreground min-h-[2.5rem]">
              {anime.title}
            </h3>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {anime.year && <span>{anime.year}</span>}
              {anime.status && (
                <>
                  <span>•</span>
                  <span className="uppercase truncate">{anime.status}</span>
                </>
              )}
            </div>
          </div>
        </div>
      </button>
    );
  },
);
AnimeCardInner.displayName = "AnimeCard";

export const AnimeCard = memo(AnimeCardInner);
