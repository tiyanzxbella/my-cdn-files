import { useState } from "react";
import { Button } from "./ui/button";
import { Share2, Copy, Check, Heart } from "lucide-react";
import { toast } from "sonner";
import { isFavorite, toggleFavorite, type FavoriteItem } from "@/lib/storage";
import { cn } from "@/lib/utils";

interface ShareBarProps {
  title: string;
  text?: string;
  favorite?: Omit<FavoriteItem, "addedAt"> | null;
}

export const ShareBar = ({ title, text, favorite }: ShareBarProps) => {
  const [copied, setCopied] = useState(false);
  const [fav, setFav] = useState<boolean>(favorite ? isFavorite(favorite.id) : false);

  const handleShare = async () => {
    const shareUrl = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title, text, url: shareUrl });
      } catch {
        /* user dismissed */
      }
    } else {
      handleCopy();
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      toast.success("Link copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy link");
    }
  };

  const handleFavorite = () => {
    if (!favorite) return;
    const next = toggleFavorite(favorite);
    setFav(next);
    toast(next ? "Added to favorites" : "Removed from favorites");
  };

  return (
    <div className="flex flex-wrap gap-2 p-4 rounded-xl bg-card border border-border">
      <Button onClick={handleShare} className="gap-2 gradient-primary border-0">
        <Share2 className="w-4 h-4" />
        Share
      </Button>
      <Button onClick={handleCopy} variant="secondary" className="gap-2">
        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        {copied ? "Copied" : "Copy Link"}
      </Button>
      {favorite && (
        <Button
          onClick={handleFavorite}
          variant="outline"
          className={cn("gap-2 ml-auto", fav && "border-primary text-primary")}
        >
          <Heart className={cn("w-4 h-4", fav && "fill-current")} />
          {fav ? "Favorited" : "Favorite"}
        </Button>
      )}
    </div>
  );
};
