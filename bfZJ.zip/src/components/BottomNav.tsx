import { NavLink } from "react-router-dom";
import { Home, Search, History, Heart, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "Home", icon: Home, end: true },
  { to: "/search", label: "Search", icon: Search },
  { to: "/history", label: "History", icon: History },
  { to: "/favorites", label: "Favorites", icon: Heart },
  { to: "/schedule", label: "Schedule", icon: Calendar },
];

export const BottomNav = () => {
  return (
    <nav
      aria-label="Primary"
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 px-2 py-2 rounded-full bg-background/70 backdrop-blur-xl border border-border shadow-glow"
    >
      <ul className="flex items-center gap-1">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <li key={item.to}>
              <NavLink
                to={item.to}
                end={item.end}
                aria-label={item.label}
                title={item.label}
                className={({ isActive }) =>
                  cn(
                    "flex flex-col items-center justify-center gap-0.5 rounded-full px-3 sm:px-4 py-2 text-[10px] sm:text-xs font-medium transition-all",
                    isActive
                      ? "bg-primary text-primary-foreground shadow-glow"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary/60",
                  )
                }
              >
                <Icon className="w-5 h-5" />
                <span className="hidden sm:inline">{item.label}</span>
              </NavLink>
            </li>
          );
        })}
      </ul>
    </nav>
  );
};
