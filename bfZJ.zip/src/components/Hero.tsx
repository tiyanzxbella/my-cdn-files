import { useNavigate } from "react-router-dom";
import { Play } from "lucide-react";
import type { Anime } from "@/types/anime";
import { Button } from "./ui/button";

interface HeroProps {
  anime: Anime;
}

export const Hero = ({ anime }: HeroProps) => {
  const navigate = useNavigate();
  return (
    <section className="relative h-[70vh] min-h-[480px] w-full overflow-hidden">
      <img
        src={anime.cover || anime.poster}
        alt={anime.title}
        className="absolute inset-0 w-full h-full object-cover"
        onError={(e) => {
          (e.currentTarget as HTMLImageElement).src = anime.poster;
        }}
      />
      <div className="absolute inset-0 gradient-hero" />
      <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/40 to-transparent" />

      <div className="relative h-full container flex items-end md:items-center pb-16 md:pb-0">
        <div className="max-w-2xl space-y-4">
          <div className="flex flex-wrap gap-2">
            {anime.genre.slice(0, 4).map((g) => (
              <span
                key={g}
                className="px-2.5 py-0.5 text-xs rounded-full bg-secondary/80 backdrop-blur-sm border border-border"
              >
                {g}
              </span>
            ))}
          </div>
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
            {anime.title}
          </h1>
          {anime.synopsis && (
            <p className="text-sm md:text-base text-muted-foreground line-clamp-3 max-w-xl">
              {anime.synopsis}
            </p>
          )}
          <div className="flex gap-3 pt-2">
            <Button
              size="lg"
              onClick={() => navigate(`/anime/${anime.id}`)}
              className="gap-2 gradient-primary border-0 shadow-glow hover:opacity-90"
            >
              <Play className="w-5 h-5 fill-current" />
              Watch Now
            </Button>
            <Button
              size="lg"
              variant="secondary"
              onClick={() => navigate(`/anime/${anime.id}`)}
            >
              More Info
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
