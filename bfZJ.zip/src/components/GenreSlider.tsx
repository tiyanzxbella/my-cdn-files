import { useGenres } from "@/hooks/useAnimeApi";
import { cn } from "@/lib/utils";
import { Skeleton } from "./ui/skeleton";

interface GenreSliderProps {
  value?: string;
  onChange: (genreId: string | undefined) => void;
}

export const GenreSlider = ({ value, onChange }: GenreSliderProps) => {
  const { data: genres, isLoading } = useGenres();

  if (isLoading) {
    return (
      <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-4 px-4 snap-x">
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="h-9 w-24 rounded-full shrink-0" />
        ))}
      </div>
    );
  }

  if (!genres?.length) return null;

  const selected = new Set((value ?? "").split(",").map((s) => s.trim()).filter(Boolean));

  return (
    <div
      className="flex gap-2 overflow-x-auto scrollbar-hide -mx-4 px-4 snap-x scroll-smooth pb-1"
      role="tablist"
      aria-label="Filter by genre"
    >
      <button
        type="button"
        role="tab"
        aria-selected={selected.size === 0}
        onClick={() => onChange(undefined)}
        className={cn(
          "shrink-0 snap-start px-4 h-9 rounded-full text-sm font-medium border transition-all",
          selected.size === 0
            ? "gradient-primary border-transparent text-primary-foreground shadow-glow"
            : "bg-secondary/60 border-border hover:bg-secondary hover:border-primary/40",
        )}
      >
        All
      </button>
      {genres.map((g) => {
        const active = selected.has(g.id);
        return (
          <button
            key={g.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(active ? undefined : g.id)}
            className={cn(
              "shrink-0 snap-start px-4 h-9 rounded-full text-sm font-medium border transition-all whitespace-nowrap",
              active
                ? "gradient-primary border-transparent text-primary-foreground shadow-glow"
                : "bg-secondary/60 border-border hover:bg-secondary hover:border-primary/40",
            )}
          >
            {g.name}
          </button>
        );
      })}
    </div>
  );
};
