import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { Episode } from "@/types/anime";
import { ArrowDownAZ, ArrowUpAZ, Play, Search } from "lucide-react";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

interface EpisodeListProps {
  episodes: Episode[];
}

export const EpisodeList = ({ episodes }: EpisodeListProps) => {
  const navigate = useNavigate();
  const [desc, setDesc] = useState(true);
  const [jump, setJump] = useState("");

  const filtered = useMemo(() => {
    const sorted = [...episodes].sort((a, b) => {
      const an = parseInt(a.number, 10) || 0;
      const bn = parseInt(b.number, 10) || 0;
      return desc ? bn - an : an - bn;
    });
    if (!jump.trim()) return sorted;
    const q = jump.trim().toLowerCase();
    return sorted.filter(
      (ep) => ep.number.toLowerCase().includes(q) || ep.title.toLowerCase().includes(q),
    );
  }, [episodes, desc, jump]);

  if (!episodes.length) {
    return <p className="text-muted-foreground text-sm">No episodes available.</p>;
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between">
        <div className="text-sm text-muted-foreground">
          {episodes.length} episode{episodes.length > 1 ? "s" : ""}
        </div>
        <div className="flex gap-2 items-center">
          <div className="relative flex-1 sm:w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={jump}
              onChange={(e) => setJump(e.target.value)}
              placeholder="Jump to episode…"
              className="pl-8 h-9"
              inputMode="numeric"
            />
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setDesc((d) => !d)}
            className="shrink-0"
          >
            {desc ? <ArrowDownAZ className="w-4 h-4" /> : <ArrowUpAZ className="w-4 h-4" />}
            <span className="hidden sm:inline">{desc ? "Latest" : "Oldest"}</span>
          </Button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm">No episodes match "{jump}".</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4 items-stretch">
          {filtered.map((ep) => (
            <button
              key={ep.id}
              type="button"
              onClick={() => navigate(`/watch/${ep.id}`)}
              aria-label={`Play episode ${ep.number}`}
              className="group relative text-left rounded-lg bg-card hover:bg-secondary border border-border p-4 transition-all hover:border-primary hover:shadow-glow"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="space-y-0.5 min-w-0">
                  <div className="text-xs text-muted-foreground">Episode</div>
                  <div className="text-lg font-bold truncate">{ep.number}</div>
                </div>
                <div className="w-9 h-9 rounded-full bg-secondary group-hover:gradient-primary flex items-center justify-center transition-all shrink-0">
                  <Play className="w-4 h-4 fill-current" />
                </div>
              </div>
              {ep.isNew && (
                <Badge className="absolute top-2 right-2 gradient-primary border-0 text-[10px] px-1.5 py-0">
                  NEW
                </Badge>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
