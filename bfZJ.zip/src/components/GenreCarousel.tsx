import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, Tags } from "lucide-react";
import { useGenres } from "@/hooks/useAnimeApi";
import { Button } from "./ui/button";
import { Skeleton } from "./ui/skeleton";

export const GenreCarousel = () => {
  const { data: genres, isLoading } = useGenres();
  const navigate = useNavigate();
  const ref = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    const el = ref.current;
    if (!el) return;
    const amount = el.clientWidth * 0.85;
    el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  };

  if (!isLoading && !genres?.length) return null;

  return (
    <section className="space-y-3 group/row">
      <div className="container flex items-center justify-between">
        <h2 className="text-xl md:text-2xl font-bold flex items-center gap-2">
          <Tags className="w-6 h-6 text-primary" />
          Browse by Genre
        </h2>
        <div className="hidden md:flex gap-1 opacity-0 group-hover/row:opacity-100 transition-opacity">
          <Button size="icon" variant="secondary" onClick={() => scroll("left")}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button size="icon" variant="secondary" onClick={() => scroll("right")}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
      <div
        ref={ref}
        className="flex gap-4 overflow-x-auto scrollbar-hide px-4 sm:px-6 lg:px-8 pb-2 scroll-smooth snap-x"
      >
        {isLoading &&
          Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="shrink-0 w-40 h-24 rounded-xl" />
          ))}

        {genres?.map((g) => (
          <button
            key={g.id}
            type="button"
            onClick={() => navigate(`/search?genre=${g.id}`)}
            className="group/card relative shrink-0 snap-start w-40 h-24 rounded-xl overflow-hidden border border-border bg-card text-left transition-transform hover:scale-[1.03] hover:border-primary/60"
          >
            {g.image ? (
              <img
                src={g.image}
                alt=""
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover/card:opacity-90 transition-opacity"
              />
            ) : null}
            <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/40 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-3">
              <span className="text-sm font-semibold line-clamp-2">{g.name}</span>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
};
