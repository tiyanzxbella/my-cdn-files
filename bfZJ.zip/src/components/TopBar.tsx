import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { searchAnime } from "@/lib/api";
import { cn } from "@/lib/utils";

export const TopBar = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // debounce
  useEffect(() => {
    const t = setTimeout(() => setDebounced(query.trim()), 350);
    return () => clearTimeout(t);
  }, [query]);

  // outside click + esc
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!wrapperRef.current?.contains(e.target as Node)) closeSearch();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeSearch();
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const closeSearch = () => {
    setOpen(false);
    setQuery("");
    setDebounced("");
  };

  const openSearch = () => {
    setOpen(true);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  const { data, isFetching } = useQuery({
    queryKey: ["topbar-search", debounced],
    queryFn: () => searchAnime({ keyword: debounced, page: 0 }),
    enabled: debounced.length > 1,
    staleTime: 1000 * 60,
  });

  const results = data ?? [];

  const goTo = (id: string, anime?: (typeof results)[number]) => {
    closeSearch();
    navigate(`/anime/${id}`, anime ? { state: { anime } } : undefined);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && results[0]) {
      goTo(results[0].id, results[0]);
    }
  };

  return (
    <div
      ref={wrapperRef}
      className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[min(640px,calc(100%-1.5rem))]"
    >
      <div
        className={cn(
          "flex items-center gap-2 rounded-full border border-border bg-background/70 backdrop-blur-xl shadow-card transition-all",
          open ? "px-3 py-2" : "px-4 py-2",
        )}
      >
        <button
          type="button"
          onClick={() => navigate("/")}
          className="text-base font-bold tracking-tight pr-2"
          aria-label="hSoft Home"
        >
          h<span className="text-gradient">Soft</span>
        </button>

        <div className="flex-1" />

        {open ? (
          <>
            <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder="Search anime…"
              className="flex-1 min-w-0 bg-transparent outline-none text-sm placeholder:text-muted-foreground"
              aria-label="Search anime"
            />
            {isFetching && (
              <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
            )}
            <button
              type="button"
              onClick={closeSearch}
              aria-label="Close search"
              className="p-1 rounded-full text-muted-foreground hover:text-foreground hover:bg-secondary/60"
            >
              <X className="w-4 h-4" />
            </button>
          </>
        ) : (
          <button
            type="button"
            onClick={openSearch}
            aria-label="Open search"
            className="p-2 rounded-full text-muted-foreground hover:text-foreground hover:bg-secondary/60"
          >
            <Search className="w-4 h-4" />
          </button>
        )}
      </div>

      {open && debounced.length > 1 && (
        <div className="mt-2 rounded-2xl border border-border bg-background/90 backdrop-blur-xl shadow-card overflow-hidden animate-fade-in">
          <div className="max-h-[60vh] overflow-y-auto">
            {results.length === 0 && !isFetching && (
              <div className="px-4 py-6 text-center text-sm text-muted-foreground">
                No results for "{debounced}"
              </div>
            )}
            {results.slice(0, 12).map((a) => (
              <button
                key={a.id}
                type="button"
                onClick={() => goTo(a.id, a)}
                className="w-full flex items-center gap-3 px-3 py-2 text-left hover:bg-secondary/60 transition-colors"
              >
                <img
                  src={a.poster}
                  alt={a.title}
                  loading="lazy"
                  className="w-10 h-14 rounded-md object-cover bg-muted shrink-0"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = "/placeholder.svg";
                  }}
                />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium line-clamp-1">{a.title}</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">
                    {a.genre.slice(0, 3).join(", ") || a.status}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
