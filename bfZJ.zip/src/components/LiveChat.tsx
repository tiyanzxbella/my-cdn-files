import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { Send, MessageCircle, Wifi, WifiOff, Loader2, AlertTriangle } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { cn } from "@/lib/utils";
import {
  LiveChatClient,
  MAX_MESSAGE_LENGTH,
  MAX_USERNAME_LENGTH,
  formatTimestamp,
  type ChatMessage,
  type ConnectionState,
} from "@/lib/liveChat";

const USERNAME_KEY = "hsoft:chat:username";

export const LiveChat = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [state, setState] = useState<ConnectionState>("disconnected");
  const [error, setError] = useState<string | null>(null);
  const [username, setUsername] = useState<string>(
    () => (typeof window !== "undefined" && localStorage.getItem(USERNAME_KEY)) || "",
  );
  const [draft, setDraft] = useState("");
  const clientRef = useRef<LiveChatClient | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const seenIds = useRef<Set<number>>(new Set());

  useEffect(() => {
    const client = new LiveChatClient();
    clientRef.current = client;

    client.on("stateChange", (s) => setState(s));
    client.on("message", (msg) => {
      setMessages((prev) => {
        if (seenIds.current.has(msg.id)) return prev;
        seenIds.current.add(msg.id);
        return [...prev, msg];
      });
    });
    client.on("error", (err) => setError(err));
    client.on("connect", () => setError(null));

    client.connect();

    return () => {
      client.disconnect();
      clientRef.current = null;
    };
  }, []);

  // Auto-scroll on new messages
  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages]);

  const handleSend = () => {
    const u = username.trim();
    const m = draft.trim();
    if (!u) {
      setError("Username required");
      return;
    }
    if (!m) {
      setError("Message required");
      return;
    }
    localStorage.setItem(USERNAME_KEY, u);
    clientRef.current?.send(u, m);
    setDraft("");
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const statusMeta = useMemo(() => {
    switch (state) {
      case "connected":
        return { label: "Connected", icon: Wifi, className: "text-emerald-400" };
      case "connecting":
        return { label: "Connecting…", icon: Loader2, className: "text-amber-400 animate-spin" };
      case "reconnecting":
        return { label: "Reconnecting…", icon: Loader2, className: "text-amber-400 animate-spin" };
      default:
        return { label: "Disconnected", icon: WifiOff, className: "text-destructive" };
    }
  }, [state]);

  const StatusIcon = statusMeta.icon;
  const isConnected = state === "connected";

  return (
    <section className="flex flex-col rounded-xl bg-card border border-border overflow-hidden h-[32rem] max-h-[70vh] w-full min-w-0">
      <header className="flex items-center justify-between gap-2 px-4 py-3 border-b border-border bg-background/40 shrink-0">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold">Live Chat</h2>
          <span className="text-xs text-muted-foreground">({messages.length})</span>
        </div>
        <div className={cn("flex items-center gap-1.5 text-xs font-medium", statusMeta.className)}>
          <StatusIcon className={cn("w-3.5 h-3.5", state !== "connecting" && state !== "reconnecting" && "animate-none")} />
          <span>{statusMeta.label}</span>
        </div>
      </header>

      {state === "disconnected" && (
        <div className="flex items-start gap-2 px-4 py-2 bg-destructive/10 border-b border-destructive/30 text-xs text-destructive">
          <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          <span>Disconnected from chat server. Trying to reconnect…</span>
        </div>
      )}

      <div
        ref={listRef}
        className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-4 py-3 space-y-3 bg-background/20"
      >
        {messages.length === 0 ? (
          <div className="h-full flex items-center justify-center text-xs text-muted-foreground py-12">
            No messages yet. Be the first to say hi!
          </div>
        ) : (
          messages.map((msg) => (
            <div key={msg.id} className="flex flex-col gap-0.5">
              <div className="flex items-baseline gap-2">
                <span className="text-sm font-semibold text-primary truncate max-w-[10rem]">
                  {msg.username}
                </span>
                <span className="text-[10px] text-muted-foreground tabular-nums">
                  {formatTimestamp(msg.timestamp)}
                </span>
              </div>
              <p className="text-sm text-foreground/90 whitespace-pre-wrap break-words leading-snug">
                {msg.message}
              </p>
            </div>
          ))
        )}
      </div>

      <div className="border-t border-border p-3 space-y-2 bg-background/40 shrink-0">
        {error && (
          <div className="text-xs text-destructive flex items-center gap-1.5">
            <AlertTriangle className="w-3 h-3" /> {error}
          </div>
        )}
        <Input
          value={username}
          onChange={(e) => setUsername(e.target.value.slice(0, MAX_USERNAME_LENGTH))}
          maxLength={MAX_USERNAME_LENGTH}
          placeholder="Your username"
          className="h-9 text-sm"
        />
        <div className="flex gap-2 items-end">
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value.slice(0, MAX_MESSAGE_LENGTH))}
            onKeyDown={handleKeyDown}
            maxLength={MAX_MESSAGE_LENGTH}
            placeholder={isConnected ? "Type a message… (Enter to send)" : "Waiting for connection…"}
            rows={2}
            className="min-h-[40px] resize-none text-sm"
            disabled={!isConnected}
          />
          <Button
            type="button"
            onClick={handleSend}
            disabled={!isConnected || !draft.trim() || !username.trim()}
            className="gradient-primary border-0 h-10 px-3"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex justify-between text-[10px] text-muted-foreground">
          <span>{username.length}/{MAX_USERNAME_LENGTH} username</span>
          <span>{draft.length}/{MAX_MESSAGE_LENGTH}</span>
        </div>
      </div>
    </section>
  );
};
