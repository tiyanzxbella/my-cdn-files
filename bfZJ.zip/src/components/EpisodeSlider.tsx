import { useEffect, useMemo, useRef } from "react";
import { useNavigate } from "react-router-dom";
import type { Episode } from "@/types/anime";
import { cn } from "@/lib/utils";
import { Badge } from "./ui/badge";

interface EpisodeSliderProps {
  episodes: Episode[];
  currentEpisodeId: string;
}

export const EpisodeSlider = ({ episodes, currentEpisodeId }: EpisodeSliderProps) => {
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef<HTMLButtonElement>(null);

  // Sort oldest -> newest (left -> right)
  const sorted = useMemo(
    () =>
      [...episodes].sort((a, b) => {
        const an = parseInt(a.number, 10) || 0;
        const bn = parseInt(b.number, 10) || 0;
        return an - bn;
      }),
    [episodes],
  );

  // Auto scroll to current episode on mount / change
  useEffect(() => {
    const el = activeRef.current;
    const container = containerRef.current;
    if (!el || !container) return;
    const elLeft = el.offsetLeft;
    const elWidth = el.offsetWidth;
    const target = elLeft - container.clientWidth / 2 + elWidth / 2;
    container.scrollTo({ left: Math.max(0, target), behavior: "smooth" });
  }, [currentEpisodeId, sorted.length]);

  if (!sorted.length) return null;

  const padNumber = (n: string) => {
    const parsed = parseInt(n, 10);
    if (isNaN(parsed)) return n;
    return parsed.toString().padStart(2, "0");
  };

  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
          Episodes
        </h3>
        <span className="text-xs text-muted-foreground">{sorted.length} total</span>
      </div>
      <div
        ref={containerRef}
        className="flex gap-2 overflow-x-auto scrollbar-hide -mx-4 px-4 pb-2 snap-x scroll-smooth"
      >
        {sorted.map((ep) => {
          const active = ep.id === currentEpisodeId;
          return (
            <button
              key={ep.id}
              ref={active ? activeRef : undefined}
              type="button"
              onClick={() => navigate(`/watch/${ep.id}`)}
              aria-label={`Episode ${ep.number}`}
              aria-current={active ? "true" : undefined}
              className={cn(
                "relative shrink-0 snap-start min-w-[64px] h-14 px-3 rounded-lg border text-sm font-bold transition-all flex items-center justify-center",
                active
                  ? "gradient-primary border-transparent text-primary-foreground shadow-glow scale-105"
                  : "bg-card border-border hover:border-primary/60 hover:bg-secondary",
              )}
            >
              {padNumber(ep.number)}
              {ep.isNew && !active && (
                <Badge className="absolute -top-1.5 -right-1.5 gradient-primary border-0 text-[9px] px-1 py-0 leading-tight">
                  NEW
                </Badge>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
