import { AlertCircle } from "lucide-react";
import { Button } from "./ui/button";

interface ErrorStateProps {
  message?: string;
  onRetry?: () => void;
}

export const ErrorState = ({ message, onRetry }: ErrorStateProps) => (
  <div className="flex flex-col items-center justify-center text-center py-16 px-4 space-y-3">
    <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center">
      <AlertCircle className="w-7 h-7 text-destructive" />
    </div>
    <h3 className="text-lg font-semibold">Something went wrong</h3>
    <p className="text-sm text-muted-foreground max-w-md">
      {message ?? "Failed to load data (CORS or network issue)"}
    </p>
    {onRetry && (
      <Button onClick={onRetry} variant="secondary">
        Try again
      </Button>
    )}
  </div>
);
