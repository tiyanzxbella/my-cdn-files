import https from 'https';
import http from 'http';
import zlib from 'zlib';
import axios from 'axios';
import * as cheerio from 'cheerio';

// ============================================
// FREE REELS CONFIGURATION
// ============================================
const CONFIG = {
  baseUrl: 'https://apiv2.free-reels.com',
  country: 'ID',
  language: 'id-ID',
  appVersion: '2.1.91',
  appName: 'com.freereels.app',
  
  deviceId: 'ab7d060a1c2a6b47',
  deviceModel: 'ASUS_AI2401_A',
  deviceBrand: 'Asus',
  deviceProduct: 'PLJ110',
  deviceVersion: '36',
  screen: { width: 360, height: 812 },
  
  oauth: {
    token: '4zd4fL5xRaK7L9azadaEEN2vqGoRbf5f',
    signature: '1131ffdde3288b27f4f0a73eea6d534d'
  },
  
  abExps: '950:3202,960:3237,883:2925,962:3244,956:3222,697:2196,961:3243,477:1439,976:3287,932:3123,437:1325,807:2618,676:2112,823:2675,919:3075,731:2311,534:1612,205:552,906:3005,544:1646,645:2001,886:2939,769:2457,955:3217,963:3246,959:3231,617:1901'
};

class Session {
  sessionId: string;
  firebaseId: string;
  appsflyerId: string;
  gaId: string;
  timestamp: number;

  constructor() {
    this.sessionId = this.generateUuid();
    this.firebaseId = this.generateFirebaseId();
    this.appsflyerId = `${Date.now()}-${this.generateRandomId(19)}`;
    this.gaId = this.generateUuid();
    this.timestamp = Date.now();
  }
  
  generateUuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
  
  generateFirebaseId() {
    return this.generateRandomId(32);
  }
  
  generateRandomId(length: number) {
    const chars = '0123456789abcdef';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
  
  getTimestamp() {
    return Date.now().toString();
  }
}

class HttpClient {
  static async request(options: any, body: any = null): Promise<any> {
    return new Promise((resolve, reject) => {
      const url = new URL(options.url);
      const isHttps = url.protocol === 'https:';
      const lib = isHttps ? https : http;
      
      const requestOptions: any = {
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: options.method || 'GET',
        headers: options.headers || {}
      };
      
      if (body) {
        const bodyData = typeof body === 'string' ? body : JSON.stringify(body);
        requestOptions.headers['Content-Length'] = Buffer.byteLength(bodyData);
      }
      
      const req = lib.request(requestOptions, (res) => {
        const chunks: any[] = [];
        
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          const buffer = Buffer.concat(chunks);
          let data = buffer;
          
          if (res.headers['content-encoding'] === 'gzip') {
            try {
              data = zlib.gunzipSync(buffer);
            } catch (e) {
              // Ignore
            }
          }
          
          try {
            const json = JSON.parse(data.toString('utf-8'));
            resolve({ statusCode: res.statusCode, headers: res.headers, data: json });
          } catch (e) {
            resolve({ statusCode: res.statusCode, headers: res.headers, data: data.toString('utf-8') });
          }
        });
      });
      
      req.on('error', reject);
      
      if (body) {
        req.write(typeof body === 'string' ? body : JSON.stringify(body));
      }
      
      req.end();
    });
  }
}

export class FreeReelsAPI {
  session: Session;

  constructor() {
    this.session = new Session();
  }
  
  buildHeaders(includeAuth = true) {
    const headers: any = {
      'Host': 'apiv2.free-reels.com',
      'Connection': 'Keep-Alive',
      'Accept-Encoding': 'gzip',
      'User-Agent': 'okhttp/4.12.0',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      
      'country': CONFIG.country,
      'timezone': '+7',
      'device-country': CONFIG.country,
      'language': CONFIG.language,
      'device-id': CONFIG.deviceId,
      'device-memory': '7.28',
      'device-language': CONFIG.language,
      'device-version': CONFIG.deviceVersion,
      'screen-width': CONFIG.screen.width.toString(),
      'screen-height': CONFIG.screen.height.toString(),
      'x-device-brand': CONFIG.deviceBrand,
      'x-device-product': CONFIG.deviceProduct,
      'x-device-model': CONFIG.deviceModel,
      'x-device-manufacturer': CONFIG.deviceBrand,
      'x-device-fingerprint': `OPPO/PLJ110/OP5E17L1:16/BP2A.250605.015/B.53fe372-338cc21-3391320:user/release-keys`,
      
      'app-name': CONFIG.appName,
      'app-version': CONFIG.appVersion,
      'is-mainland': 'false',
      'mcc-country': '510',
      'device': 'android',
      'network-type': 'no_permission',
      
      'X-Appsflyer_Id': this.session.appsflyerId,
      'gaid': this.session.gaId,
      'appsflyer-id': this.session.appsflyerId,
      'firebase-id': this.session.firebaseId,
      'session-id': this.session.sessionId,
      
      'Ab-Exps': CONFIG.abExps
    };
    
    if (includeAuth) {
      headers['Authorization'] = `oauth_signature=${CONFIG.oauth.signature},oauth_token=${CONFIG.oauth.token},ts=${this.session.getTimestamp()}`;
    }
    
    return headers;
  }
  
  async getDashboard(tabKey = '503', positionIndex = 10000) {
    const url = `${CONFIG.baseUrl}/frv2-api/homepage/v2/tab/index`;
    const params = new URLSearchParams({
      tab_key: tabKey,
      position_index: positionIndex.toString(),
      rec_trigger: '1'
    });
    
    const response = await HttpClient.request({
      url: `${url}?${params}`,
      method: 'GET',
      headers: this.buildHeaders()
    });
    
    return this.parseDashboard(response.data);
  }
  
  parseDashboard(data: any) {
    if (!data || data.code !== 200 || !data.data) {
      return [];
    }
    const items: any[] = [];
    for (const module of data.data.items || []) {
      for (const item of module.items || []) {
        items.push({
          id: item.key, // Ensure consistent id key for UI
          title: item.title,
          poster: item.cover,
          description: item.desc,
          tags: item.tag || [],
          episodes: item.episode_count,
          score: item.hot_score ? (item.hot_score / 1000).toFixed(1) : undefined,
          isFree: item.free,
          source: 'freereels'
        });
      }
    }
    return items;
  }
  
  async getHotlist() {
    const url = `${CONFIG.baseUrl}/frv2-api/search/hot-list`;
    const response = await HttpClient.request({
      url: url,
      method: 'POST',
      headers: this.buildHeaders()
    }, {});
    
    if (!response.data || response.data.code !== 200 || !response.data.data) return [];
    
    return (response.data.data.items || []).map((item: any) => ({
      id: item.id,
      title: item.name,
      description: item.desc,
      poster: item.cover,
      tags: item.series_tag || [],
      episodes: item.episode_count,
      score: item.hot_score ? (item.hot_score / 1000).toFixed(1) : undefined,
      isFree: item.free,
      source: 'freereels'
    }));
  }

  async getDramaInfo(seriesId: string) {
    const url = `${CONFIG.baseUrl}/frv2-api/drama/info_v2`;
    const params = new URLSearchParams({
      series_id: seriesId,
      clip_content: ''
    });
    const response = await HttpClient.request({
      url: `${url}?${params}`,
      method: 'GET',
      headers: this.buildHeaders()
    });
    
    if (!response.data || response.data.code !== 200 || !response.data.data) return null;
    const info = response.data.data.info || {};
    return {
      id: info.id,
      title: info.name,
      description: info.desc,
      poster: info.cover,
      tags: info.tag || [],
      episodes: info.episode_count,
      isFree: info.free,
      source: 'freereels',
      episodeList: (info.episode_list || []).map((ep: any) => ({
        id: ep.id,
        title: ep.name || `Episode ${ep.index}`,
        poster: ep.cover,
        duration: ep.duration,
        index: ep.index,
        h264Url: ep.external_audio_h264_m3u8,
        h265Url: ep.external_audio_h265_m3u8,
        subtitles: (ep.subtitle_list || []).map((sub: any) => ({
          language: sub.language,
          name: sub.display_name,
          url: sub.vtt || sub.subtitle
        }))
      }))
    };
  }

  async search(keyword: string, next = '') {
    const url = `${CONFIG.baseUrl}/frv2-api/search/drama`;
    const body = {
      next: next,
      keyword: keyword,
      timestamp: this.session.getTimestamp()
    };
    const response = await HttpClient.request({
      url: url,
      method: 'POST',
      headers: this.buildHeaders()
    }, body);
    
    if (!response.data || response.data.code !== 200 || !response.data.data) return { items: [], next: '' };
    
    const items = (response.data.data.items || []).map((item: any) => ({
      id: item.id,
      title: item.name,
      description: item.desc,
      poster: item.cover,
      tags: item.series_tag || [],
      episodes: item.episode_count,
      score: item.hot_score ? (item.hot_score / 1000).toFixed(1) : undefined,
      isFree: item.free,
      source: 'freereels'
    }));
    
    return {
      items,
      next: response.data.data.page_info?.next || ''
    };
  }
}

// ============================================
// KLIKXXI SCRAPER (Based on Loklok?)
// ============================================
export class KlikXXIScraper {
  baseURL = 'https://klikxxi.me';
  
  async search(query: string) {
    try {
      const response = await axios.get(`${this.baseURL}/`, {
        params: { s: query, 'post_type[]': ['post', 'tv'] },
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      
      const $ = cheerio.load(response.data);
      const results: any[] = [];
      
      $('#gmr-main-load .item-infinite').each((index, element) => {
        const item = $(element);
        const title = item.find('.entry-title a').text().trim();
        const url = item.find('.entry-title a').attr('href');
        const thumbnail = item.find('img').attr('data-lazy-src') || item.find('img').attr('src');
        const rating = item.find('.gmr-rating-item').text().replace('icon_star', '').trim();
        const quality = item.find('.gmr-quality-item').text().trim();
        const epsMatch = title.match(/Episode\s*(\d+)/i);
        
        results.push({
          id: url ? Buffer.from(url).toString('base64') : null, // encode URL as ID
          title,
          poster: thumbnail?.startsWith('//') ? 'https:' + thumbnail : thumbnail,
          url,
          score: rating,
          quality,
          episodes: epsMatch ? epsMatch[1] : '1',
          source: 'klikxxi'
        });
      });
      return results;
    } catch (e) {
      console.error("Error scraping Loklok/KlikXXI:", e);
      return [];
    }
  }

  async getDetail(idBase64: string) {
    try {
      const url = Buffer.from(idBase64, 'base64').toString('ascii');
      const response = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      const $ = cheerio.load(response.data);
      
      const servers: any[] = [];
      $('.muvipro-player-tabs li a').each((i, el) => {
        servers.push({
          name: $(el).text().trim(),
          id: $(el).attr('id'),
          url: $(el).attr('href')
        });
      });
      
      // Grab the main iframe if available
      const iframeSrc = $('.gmr-embed-responsive iframe').attr('src');
      if (iframeSrc) {
        servers.push({ name: 'Default', url: iframeSrc });
      }

      return {
        id: idBase64,
        title: $('.entry-title').text().trim(),
        poster: $('.gmr-movie-data figure img').attr('data-lazy-src') || $('.gmr-movie-data figure img').attr('src'),
        description: $('.entry-content p').first().text().trim(),
        score: $('.gmr-meta-rating span[itemprop="ratingValue"]').text().trim(),
        source: 'klikxxi',
        url,
        episodeList: [
          {
            id: url,
            title: 'Full Movie/Episode',
            h264Url: iframeSrc || '', // fallback
            servers
          }
        ]
      };
    } catch (e) {
      console.error("Error fetching detail KlikXXI:", e);
      return null;
    }
  }
}
