import fetch from 'node-fetch';

async function test() {
  try {
    const response = await fetch('http://localhost:3000/api/completed-anime');
    const json = await response.json();
    console.log(JSON.stringify(json, null, 2).substring(0, 500));
  } catch (e) {
    console.error(e);
  }
}

test();
