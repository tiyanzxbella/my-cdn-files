import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export function AIRecommendations() {
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          fetchRecommendations(session.user.id);
        }
      });
    }
  }, []);

  const fetchRecommendations = async (userId: string) => {
    setLoading(true);
    try {
      // 1. Get user's watch history
      const { data: history } = await supabase
        .from('watch_history')
        .select('title')
        .eq('user_id', userId)
        .order('last_watched_at', { ascending: false })
        .limit(10);

      // 2. Get user's bookmarks
      const { data: bookmarks } = await supabase
        .from('bookmarks')
        .select('title')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(10);

      const historyTitles = history?.map(h => h.title) || [];
      const bookmarkTitles = bookmarks?.map(b => b.title) || [];
      const combinedTitles = [...new Set([...historyTitles, ...bookmarkTitles])];

      if (combinedTitles.length === 0) {
        setLoading(false);
        return; // Not enough data to recommend
      }

      // 3. Call our backend API to get Gemini recommendations
      const response = await fetch('/api/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ watchedAnime: combinedTitles })
      });

      if (!response.ok) throw new Error('Failed to fetch recommendations');
      
      const data = await response.json();
      setRecommendations(data.recommendations || []);
    } catch (err) {
      console.error(err);
      setError('Gagal memuat rekomendasi AI.');
    } finally {
      setLoading(false);
    }
  };

  if (!user || (recommendations.length === 0 && !loading)) {
    return null;
  }

  return (
    <>
      <div className="flex items-end justify-between mb-8 px-2">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-500/20 border border-purple-500/30 rounded-full text-[10px] font-bold text-purple-300 uppercase tracking-wider mb-3">
            <i className="fa-solid fa-sparkles"></i> Pilihan Terbaik
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-white mb-2">AI <span className="ai-text-gradient">Recommended</span></h2>
          <p className="text-white/40 text-sm md:text-base font-medium">Kurasi eksklusif berdasarkan algoritmamu.</p>
        </div>
        <Link to="/recommendations" className="group flex items-center gap-3 hover:opacity-80 transition-opacity pb-1 shrink-0">
          <span className="text-sm font-bold text-white/50 group-hover:text-purple-400 hidden sm:block transition-colors">Eksplorasi</span>
          <div className="w-10 h-10 rounded-full glass-dock border border-white/10 flex items-center justify-center group-hover:bg-purple-500/20 group-hover:border-purple-500/50 transition-all shadow-lg">
            <i className="fa-solid fa-arrow-right text-white/70 group-hover:text-white transform group-hover:translate-x-1 transition-transform"></i>
          </div>
        </Link>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : error ? (
        <div className="text-red-500 text-sm px-2">{error}</div>
      ) : (
        <div className="flex gap-4 md:gap-6 overflow-x-auto no-scrollbar pb-12 pt-4 px-2 snap-x">
          {recommendations.map((anime, idx) => (
            <div key={idx} className="tilt-card-wrapper w-[160px] md:w-[240px] shrink-0 snap-start">
              <div className="tilt-card relative aspect-[3/4] w-full rounded-2xl md:rounded-3xl overflow-hidden cursor-pointer group bg-darkCard border border-white/5 shadow-2xl block flex flex-col">
                <div className="absolute top-3 left-3 ai-gradient px-2.5 py-1 rounded-lg text-[10px] font-bold text-white shadow-lg tilt-card-content flex items-center gap-1 z-30">
                  <i className="fa-solid fa-sparkles"></i> Best
                </div>
                <div className="flex-1 p-4 flex flex-col justify-end relative z-20 bg-gradient-to-t from-black via-black/80 to-black/40 h-full">
                  <h3 className="font-bold text-sm md:text-base text-white line-clamp-2 leading-tight mb-2 group-hover:text-primary transition-colors">{anime.title}</h3>
                  <p className="text-xs text-white/60 line-clamp-3 mb-4">{anime.reason}</p>
                  <Link to={`/search/${encodeURIComponent(anime.title)}`} className="text-xs bg-primary/20 text-primary px-3 py-2 rounded-lg font-bold hover:bg-primary hover:text-primary-foreground transition-colors text-center w-full">
                    Cari Anime Ini
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
