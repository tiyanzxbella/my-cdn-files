import { Link } from 'react-router-dom';

interface AnimeCardProps {
  title: string;
  poster: string;
  animeId: string;
  status?: string;
  score?: string;
  episodes?: number | string;
  type?: 'ongoing' | 'recommended' | 'completed' | 'trending';
  releaseDay?: string;
  isScrollable?: boolean;
  isDracin?: boolean;
}

export function AnimeCard({ title, poster, animeId, status, score, episodes, type = 'ongoing', releaseDay, isScrollable = false, isDracin = false }: AnimeCardProps) {
  const wrapperClass = isScrollable ? "w-[160px] md:w-[240px] shrink-0 snap-start" : "w-full";
  
  let topBadge = null;
  if (type === 'ongoing') {
    topBadge = <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold border border-white/10 text-white shadow-lg tilt-card-content">{releaseDay || status || 'Ongoing'}</div>;
  } else if (type === 'recommended') {
    topBadge = <div className="absolute top-3 left-3 ai-gradient px-2.5 py-1 rounded-lg text-[10px] font-bold text-white shadow-lg tilt-card-content flex items-center gap-1"><i className="fa-solid fa-sparkles"></i> Best</div>;
  } else if (type === 'completed') {
    topBadge = <div className="absolute top-3 right-3 bg-yellow-500/90 backdrop-blur px-2 py-1 rounded-lg text-[11px] font-black text-black shadow-[0_0_15px_rgba(234,179,8,0.5)] flex items-center gap-1 tilt-card-content"><i className="fa-solid fa-star text-[9px]"></i> {score || '?'}</div>;
  }

  const linkTo = isDracin ? `/dracin/${animeId}` : `/anime/${animeId}`;

  return (
    <div className={`tilt-card-wrapper ${wrapperClass}`}>
      <Link to={linkTo} className="tilt-card relative aspect-[3/4] w-full rounded-2xl md:rounded-3xl overflow-hidden cursor-pointer group bg-darkCard border border-white/5 shadow-2xl block">
        <img 
          src={poster} 
          alt={`Nonton Anime ${title} Sub Indo`} 
          loading="lazy" 
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-90 group-hover:opacity-100 transition-opacity"></div>
        {topBadge}
        <div className="absolute inset-0 flex justify-center items-center opacity-0 group-hover:opacity-100 transition-all duration-500 scale-75 group-hover:scale-100 z-20">
          <div className="w-16 h-16 rounded-full bg-purple-600/80 backdrop-blur flex items-center justify-center pl-1 border border-white/30 shadow-[0_0_30px_rgba(168,85,247,0.8)]">
            <i className="fa-solid fa-play text-white text-xl"></i>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 w-full p-4 tilt-card-content pointer-events-none z-20">
          <div className="text-[10px] md:text-xs font-bold text-purple-400 mb-1.5 uppercase tracking-wider bg-purple-900/30 w-fit px-2 py-0.5 rounded border border-purple-500/20">EP {episodes || '?'}</div>
          <h3 className="font-bold text-sm md:text-base text-white line-clamp-2 leading-tight">{title}</h3>
        </div>
      </Link>
    </div>
  );
}
