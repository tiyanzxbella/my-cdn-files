import { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export function NotificationsDropdown({ user }: { user: any }) {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user || !supabase) return;

    const checkNewEpisodes = async () => {
      setLoading(true);
      try {
        // 1. Get user's bookmarks
        const { data: bookmarks } = await supabase
          .from('bookmarks')
          .select('anime_id, title')
          .eq('user_id', user.id);

        if (!bookmarks || bookmarks.length === 0) {
          setLoading(false);
          return;
        }

        // 2. Fetch ongoing anime to see what's new
        const res = await fetch('/api/home');
        const json = await res.json();
        const ongoingList = json.data?.ongoing?.animeList || [];

        // 3. Find matches
        const newNotifs = [];
        for (const bookmark of bookmarks) {
          const ongoingMatch = ongoingList.find((a: any) => a.animeId === bookmark.anime_id);
          if (ongoingMatch) {
            newNotifs.push({
              id: bookmark.anime_id,
              title: bookmark.title,
              message: `Episode ${ongoingMatch.episodes} baru saja rilis!`,
              link: `/anime/${bookmark.anime_id}`,
              time: 'Baru saja'
            });
          }
        }

        setNotifications(newNotifs);
      } catch (err) {
        console.error('Failed to fetch notifications', err);
      } finally {
        setLoading(false);
      }
    };

    checkNewEpisodes();
    // Poll every 5 minutes
    const interval = setInterval(checkNewEpisodes, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [user]);

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="text-muted-foreground hover:text-primary transition-colors relative p-2" 
        title="Notifications"
      >
        <Bell size={20} />
        {notifications.length > 0 && (
          <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-card"></span>
        )}
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)}></div>
          <div className="absolute right-0 mt-2 w-80 bg-card border border-border rounded-xl shadow-2xl z-50 overflow-hidden">
            <div className="p-4 border-b border-border bg-muted/30">
              <h3 className="font-bold text-foreground">Notifikasi</h3>
            </div>
            <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
              {loading ? (
                <div className="p-4 text-center text-sm text-muted-foreground">Memeriksa pembaruan...</div>
              ) : notifications.length === 0 ? (
                <div className="p-8 text-center text-sm text-muted-foreground">
                  Belum ada notifikasi baru.
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {notifications.map((notif) => (
                    <Link 
                      key={notif.id} 
                      to={notif.link}
                      onClick={() => setIsOpen(false)}
                      className="block p-4 hover:bg-muted transition-colors"
                    >
                      <p className="text-sm font-bold text-foreground mb-1">{notif.title}</p>
                      <p className="text-sm text-primary mb-2">{notif.message}</p>
                      <p className="text-xs text-muted-foreground">{notif.time}</p>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
