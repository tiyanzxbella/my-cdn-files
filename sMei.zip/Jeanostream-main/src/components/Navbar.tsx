import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { AuthModal } from './AuthModal';

export function Navbar() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [showAuth, setShowAuth] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUser = async () => {
      if (!supabase) return;
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
      if (session?.user) {
        const { data } = await supabase.from('user_profiles').select('*').eq('user_id', session.user.id).single();
        setProfile(data);
      }
    };
    
    fetchUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        const { data } = await supabase.from('user_profiles').select('*').eq('user_id', session.user.id).single();
        setProfile(data);
      } else {
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/search/${encodeURIComponent(search.trim())}`);
      setIsSearchOpen(false);
      setIsMobileMenuOpen(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch(e);
    }
  };

  const handleLogout = async () => {
    if (!supabase) return;
    await supabase.auth.signOut();
    setIsProfileOpen(false);
    setIsMobileMenuOpen(false);
  };

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
    if (!isSearchOpen) {
       setTimeout(() => {
          document.getElementById('searchInput')?.focus();
       }, 100);
    }
  };
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const toggleProfile = () => setIsProfileOpen(!isProfileOpen);

  return (
    <>
      {/* DESKTOP DOCK NAVIGATION */}
      <nav className="hidden lg:flex fixed bottom-8 left-1/2 transform -translate-x-1/2 w-fit glass-dock rounded-[2rem] p-1.5 z-[100] items-center gap-1 shadow-2xl transition-all duration-500 hover:bg-black/60 border border-white/10">
        {/* Logo */}
        <Link to="/" className="px-5 text-xl font-display font-bold text-white flex items-center gap-2 shrink-0 group" aria-label="Home">
          <div className="w-8 h-8 rounded-full ai-gradient flex items-center justify-center group-hover:rotate-90 transition-transform duration-500 shadow-[0_0_15px_rgba(168,85,247,0.5)]">
            <i className="fa-solid fa-play text-xs text-white"></i>
          </div> 
          JEANOSTREAM
        </Link>
        <div className="w-px h-6 bg-white/10 mx-1 shrink-0"></div>
        
        {/* Links */}
        <div className="flex items-center gap-1 shrink-0 px-1">
          <Link to="/" className="px-4 py-2 rounded-full text-sm font-semibold text-white hover:bg-white/10 transition-all flex items-center gap-2">
            <i className="fa-solid fa-house text-white/50"></i> Home
          </Link>
          <Link to="/ongoing" className="px-4 py-2 rounded-full text-sm font-medium text-white/60 hover:text-white hover:bg-white/5 transition-all flex items-center gap-2">
            <i className="fa-solid fa-fire text-orange-500/70"></i> Ongoing
          </Link>
          <Link to="/recommendations" className="px-5 py-2 rounded-full text-sm font-bold text-white relative group ml-1 shrink-0 overflow-hidden transform hover:scale-105 transition-all">
            <div className="absolute inset-0 ai-gradient opacity-80 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative flex items-center gap-2 z-10 drop-shadow-md">
              <i className="fa-solid fa-sparkles animate-pulse"></i> AI Picks
            </div>
          </Link>
          <Link to="/completed" className="px-4 py-2 rounded-full text-sm font-medium text-white/60 hover:text-white hover:bg-white/5 transition-all flex items-center gap-2">
            <i className="fa-solid fa-check-double text-green-400/70"></i> Completed
          </Link>
        </div>
        
        <div className="w-px h-6 bg-white/10 mx-1 shrink-0"></div>
        
        {/* Search & Auth */}
        <button onClick={toggleSearch} className="w-10 h-10 rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors shrink-0 group" aria-label="Search">
          <i className="fa-solid fa-magnifying-glass group-hover:scale-110 transition-transform"></i>
        </button>

        <div className="relative flex items-center ml-1">
          {user ? (
            <button onClick={toggleProfile} className="px-2 pr-4 py-1.5 rounded-full bg-white/10 text-white text-sm font-bold hover:scale-105 transition-all flex items-center gap-2 relative overflow-hidden group border border-white/20">
              <span className="relative z-10 flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 p-0.5">
                  <img src={profile?.avatar_url || "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=transparent"} alt="Avatar" className="w-full h-full bg-darkBg rounded-full" />
                </div>
                <span className="text-white text-sm">Profil</span>
              </span>
            </button>
          ) : (
            <button onClick={() => setShowAuth(true)} className="px-6 py-2.5 rounded-full bg-white text-black text-sm font-bold hover:scale-105 transition-all flex items-center gap-2 relative overflow-hidden group">
              <span className="relative z-10 flex items-center gap-2">Masuk</span>
              <div className="absolute inset-0 bg-gray-200 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
            </button>
          )}
          
          {/* POP-UP DROPDOWN PROFILE */}
          {user && (
            <div className={`absolute bottom-[calc(100%+16px)] right-0 w-64 glass-panel rounded-3xl p-2 shadow-2xl border border-white/20 transition-all duration-300 transform origin-bottom-right ${isProfileOpen ? 'opacity-100 scale-100 pointer-events-auto' : 'opacity-0 scale-95 pointer-events-none'}`}>
              <div className="p-4 border-b border-white/10 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 p-0.5">
                  <img src={profile?.avatar_url || "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=transparent"} alt="Avatar" className="w-full h-full bg-darkBg rounded-full" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white leading-none">{profile?.username || 'User'}</p>
                  <p className="text-[10px] text-purple-400 font-medium mt-1"><i className="fa-solid fa-crown"></i> Premium Member</p>
                </div>
              </div>
              <div className="p-2 flex flex-col gap-1">
                <Link to="/profile" onClick={() => setIsProfileOpen(false)} className="px-4 py-2.5 rounded-xl text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white transition-colors flex items-center gap-3">
                  <i className="fa-regular fa-user w-4 text-center"></i> Profil Saya
                </Link>
                <Link to="/bookmarks" onClick={() => setIsProfileOpen(false)} className="px-4 py-2.5 rounded-xl text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white transition-colors flex items-center gap-3">
                  <i className="fa-regular fa-bookmark w-4 text-center"></i> Bookmark
                </Link>
              </div>
              <div className="p-2 border-t border-white/10">
                <button onClick={handleLogout} className="w-full px-4 py-2.5 rounded-xl text-sm font-bold text-red-400 hover:bg-red-500/20 transition-colors flex items-center gap-3">
                  <i className="fa-solid fa-right-from-bracket w-4 text-center"></i> Keluar
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* MOBILE BOTTOM BAR */}
      <nav className="lg:hidden fixed bottom-4 left-4 right-4 glass-dock rounded-[2rem] px-5 py-3 z-[100] flex justify-between items-center shadow-2xl border border-white/10">
        <Link to="/" className="flex flex-col items-center gap-1 text-white p-2" aria-label="Home">
          <i className="fa-solid fa-house text-[22px]"></i>
        </Link>
        <Link to="/ongoing" className="flex flex-col items-center gap-1 text-white/40 hover:text-white transition-all p-2" aria-label="Ongoing">
          <i className="fa-solid fa-fire text-[22px]"></i>
        </Link>
        
        {/* MAGIC CENTER BUTTON */}
        <div className="relative -top-6">
          {user ? (
            <button onClick={toggleMobileMenu} className="flex flex-col items-center justify-center w-[68px] h-[68px] rounded-full bg-gradient-to-r from-purple-500 to-pink-500 shadow-[0_10px_30px_rgba(168,85,247,0.6)] border-[5px] border-[#050505] transform hover:scale-105 transition-transform p-0.5 relative z-10 overflow-hidden" aria-label="Profile">
              <div className="w-full h-full rounded-full bg-darkBg overflow-hidden flex items-center justify-center">
                <img src={profile?.avatar_url || "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=transparent"} alt="Avatar" className="w-full h-full scale-125 pt-1" />
              </div>
            </button>
          ) : (
            <button onClick={toggleSearch} className="flex flex-col items-center justify-center w-[68px] h-[68px] rounded-full ai-gradient shadow-[0_10px_30px_rgba(168,85,247,0.6)] border-[5px] border-[#050505] transform hover:scale-105 transition-transform relative z-10" aria-label="Search Center">
              <i className="fa-solid fa-magnifying-glass text-2xl text-white"></i>
            </button>
          )}
        </div>
        
        <Link to="/completed" className="flex flex-col items-center gap-1 text-white/40 hover:text-white transition-all p-2" aria-label="Completed">
          <i className="fa-solid fa-check-double text-[22px]"></i>
        </Link>
        <button onClick={toggleMobileMenu} className="flex flex-col items-center gap-1 text-white/40 hover:text-white transition-all p-2 relative" aria-label="Menu">
          <i className="fa-solid fa-bars-staggered text-[22px]"></i>
        </button>
      </nav>

      {/* FULLSCREEN SEARCH OVERLAY */}
      <div className={`fixed inset-0 z-[120] flex flex-col transition-all duration-400 ${isSearchOpen ? 'opacity-100 pointer-events-auto backdrop-blur-[25px] bg-black/80' : 'opacity-0 pointer-events-none'}`}>
        <div className="absolute inset-0" onClick={toggleSearch}></div>
        <div className={`relative w-full max-w-4xl mx-auto px-4 pt-12 md:pt-20 transition-all duration-500 ${isSearchOpen ? 'translate-y-0 opacity-100' : '-translate-y-[30px] opacity-0'}`}>
          <div className="flex items-center w-full bg-white/10 border border-white/20 rounded-2xl p-2 shadow-2xl backdrop-blur-xl focus-within:border-purple-500/50 focus-within:bg-white/15 transition-all">
            <i className="fa-solid fa-magnifying-glass text-xl md:text-2xl text-purple-400 ml-4 mr-3"></i>
            <input 
              id="searchInput"
              type="text" 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Cari judul anime, dracin, genre, atau karakter..." 
              className="w-full bg-transparent text-lg md:text-xl font-medium text-white placeholder-white/30 outline-none py-3 px-2"
              autoComplete="off"
            />
            <button type="button" onClick={handleSearch} className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg font-bold mr-2 hidden sm:block transition-colors">Cari</button>
            <button type="button" onClick={toggleSearch} className="w-12 h-12 shrink-0 rounded-xl bg-white/5 border border-white/10 hover:bg-red-500/20 hover:text-red-400 flex items-center justify-center transition-colors mr-1" aria-label="Close Search">
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>
          </div>
          <div className={`mt-8 px-2 md:px-4 transition-all duration-500 delay-300 ${isSearchOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[10px]'}`}>
            <p className="text-xs font-bold text-white/30 uppercase tracking-widest mb-4">
              <i className="fa-solid fa-bolt text-yellow-400 mr-2"></i>Pencarian Populer
            </p>
            <div className="flex flex-wrap gap-2 md:gap-3">
              <Link to="/search/isekai" onClick={toggleSearch} className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm font-medium hover:bg-purple-500/20 hover:text-white transition-all flex items-center gap-2">
                <i className="fa-solid fa-fire text-orange-500"></i> Isekai
              </Link>
              <Link to="/search/ceo" onClick={toggleSearch} className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm font-medium hover:bg-red-500/20 hover:text-white transition-all">
                CEO Cantik
              </Link>
              <Link to="/search/romance" onClick={toggleSearch} className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm font-medium hover:bg-pink-500/20 hover:text-white transition-all flex items-center gap-2">
                <i className="fa-solid fa-heart text-pink-500"></i> Romance
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* MOBILE FULLSCREEN MENU */}
      <div className={`fixed inset-0 z-[110] bg-darkBg/95 backdrop-blur-3xl flex flex-col pt-12 pb-8 px-6 transition-all duration-600 ${isMobileMenuOpen ? 'translate-y-0 opacity-100 pointer-events-auto rounded-none' : 'translate-y-full opacity-0 pointer-events-none rounded-t-[40px]'}`}>
        <div className="flex justify-between items-center mb-6">
          <div className="text-2xl font-display font-bold flex items-center gap-3">
            <div className="w-10 h-10 rounded-full ai-gradient flex items-center justify-center">
              <i className="fa-solid fa-play text-sm text-white"></i>
            </div> 
            JEANOSTREAM
          </div>
          <button onClick={toggleMobileMenu} className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/10 transition-colors" aria-label="Close Menu">
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
        </div>
        
        <div className="flex flex-col gap-3 overflow-y-auto no-scrollbar flex-1 pb-10">
          {/* MOBILE PROFILE HEADER */}
          {user && (
            <div className="mb-4 p-4 rounded-3xl bg-gradient-to-br from-purple-900/40 to-blue-900/20 border border-purple-500/20 flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 p-0.5">
                <img src={profile?.avatar_url || "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=transparent"} alt="Avatar" className="w-full h-full bg-darkBg rounded-full" />
              </div>
              <div className="flex-1">
                <p className="text-lg font-bold text-white leading-tight">{profile?.username || 'User'}</p>
                <p className="text-xs text-purple-400 font-medium mt-0.5">Premium Member</p>
              </div>
              <Link to="/profile" onClick={toggleMobileMenu} className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white" aria-label="Settings">
                <i className="fa-solid fa-gear"></i>
              </Link>
            </div>
          )}

          {/* Menus */}
          <p className="text-xs font-bold text-white/30 uppercase tracking-widest pl-2 mb-1 mt-2">Menu Utama</p>
          <Link to="/" onClick={toggleMobileMenu} className="p-4 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/5 text-white/70 hover:text-white font-bold text-lg flex items-center justify-between group transition-all">
            <div className="flex items-center gap-4"><div className="w-8 flex justify-center"><i className="fa-solid fa-house text-white/60"></i></div> Anime Home</div>
            <i className="fa-solid fa-chevron-right text-sm text-white/20"></i>
          </Link>
          <Link to="/ongoing" onClick={toggleMobileMenu} className="p-4 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/5 text-white/70 hover:text-white font-bold text-lg flex items-center justify-between group transition-all">
            <div className="flex items-center gap-4"><div className="w-8 flex justify-center"><i className="fa-solid fa-fire text-orange-400"></i></div> Ongoing Anime</div>
            <i className="fa-solid fa-chevron-right text-sm text-white/20"></i>
          </Link>
          <Link to="/completed" onClick={toggleMobileMenu} className="p-4 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/5 text-white/70 hover:text-white font-bold text-lg flex items-center justify-between group transition-all">
            <div className="flex items-center gap-4"><div className="w-8 flex justify-center"><i className="fa-solid fa-check-double text-green-400"></i></div> Anime Tamat</div>
            <i className="fa-solid fa-chevron-right text-sm text-white/20"></i>
          </Link>
          
          <p className="text-xs font-bold text-white/30 uppercase tracking-widest pl-2 mb-1 mt-4">Eksplorasi</p>
          <Link to="/recommendations" onClick={toggleMobileMenu} className="relative p-4 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/5 text-white/70 hover:text-white font-bold text-lg flex items-center justify-between group transition-all overflow-hidden">
            <div className="absolute inset-0 ai-gradient opacity-0 group-hover:opacity-20 transition-opacity"></div>
            <div className="flex items-center gap-4 relative z-10"><div className="w-8 flex justify-center"><i className="fa-solid fa-sparkles text-purple-400"></i></div> AI Recommended</div>
            <i className="fa-solid fa-chevron-right text-sm text-white/20 relative z-10"></i>
          </Link>
          
          {user && (
            <>
              <p className="text-xs font-bold text-white/30 uppercase tracking-widest pl-2 mb-1 mt-4">Personal</p>
              <Link to="/bookmarks" onClick={toggleMobileMenu} className="p-4 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/5 text-white/70 hover:text-white font-bold text-lg flex items-center justify-between group transition-all">
                <div className="flex items-center gap-4"><div className="w-8 flex justify-center"><i className="fa-regular fa-bookmark text-white/60"></i></div> Bookmark</div>
                <i className="fa-solid fa-chevron-right text-sm text-white/20"></i>
              </Link>
            </>
          )}
        </div>
        
        <div className="mt-auto pt-4">
          {user ? (
            <button onClick={handleLogout} className="w-full py-4 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 text-center font-bold text-lg transition-colors hover:bg-red-500/20">
              Keluar / Logout
            </button>
          ) : (
            <button onClick={() => { setShowAuth(true); setIsMobileMenuOpen(false); }} className="w-full py-4 rounded-full bg-white text-black text-center font-bold text-lg shadow-[0_0_30px_rgba(255,255,255,0.2)]">
              Masuk / Login
            </button>
          )}
        </div>
      </div>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
    </>
  );
}
