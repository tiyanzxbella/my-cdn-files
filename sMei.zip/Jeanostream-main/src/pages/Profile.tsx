import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { User, Settings, History, Save, PlayCircle } from 'lucide-react';
import { AnimeCard } from '../components/AnimeCard';

export default function Profile() {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [watchHistory, setWatchHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // Form states
  const [username, setUsername] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [theme, setTheme] = useState('dark');
  const [favoriteGenre, setFavoriteGenre] = useState('');
  const [emailNotifications, setEmailNotifications] = useState(true);
  
  const [activeTab, setActiveTab] = useState<'history' | 'settings'>('history');
  const navigate = useNavigate();

  // Apply theme to document
  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, [theme]);

  useEffect(() => {
    const fetchProfileData = async () => {
      if (!supabase) {
        setLoading(false);
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.user) {
        navigate('/');
        return;
      }

      setUser(session.user);

      // Fetch profile
      const { data: profileData } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', session.user.id)
        .single();

      if (profileData) {
        setProfile(profileData);
        setUsername(profileData.username || '');
        setAvatarUrl(profileData.avatar_url || '');
        
        const prefs = profileData.preferences || {};
        setTheme(prefs.theme || 'dark');
        setFavoriteGenre(prefs.favoriteGenre || '');
        setEmailNotifications(prefs.emailNotifications !== false);
      } else {
        // Create profile if it doesn't exist
        const newProfile = {
          user_id: session.user.id,
          username: session.user.email?.split('@')[0] || 'User',
          avatar_url: '',
          preferences: { theme: 'dark', emailNotifications: true }
        };
        await supabase.from('user_profiles').insert([newProfile]);
        setProfile(newProfile);
        setUsername(newProfile.username);
      }

      // Fetch watch history
      const { data: historyData } = await supabase
        .from('watch_history')
        .select('*')
        .eq('user_id', session.user.id)
        .order('watched_at', { ascending: false })
        .limit(50);

      if (historyData) {
        setWatchHistory(historyData);
      }

      setLoading(false);
    };

    fetchProfileData();
  }, [navigate]);

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase || !user) return;
    
    setSaving(true);
    const preferences = { theme, favoriteGenre, emailNotifications };
    
    const { error } = await supabase
      .from('user_profiles')
      .update({ 
        username, 
        avatar_url: avatarUrl,
        preferences 
      })
      .eq('user_id', user.id);
      
    setSaving(false);
    if (!error) {
      alert('Profil berhasil diperbarui!');
    } else {
      alert('Gagal memperbarui profil.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-card rounded-2xl border border-border p-6 md:p-8 mb-8 flex flex-col md:flex-row items-center gap-6 shadow-lg">
        <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-muted flex items-center justify-center overflow-hidden border-4 border-background shadow-xl flex-shrink-0">
          {avatarUrl ? (
            <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
          ) : (
            <User size={48} className="text-muted-foreground" />
          )}
        </div>
        <div className="text-center md:text-left flex-grow">
          <h1 className="text-3xl font-bold text-foreground mb-1">{username || 'User'}</h1>
          <p className="text-muted-foreground mb-4">{user?.email}</p>
          <div className="flex flex-wrap justify-center md:justify-start gap-4 text-sm">
            <div className="bg-background border border-border px-4 py-2 rounded-lg">
              <span className="text-muted-foreground block text-xs">Total Ditonton</span>
              <span className="font-bold text-lg">{watchHistory.length} Episode</span>
            </div>
            {favoriteGenre && (
              <div className="bg-background border border-border px-4 py-2 rounded-lg">
                <span className="text-muted-foreground block text-xs">Genre Favorit</span>
                <span className="font-bold text-lg capitalize">{favoriteGenre}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex border-b border-border mb-8 overflow-x-auto custom-scrollbar">
        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-6 py-4 font-medium transition-colors border-b-2 whitespace-nowrap ${
            activeTab === 'history' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <History size={20} /> Riwayat Tontonan Detail
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-6 py-4 font-medium transition-colors border-b-2 whitespace-nowrap ${
            activeTab === 'settings' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <Settings size={20} /> Pengaturan Akun
        </button>
      </div>

      {activeTab === 'history' && (
        <div>
          {watchHistory.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground bg-card rounded-2xl border border-border">
              Belum ada riwayat tontonan.
            </div>
          ) : (
            <div className="space-y-4">
              {watchHistory.map((item) => {
                const date = new Date(item.watched_at);
                const isToday = new Date().toDateString() === date.toDateString();
                const timeString = isToday 
                  ? `Hari ini, ${date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}`
                  : date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
                  
                return (
                  <Link 
                    key={item.id} 
                    to={`/episode/${item.episode_id}`}
                    className="flex items-center gap-4 bg-card rounded-xl border border-border p-4 hover:bg-muted transition-colors group"
                  >
                    <div className="relative w-24 h-16 sm:w-32 sm:h-20 flex-shrink-0 rounded-lg overflow-hidden bg-black">
                      <img src={item.poster} alt={item.title} className="w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity" />
                      <PlayCircle className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white opacity-80" size={24} />
                    </div>
                    <div className="flex-grow min-w-0">
                      <h3 className="font-bold text-foreground truncate group-hover:text-primary transition-colors">{item.title}</h3>
                      <p className="text-sm text-primary mb-1">
                        Episode {item.episode_id.split('-episode-')[1]?.replace('-sub-indo', '') || '?'}
                      </p>
                      <p className="text-xs text-muted-foreground">{timeString}</p>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeTab === 'settings' && (
        <div className="bg-card rounded-2xl border border-border p-6 md:p-8">
          <form onSubmit={saveProfile} className="space-y-8 max-w-2xl">
            
            {/* Profil Section */}
            <section>
              <h3 className="text-lg font-bold border-b border-border pb-2 mb-4">Profil Publik</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Username</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full bg-background border border-border rounded-xl px-4 py-2 focus:outline-none focus:border-primary"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">URL Avatar</label>
                  <input
                    type="url"
                    value={avatarUrl}
                    onChange={(e) => setAvatarUrl(e.target.value)}
                    placeholder="https://example.com/avatar.png"
                    className="w-full bg-background border border-border rounded-xl px-4 py-2 focus:outline-none focus:border-primary"
                  />
                </div>
              </div>
            </section>

            {/* Preferensi Section */}
            <section>
              <h3 className="text-lg font-bold border-b border-border pb-2 mb-4">Preferensi Aplikasi</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Tema</label>
                  <select
                    value={theme}
                    onChange={(e) => setTheme(e.target.value)}
                    className="w-full bg-background border border-border rounded-xl px-4 py-2 focus:outline-none focus:border-primary mb-4"
                  >
                    <option value="dark">Dark Mode</option>
                    <option value="light">Light Mode</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Genre Favorit</label>
                  <select
                    value={favoriteGenre}
                    onChange={(e) => setFavoriteGenre(e.target.value)}
                    className="w-full bg-background border border-border rounded-xl px-4 py-2 focus:outline-none focus:border-primary"
                  >
                    <option value="">Pilih Genre...</option>
                    <option value="action">Action</option>
                    <option value="adventure">Adventure</option>
                    <option value="comedy">Comedy</option>
                    <option value="drama">Drama</option>
                    <option value="fantasy">Fantasy</option>
                    <option value="isekai">Isekai</option>
                    <option value="romance">Romance</option>
                    <option value="sci-fi">Sci-Fi</option>
                    <option value="slice-of-life">Slice of Life</option>
                  </select>
                  <p className="text-xs text-muted-foreground mt-1">Membantu AI memberikan rekomendasi yang lebih akurat.</p>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-background border border-border rounded-xl">
                  <div>
                    <p className="font-medium">Notifikasi Email</p>
                    <p className="text-xs text-muted-foreground">Terima email saat episode baru rilis</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={emailNotifications}
                      onChange={(e) => setEmailNotifications(e.target.checked)}
                    />
                    <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                  </label>
                </div>
              </div>
            </section>

            <div className="pt-4 border-t border-border">
              <button
                type="submit"
                disabled={saving}
                className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 rounded-xl font-bold transition-colors disabled:opacity-50 w-full sm:w-auto justify-center"
              >
                <Save size={20} /> {saving ? 'Menyimpan...' : 'Simpan Pengaturan'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
