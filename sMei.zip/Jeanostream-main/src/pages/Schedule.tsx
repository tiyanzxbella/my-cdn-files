import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function Schedule() {
  const [schedule, setSchedule] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/schedule')
      .then((res) => res.json())
      .then((json) => {
        setSchedule(json.data || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center text-primary">Jadwal Rilis Anime</h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {schedule.map((dayData: any) => (
          <div key={dayData.day} className="bg-card rounded-xl shadow-lg border border-border overflow-hidden">
            <div className="bg-primary/10 border-b border-border p-4">
              <h2 className="text-xl font-bold text-primary text-center">{dayData.day}</h2>
            </div>
            <ul className="divide-y divide-border">
              {dayData.anime_list?.map((anime: any) => (
                <li key={anime.slug} className="hover:bg-muted/50 transition-colors">
                  <Link to={`/anime/${anime.slug}`} className="flex items-center p-3 gap-3">
                    <img 
                      src={anime.poster} 
                      alt={anime.title} 
                      className="w-12 h-16 object-cover rounded-md"
                      loading="lazy"
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-sm font-medium line-clamp-2 text-foreground hover:text-primary transition-colors">
                      {anime.title}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
