import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AnimeCard } from '../components/AnimeCard';
import { AIRecommendations } from '../components/AIRecommendations';

export default function Home() {
  const [data, setData] = useState<any>(null);
  const [dracinData, setDracinData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const fetchAnime = fetch('/api/home').then((res) => res.json());
    const fetchDracin = fetch('/api/dracin/home').then((res) => res.json());

    Promise.all([fetchAnime, fetchDracin])
      .then(([animeJson, dracinJson]) => {
        setData(animeJson.data);
        setDracinData(dracinJson);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    if (!data || !data.ongoing?.animeList) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % 5);
    }, 6000);
    return () => clearInterval(interval);
  }, [data]);

  useEffect(() => {
    const initTiltEffect = () => {
      if (window.innerWidth < 768) return;
      const cards = document.querySelectorAll('.tilt-card');
      cards.forEach(card => {
        const handleMouseMove = (e: any) => {
          const rect = card.getBoundingClientRect();
          (card as HTMLElement).style.setProperty('--mouse-x', `${e.clientX - rect.left}px`); 
          (card as HTMLElement).style.setProperty('--mouse-y', `${e.clientY - rect.top}px`);
          const rotateX = (((e.clientY - rect.top) - (rect.height / 2)) / (rect.height / 2)) * -10;
          const rotateY = (((e.clientX - rect.left) - (rect.width / 2)) / (rect.width / 2)) * 10;
          (card as HTMLElement).style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        };
        const handleMouseLeave = () => {
          (card as HTMLElement).style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
        };
        card.addEventListener('mousemove', handleMouseMove);
        card.addEventListener('mouseleave', handleMouseLeave);
        
        // Cleanup
        return () => {
          card.removeEventListener('mousemove', handleMouseMove);
          card.removeEventListener('mouseleave', handleMouseLeave);
        };
      });
    };
    
    if (!loading) {
      setTimeout(initTiltEffect, 500);
    }
  }, [loading, data, dracinData]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-16 h-16 rounded-full border-4 border-purple-500 border-t-transparent animate-spin"></div>
      </div>
    );
  }

  if (!data && !dracinData) return <div className="text-center py-12">Gagal memuat data.</div>;

  const animeSliderData = data?.ongoing?.animeList?.slice(0, 3) || [];
  const dracinSliderData = dracinData?.hotlist?.slice(0, 2).map((d: any) => ({
    ...d,
    isDracin: true,
    animeId: d.id // map id to animeId for consistent keying
  })) || [];
  
  const sliderData = [...animeSliderData, ...dracinSliderData];

  const trendData = [...(data?.ongoing?.animeList || []), ...(data?.completed?.animeList || [])].slice(0, 8);
  const dracinHotlist = dracinData?.hotlist?.slice(0, 10) || [];
  const dracinDashboard = dracinData?.dashboard?.slice(0, 10) || [];

  return (
    <>
      {/* CINEMATIC HERO SLIDER */}
      <header className="relative w-full h-[85vh] min-h-[600px] flex items-end pb-24 md:pb-36 z-10 overflow-hidden bg-black">
        {sliderData.map((item: any, index: number) => (
          <div key={item.animeId || item.id} className={`slide-item ${index === currentSlide ? 'active' : ''} w-full h-full`}>
            <div className="absolute inset-0 z-10 bg-gradient-to-t from-darkBg via-darkBg/60 to-transparent"></div>
            <div className="absolute inset-0 z-10 bg-gradient-to-r from-darkBg via-darkBg/60 to-transparent hidden md:block"></div>
            <img src={item.poster} alt={item.title} className="w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 z-20 container mx-auto px-6 md:px-12 flex items-center md:items-end pb-28 md:pb-36">
              <div className="slide-content max-w-4xl">
                {item.isDracin && (
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-500/20 border border-red-500/30 rounded-full text-[10px] font-bold text-red-300 uppercase tracking-wider mb-3">
                    Drama China
                  </div>
                )}
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold tracking-tight mb-4 leading-[1.1] drop-shadow-2xl text-white">{item.title}</h1>
                <p className="text-white/70 text-sm md:text-lg mb-8 line-clamp-2 md:line-clamp-3 max-w-2xl font-medium leading-relaxed">
                  {item.description || "Saksikan keseruan episode terbarunya minggu ini!"}
                </p>
                <div className="flex gap-4 items-center tilt-card-wrapper">
                  <Link to={item.isDracin ? `/dracin/${item.id}?source=${item.source}` : `/anime/${item.animeId}`} className="px-8 py-4 bg-white text-black rounded-full font-bold text-sm hover:scale-105 transition-transform flex items-center gap-3 shadow-[0_0_40px_rgba(255,255,255,0.4)] tilt-card">
                    <i className="fa-solid fa-play text-lg"></i> <span className="tilt-card-content">Tonton Sekarang</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        <div className="absolute bottom-10 left-6 md:left-12 z-20 flex gap-3">
          {sliderData.map((_: any, index: number) => (
            <div 
              key={index} 
              className={`indicator-line ${index === currentSlide ? 'active' : ''}`}
              onClick={() => setCurrentSlide(index)}
            >
              <div className="indicator-progress"></div>
            </div>
          ))}
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="relative z-20 container mx-auto px-4 md:px-8 mt-12 md:mt-16">
        
        {/* TREND MINGGU INI (TOP 10 STYLE) */}
        <section id="trending" className="mb-20 md:mb-24">
          <div className="flex items-end justify-between mb-6 md:mb-8 px-2">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 border border-white/20 rounded-full text-[10px] font-bold text-white uppercase tracking-wider mb-3">
                <i className="fa-solid fa-arrow-trend-up"></i> Paling Banyak Ditonton
              </div>
              <h2 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-white mb-2">Trend Anime <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-200 to-gray-500">Minggu Ini</span></h2>
            </div>
          </div>
          
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-12 pt-4 px-2 snap-x">
            {trendData.map((anime: any, index: number) => (
              <div key={anime.animeId} className="trend-card-group flex items-end shrink-0 snap-start mr-4 md:mr-8 relative group cursor-pointer">
                <div className="text-stroke-number -mr-8 md:-mr-12 relative z-0">{index + 1}</div>
                <div className="relative z-10 w-[140px] md:w-[200px]">
                  <AnimeCard {...anime} type="trending" isScrollable={false} />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* DRACIN HOTLIST (TOP 10 STYLE) */}
        {dracinHotlist.length > 0 && (
          <section id="dracin-trending" className="mb-20 md:mb-24">
            <div className="flex items-end justify-between mb-6 md:mb-8 px-2">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 border border-white/20 rounded-full text-[10px] font-bold text-white uppercase tracking-wider mb-3">
                  <i className="fa-solid fa-fire text-red-500"></i> Hotlist Dracin
                </div>
                <h2 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-white mb-2">Drama <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-pink-500">Terpanas</span></h2>
              </div>
            </div>
            
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-12 pt-4 px-2 snap-x">
              {dracinHotlist.map((drama: any, index: number) => (
                <div key={drama.id} className="trend-card-group flex items-end shrink-0 snap-start mr-4 md:mr-8 relative group cursor-pointer">
                  <div className="text-stroke-number -mr-8 md:-mr-12 relative z-0">{index + 1}</div>
                  <div className="relative z-10 w-[140px] md:w-[200px]">
                    <div className="tilt-card-wrapper w-full">
                      <Link to={`/dracin/${drama.id}?source=${drama.source}`} className="tilt-card relative aspect-[3/4] w-full rounded-2xl md:rounded-3xl overflow-hidden cursor-pointer group bg-darkCard border border-white/5 shadow-2xl block">
                        <img src={drama.poster} alt={drama.title} loading="lazy" referrerPolicy="no-referrer" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-90 group-hover:opacity-100 transition-opacity"></div>
                        <div className="absolute top-3 left-3 bg-red-500/90 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold text-white shadow-lg tilt-card-content">Hot</div>
                        <div className="absolute bottom-0 left-0 w-full p-4 tilt-card-content pointer-events-none z-20">
                          <div className="text-[10px] md:text-xs font-bold text-red-400 mb-1.5 uppercase tracking-wider bg-red-900/30 w-fit px-2 py-0.5 rounded border border-red-500/20">EP {drama.episodes || '?'}</div>
                          <h3 className="font-bold text-sm md:text-base text-white line-clamp-2 leading-tight">{drama.title}</h3>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ONGOING SECTION */}
        <section id="ongoing" className="mb-20 md:mb-24">
          <div className="flex items-end justify-between mb-8 px-2">
            <div>
              <h2 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-white mb-2">Anime On<span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-red-500">going</span></h2>
              <p className="text-white/40 text-sm md:text-base font-medium">Hype setiap minggu tidak pernah berhenti.</p>
            </div>
            <Link to="/ongoing" className="group flex items-center gap-3 hover:opacity-80 transition-opacity pb-1 shrink-0">
              <span className="text-sm font-bold text-white/50 group-hover:text-orange-400 hidden sm:block transition-colors">Lihat Semua</span>
              <div className="w-10 h-10 rounded-full glass-dock border border-white/10 flex items-center justify-center group-hover:bg-orange-500/20 group-hover:border-orange-500/50 transition-all shadow-lg">
                <i className="fa-solid fa-arrow-right text-white/70 group-hover:text-white transform group-hover:translate-x-1 transition-transform"></i>
              </div>
            </Link>
          </div>
          <div className="flex gap-4 md:gap-6 overflow-x-auto no-scrollbar pb-12 pt-4 px-2 snap-x">
            {data?.ongoing?.animeList?.map((anime: any) => (
              <AnimeCard key={anime.animeId} {...anime} type="ongoing" isScrollable={true} />
            ))}
          </div>
        </section>

        {/* DRACIN DASHBOARD SECTION */}
        {dracinDashboard.length > 0 && (
          <section id="dracin-dashboard" className="mb-20 md:mb-24">
            <div className="flex items-end justify-between mb-8 px-2">
              <div>
                <h2 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-white mb-2">Pilihan Dracin <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-red-500">Terbaik</span></h2>
                <p className="text-white/40 text-sm md:text-base font-medium">Banyak drama menarik menunggu Anda.</p>
              </div>
            </div>
            <div className="flex gap-4 md:gap-6 overflow-x-auto no-scrollbar pb-12 pt-4 px-2 snap-x">
              {dracinDashboard.map((drama: any) => (
                 <div key={drama.id} className="tilt-card-wrapper w-[160px] md:w-[240px] shrink-0 snap-start">
                    <Link to={`/dracin/${drama.id}?source=${drama.source}`} className="tilt-card relative aspect-[3/4] w-full rounded-2xl md:rounded-3xl overflow-hidden cursor-pointer group bg-darkCard border border-white/5 shadow-2xl block">
                      <img src={drama.poster} alt={drama.title} loading="lazy" referrerPolicy="no-referrer" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-90 group-hover:opacity-100 transition-opacity"></div>
                      {drama.score && <div className="absolute top-3 right-3 bg-yellow-500/90 backdrop-blur px-2 py-1 rounded-lg text-[11px] font-black text-black shadow-[0_0_15px_rgba(234,179,8,0.5)] flex items-center gap-1 tilt-card-content"><i className="fa-solid fa-star text-[9px]"></i> {drama.score}</div>}
                      <div className="absolute bottom-0 left-0 w-full p-4 tilt-card-content pointer-events-none z-20">
                        <div className="text-[10px] md:text-xs font-bold text-red-400 mb-1.5 uppercase tracking-wider bg-red-900/30 w-fit px-2 py-0.5 rounded border border-red-500/20">EP {drama.episodes || '?'}</div>
                        <h3 className="font-bold text-sm md:text-base text-white line-clamp-2 leading-tight">{drama.title}</h3>
                      </div>
                    </Link>
                  </div>
              ))}
            </div>
          </section>
        )}

        {/* AI RECOMMENDED SECTION */}
        <section id="recommended" className="mb-20 md:mb-24">
          <AIRecommendations />
        </section>

        {/* COMPLETED SECTION */}
        <section id="completed" className="mb-24">
          <div className="flex items-end justify-between mb-8 px-2">
            <div>
              <h2 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-white mb-2">Anime Com<span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">pleted</span></h2>
              <p className="text-white/40 text-sm md:text-base font-medium">Selesaikan ceritanya dalam satu malam.</p>
            </div>
            <Link to="/completed" className="group flex items-center gap-3 hover:opacity-80 transition-opacity pb-1 shrink-0">
              <span className="text-sm font-bold text-white/50 group-hover:text-blue-400 hidden sm:block transition-colors">Lihat Semua</span>
              <div className="w-10 h-10 rounded-full glass-dock border border-white/10 flex items-center justify-center group-hover:bg-blue-500/20 group-hover:border-blue-500/50 transition-all shadow-lg">
                <i className="fa-solid fa-arrow-right text-white/70 group-hover:text-white transform group-hover:translate-x-1 transition-transform"></i>
              </div>
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6 px-2">
            {data?.completed?.animeList?.map((anime: any) => (
              <AnimeCard key={anime.animeId} {...anime} type="completed" isScrollable={false} />
            ))}
          </div>
        </section>

      </main>
    </>
  );
}
