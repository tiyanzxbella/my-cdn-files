import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function GenreList() {
  const [genres, setGenres] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/genre')
      .then((res) => res.json())
      .then((json) => {
        setGenres(json.data?.genreList || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold mb-8 text-center text-primary">Daftar Genre</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {genres.map((genre: any) => (
          <Link
            key={genre.genreId}
            to={`/genre/${genre.genreId}`}
            className="bg-card border border-border hover:border-primary hover:bg-primary/10 text-center py-4 rounded-xl shadow-sm transition-all duration-300 hover:-translate-y-1 glow-hover"
          >
            <span className="font-medium text-foreground">{genre.title}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
