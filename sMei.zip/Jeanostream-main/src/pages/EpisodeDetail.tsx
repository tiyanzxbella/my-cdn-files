import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Download, List, PlayCircle, Bookmark } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function EpisodeDetail() {
  const { slug } = useParams();
  const [episode, setEpisode] = useState<any>(null);
  const [animeDetail, setAnimeDetail] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [currentServerUrl, setCurrentServerUrl] = useState('');
  const [user, setUser] = useState<any>(null);
  const [isBookmarked, setIsBookmarked] = useState(false);

  useEffect(() => {
    if (supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setUser(session?.user ?? null);
      });
    }

    setLoading(true);
    fetch(`/api/episode/${slug}`)
      .then((res) => res.json())
      .then((json) => {
        setEpisode(json.data);
        setCurrentServerUrl(json.data?.defaultStreamingUrl || '');
        setLoading(false);
        
        // Record watch history
        if (supabase && user && json.data) {
          recordWatchHistory(json.data);
        }

        // Fetch anime details for the sidebar
        if (json.data?.animeId) {
          fetch(`/api/anime/${json.data.animeId}`)
            .then(res => res.json())
            .then(animeJson => {
              setAnimeDetail(animeJson.data);
              if (user) checkBookmark(user.id, json.data.animeId);
            });
        }
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [slug, user]);

  const recordWatchHistory = async (epData: any) => {
    if (!supabase || !user) return;
    
    try {
      await supabase.from('watch_history').upsert({
        user_id: user.id,
        anime_id: epData.animeId || epData.id,
        episode_id: slug,
        title: epData.title || animeDetail?.title || '',
        poster: animeDetail?.poster || epData.poster || 'https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg',
        watched_at: new Date().toISOString()
      }, { onConflict: 'user_id,episode_id' });
    } catch (e) {
      console.error('Failed to record watch history', e);
    }
  };

  const checkBookmark = async (userId: string, animeId: string) => {
    if (!supabase) return;
    const { data } = await supabase
      .from('bookmarks')
      .select('*')
      .eq('user_id', userId)
      .eq('anime_id', animeId)
      .single();
    
    if (data) setIsBookmarked(true);
  };

  const toggleBookmark = async () => {
    if (!supabase || !user || !episode) return;
    if (isBookmarked) {
      await supabase.from('bookmarks').delete().eq('user_id', user.id).eq('anime_id', episode.animeId);
      setIsBookmarked(false);
    } else {
      await supabase.from('bookmarks').insert([{ 
        user_id: user.id, 
        anime_id: episode.animeId, 
        title: animeDetail?.title || episode.title, 
        poster: animeDetail?.poster || '' 
      }]);
      setIsBookmarked(true);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!episode) return <div className="text-center py-12">Episode tidak ditemukan.</div>;

  return (
    <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        
        {/* Main Content (Left) */}
        <div className="w-full lg:w-[70%] xl:w-[75%]">
          {/* Video Player */}
          <div className="relative w-full pt-[56.25%] bg-black rounded-xl overflow-hidden shadow-lg border border-border mb-4">
            {currentServerUrl ? (
              <iframe
                src={currentServerUrl}
                allowFullScreen
                className="absolute top-0 left-0 w-full h-full"
                title={episode.title}
              ></iframe>
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                Video tidak tersedia.
              </div>
            )}
          </div>

          {/* Video Info */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-foreground mb-2">{episode.title}</h1>
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-4">
              <p className="text-muted-foreground text-sm">{episode.releaseTime}</p>
              
              <div className="flex items-center gap-2">
                <button 
                  onClick={toggleBookmark}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full font-medium transition-colors ${isBookmarked ? 'bg-accent/20 text-accent' : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'}`}
                >
                  <Bookmark size={18} fill={isBookmarked ? "currentColor" : "none"} /> 
                  {isBookmarked ? 'Tersimpan' : 'Simpan Anime'}
                </button>
              </div>
            </div>
          </div>

          {/* Anime Details Card */}
          {animeDetail && (
            <div className="bg-card rounded-xl border border-border p-4 mb-8 flex gap-4">
              <img src={animeDetail.poster} alt={animeDetail.title} className="w-24 h-32 object-cover rounded-lg" referrerPolicy="no-referrer" />
              <div>
                <h3 className="font-bold text-lg mb-1">{animeDetail.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{animeDetail.synopsis?.paragraphs?.[0]}</p>
                <Link to={`/anime/${episode.animeId}`} className="text-primary text-sm font-medium hover:underline">
                  Lihat Detail Anime
                </Link>
              </div>
            </div>
          )}

          {/* Download Links */}
          {episode.downloadUrl?.formats && (
            <div className="bg-card rounded-xl border border-border p-6 mb-8">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Download className="text-primary" size={20} /> Download Episode
              </h3>
              <div className="space-y-4">
                {episode.downloadUrl.formats.map((format: any) => (
                  <div key={format.title} className="space-y-2">
                    <h4 className="font-semibold text-sm text-accent">{format.title}</h4>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {format.qualities.map((quality: any) => (
                        <div key={quality.title} className="bg-background border border-border rounded-lg p-3">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium text-sm">{quality.title}</span>
                            <span className="text-xs text-muted-foreground">{quality.size}</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {quality.urls.map((urlObj: any) => (
                              <a
                                key={urlObj.title}
                                href={urlObj.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[10px] bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground px-2 py-1 rounded transition-colors"
                              >
                                {urlObj.title}
                              </a>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar (Right) */}
        <div className="w-full lg:w-[30%] xl:w-[25%] space-y-4">
          <div className="bg-card rounded-xl border border-border p-4">
            <h3 className="font-bold text-lg mb-4">Episode Lainnya</h3>
            
            {/* Prev/Next Quick Nav */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              <Link
                to={episode.hasPrevEpisode ? `/episode/${episode.prevEpisode?.episodeId}` : '#'}
                className={`flex flex-col items-center justify-center p-3 rounded-lg text-center transition-colors ${
                  episode.hasPrevEpisode ? 'bg-secondary hover:bg-secondary/80 text-secondary-foreground' : 'bg-muted text-muted-foreground cursor-not-allowed opacity-50'
                }`}
              >
                <ChevronLeft size={20} className="mb-1" />
                <span className="text-xs font-medium">Sebelumnya</span>
              </Link>
              <Link
                to={episode.hasNextEpisode ? `/episode/${episode.nextEpisode?.episodeId}` : '#'}
                className={`flex flex-col items-center justify-center p-3 rounded-lg text-center transition-colors ${
                  episode.hasNextEpisode ? 'bg-secondary hover:bg-secondary/80 text-secondary-foreground' : 'bg-muted text-muted-foreground cursor-not-allowed opacity-50'
                }`}
              >
                <ChevronRight size={20} className="mb-1" />
                <span className="text-xs font-medium">Selanjutnya</span>
              </Link>
            </div>

            {/* Episode List */}
            {animeDetail?.episodeList ? (
              <div className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar pr-2">
                {animeDetail.episodeList.map((ep: any) => {
                  const isActive = ep.episodeId === slug;
                  return (
                    <Link 
                      key={ep.episodeId} 
                      to={`/episode/${ep.episodeId}`}
                      className={`flex items-start gap-3 p-2 rounded-lg transition-colors ${isActive ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted'}`}
                    >
                      <div className="mt-1">
                        {isActive ? <PlayCircle size={16} className="text-primary" /> : <PlayCircle size={16} className="text-muted-foreground" />}
                      </div>
                      <div>
                        <p className={`text-sm font-medium line-clamp-2 ${isActive ? 'text-primary' : 'text-foreground'}`}>{ep.title}</p>
                        <p className="text-xs text-muted-foreground mt-1">{ep.date}</p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-sm text-muted-foreground">
                Memuat daftar episode...
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
