import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Download } from 'lucide-react';

export default function BatchDetail() {
  const { slug } = useParams();
  const [batch, setBatch] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/batch/${slug}`)
      .then((res) => res.json())
      .then((json) => {
        setBatch(json.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [slug]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!batch) return <div className="text-center py-12">Batch tidak ditemukan.</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="bg-card rounded-2xl border border-border p-6 shadow-xl">
        <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-6 text-center">{batch.title}</h1>
        
        {batch.downloadUrl?.formats && (
          <div className="space-y-6">
            {batch.downloadUrl.formats.map((format: any) => (
              <div key={format.title} className="space-y-4">
                <h4 className="font-semibold text-lg text-accent border-b border-border pb-2">{format.title}</h4>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {format.qualities.map((quality: any) => (
                    <div key={quality.title} className="bg-background border border-border rounded-xl p-4 hover:border-primary transition-colors">
                      <div className="flex justify-between items-center mb-3">
                        <span className="font-medium text-foreground">{quality.title}</span>
                        <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-md">{quality.size}</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {quality.urls.map((urlObj: any) => (
                          <a
                            key={urlObj.title}
                            href={urlObj.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground px-2 py-1 rounded transition-colors flex items-center gap-1"
                          >
                            <Download size={12} /> {urlObj.title}
                          </a>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
