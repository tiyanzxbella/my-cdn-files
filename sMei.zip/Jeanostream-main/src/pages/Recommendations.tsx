import { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { AnimeCard } from '../components/AnimeCard';

export default function Recommendations() {
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          fetchRecommendations(session.user.id);
        } else {
          setLoading(false);
          setError('Silakan login untuk melihat rekomendasi yang dipersonalisasi.');
        }
      });
    } else {
      setLoading(false);
      setError('Supabase belum dikonfigurasi.');
    }
  }, []);

  const fetchRecommendations = async (userId: string) => {
    setLoading(true);
    try {
      // 1. Get user's watch history
      const { data: history } = await supabase
        .from('watch_history')
        .select('title')
        .eq('user_id', userId)
        .order('last_watched_at', { ascending: false })
        .limit(20);

      // 2. Get user's bookmarks
      const { data: bookmarks } = await supabase
        .from('bookmarks')
        .select('title')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      const historyTitles = history?.map(h => h.title) || [];
      const bookmarkTitles = bookmarks?.map(b => b.title) || [];
      const combinedTitles = [...new Set([...historyTitles, ...bookmarkTitles])];

      if (combinedTitles.length === 0) {
        setLoading(false);
        setError('Belum ada cukup data. Tonton atau simpan beberapa anime agar AI dapat memberikan rekomendasi.');
        return;
      }

      // 3. Call our backend API to get Gemini recommendations
      const response = await fetch('/api/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ watchedAnime: combinedTitles })
      });

      if (!response.ok) throw new Error('Failed to fetch recommendations');
      
      const data = await response.json();
      setRecommendations(data.recommendations || []);
    } catch (err) {
      console.error(err);
      setError('Gagal memuat rekomendasi AI. Silakan coba lagi nanti.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-3 mb-8 border-b border-border pb-4">
        <Sparkles className="text-yellow-400" size={32} />
        <h1 className="text-3xl font-bold text-foreground">Rekomendasi AI</h1>
      </div>
      
      {loading ? (
        <div className="flex flex-col items-center justify-center min-h-[40vh] gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          <p className="text-muted-foreground animate-pulse">AI sedang menganalisis selera Anda...</p>
        </div>
      ) : error ? (
        <div className="bg-card border border-border rounded-xl p-8 text-center max-w-2xl mx-auto mt-12">
          <p className="text-muted-foreground text-lg">{error}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recommendations.map((anime, idx) => (
            <div key={idx} className="bg-card rounded-2xl overflow-hidden border border-border shadow-lg hover:shadow-xl transition-all hover:border-primary/50 group flex flex-col h-full">
              <div className="p-6 flex-grow">
                <h3 className="font-bold text-xl mb-3 group-hover:text-primary transition-colors">{anime.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">{anime.reason}</p>
              </div>
              <div className="px-6 pb-6 mt-auto">
                <a 
                  href={`/search/${encodeURIComponent(anime.title)}`} 
                  className="w-full text-center bg-primary/10 text-primary px-4 py-3 rounded-xl font-bold hover:bg-primary hover:text-primary-foreground transition-colors block"
                >
                  Cari Anime Ini
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
