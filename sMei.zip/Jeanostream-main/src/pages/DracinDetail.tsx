import { useState, useEffect, useRef } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import Hls from 'hls.js';
import { Play, Bookmark } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function DracinDetail() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const source = searchParams.get('source') || 'freereels';
  
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeEpisode, setActiveEpisode] = useState<any>(null);
  const [activeServer, setActiveServer] = useState<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [user, setUser] = useState<any>(null);
  const [isBookmarked, setIsBookmarked] = useState(false);

  useEffect(() => {
    if (supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setUser(session?.user ?? null);
        if (session?.user && id) {
          checkBookmark(session.user.id, id);
        }
      });
    }

    setLoading(true);
    fetch(`/api/dracin/detail/${id}?source=${source}`)
      .then(res => res.json())
      .then(json => {
        setData(json);
        if (json.episodeList && json.episodeList.length > 0) {
          setActiveEpisode(json.episodeList[0]);
          if (json.episodeList[0].servers && json.episodeList[0].servers.length > 0) {
             setActiveServer(json.episodeList[0].servers[0]);
          }
        }
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [id, source]);

  useEffect(() => {
    let hls: Hls | null = null;
    
    if (activeEpisode && !activeServer && videoRef.current) {
      const videoSrc = activeEpisode.h264Url || activeEpisode.h265Url;
      const video = videoRef.current;
      
      if (videoSrc) {
        if (Hls.isSupported()) {
          hls = new Hls();
          hls.loadSource(videoSrc);
          hls.attachMedia(video);
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = videoSrc;
        }
      }
    }
    
    return () => {
      if (hls) {
        hls.destroy();
      }
    };
  }, [activeEpisode, activeServer]);

  const checkBookmark = async (userId: string, dramaId: string) => {
    if (!supabase) return;
    const { data } = await supabase
      .from('bookmarks')
      .select('*')
      .eq('user_id', userId)
      .eq('anime_id', dramaId)
      .single();
    
    if (data) setIsBookmarked(true);
  };

  const toggleBookmark = async () => {
    if (!supabase) {
      alert('Fitur bookmark tidak tersedia karena konfigurasi Supabase belum diatur.');
      return;
    }

    if (!user) {
      alert('Silakan login untuk menyimpan bookmark.');
      return;
    }

    if (!id || !data) return;

    if (isBookmarked) {
      await supabase
        .from('bookmarks')
        .delete()
        .eq('user_id', user.id)
        .eq('anime_id', id);
      setIsBookmarked(false);
    } else {
      await supabase
        .from('bookmarks')
        .insert([{ 
          user_id: user.id, 
          anime_id: id, 
          title: data.title, 
          poster: data.poster 
        }]);
      setIsBookmarked(true);
    }
  };

  const recordWatchHistory = async (epData: any) => {
    if (!supabase || !user || !id) return;
    
    try {
      await supabase.from('watch_history').upsert({
        user_id: user.id,
        anime_id: id,
        episode_id: epData.id,
        title: data?.title || '',
        poster: data?.poster || '',
        watched_at: new Date().toISOString()
      }, { onConflict: 'user_id,episode_id' });
    } catch (e) {
      console.error('Failed to record watch history', e);
    }
  };

  useEffect(() => {
    if (activeEpisode && data) {
       recordWatchHistory(activeEpisode);
    }
  }, [activeEpisode, data, user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-16 h-16 rounded-full border-4 border-red-500 border-t-transparent animate-spin"></div>
      </div>
    );
  }

  if (!data) return <div className="text-center py-12">Gagal memuat detail dracin.</div>;

  return (
    <div className="min-h-screen bg-background">
      {/* Player Section */}
      <div className="w-full bg-black aspect-video max-h-[70vh] flex items-center justify-center relative shadow-2xl">
        {activeServer ? (
          <iframe 
            src={activeServer.url} 
            allowFullScreen 
            className="w-full h-full border-0"
          ></iframe>
        ) : (
          <video 
            ref={videoRef}
            controls 
            className="w-full h-full outline-none"
            poster={activeEpisode?.poster || data.poster}
          >
            {activeEpisode?.subtitles?.map((sub: any, idx: number) => (
              <track key={idx} label={sub.name} kind="subtitles" srcLang={sub.language} src={sub.url} default={idx === 0} />
            ))}
          </video>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col lg:flex-row gap-8">
        <div className="flex-grow">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl md:text-3xl font-bold font-display text-white">{data.title}</h1>
              <span className="bg-red-500/20 text-red-400 px-2.5 py-1 rounded-md text-xs font-bold border border-red-500/30">
                {source.toUpperCase()}
              </span>
            </div>
            
            <button 
              onClick={toggleBookmark}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-sm transition-all sm:self-auto self-start ${
                isBookmarked 
                  ? 'bg-red-500/20 text-red-400 border border-red-500/50' 
                  : 'bg-white/10 text-white/80 hover:bg-white/20 border border-white/10'
              }`}
            >
              <Bookmark size={18} fill={isBookmarked ? "currentColor" : "none"} />
              {isBookmarked ? 'Tersimpan' : 'Simpan Dracin'}
            </button>
          </div>
          
          {activeEpisode && (
            <h2 className="text-xl text-white/80 font-medium mb-6 flex items-center gap-2">
               <span className="w-2 h-2 rounded-full bg-red-500"></span>
               Sedang diputar: {activeEpisode.title}
            </h2>
          )}

          {activeEpisode?.servers && activeEpisode.servers.length > 0 && (
             <div className="mb-8">
                <h3 className="text-sm font-bold text-white/50 uppercase tracking-widest mb-3">Pilih Server</h3>
                <div className="flex flex-wrap gap-2">
                   {activeEpisode.servers.map((server: any, idx: number) => (
                      <button 
                        key={idx}
                        onClick={() => setActiveServer(server)}
                        className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                          activeServer?.name === server.name 
                            ? 'bg-red-500 text-white' 
                            : 'bg-white/5 text-white/70 hover:bg-white/10'
                        }`}
                      >
                         {server.name}
                      </button>
                   ))}
                </div>
             </div>
          )}

          <div className="bg-card border border-border rounded-2xl p-6 mb-8 hover:border-red-500/30 transition-colors">
            <h3 className="text-sm font-bold text-white/50 uppercase tracking-widest mb-3">Sinopsis</h3>
            <p className="text-white/80 leading-relaxed text-sm md:text-base">
              {data.description || 'Sinopsis tidak tersedia.'}
            </p>
          </div>
        </div>

        {/* Sidebar Episodes */}
        {data.episodeList && data.episodeList.length > 1 && (
          <div className="lg:w-80 shrink-0">
            <div className="bg-card border border-border rounded-xl p-4 sticky top-6 shadow-xl">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-white">
                <Play className="text-red-500" size={18} fill="currentColor" />
                Daftar Episode
              </h3>
              <div className="max-h-[60vh] overflow-y-auto pr-2 no-scrollbar flex flex-col gap-2">
                {data.episodeList.map((ep: any) => (
                  <button
                    key={ep.id}
                    onClick={() => {
                        setActiveEpisode(ep);
                        if (ep.servers && ep.servers.length > 0) setActiveServer(ep.servers[0]);
                        else setActiveServer(null);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`flex items-start gap-3 p-3 rounded-xl transition-all text-left ${
                      activeEpisode?.id === ep.id 
                        ? 'bg-red-500/20 border-red-500/50 border' 
                        : 'bg-background border border-white/5 hover:border-red-500/30 hover:bg-white/5'
                    }`}
                  >
                    <div className="relative w-20 aspect-video rounded-md overflow-hidden shrink-0 bg-white/5">
                      {ep.poster && <img src={ep.poster} alt={ep.title} className="w-full h-full object-cover" />}
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                         <Play size={14} className="text-white opacity-70" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className={`text-sm font-bold line-clamp-2 ${activeEpisode?.id === ep.id ? 'text-red-400' : 'text-white'}`}>
                        {ep.title}
                      </h4>
                      {ep.duration && <span className="text-[10px] text-white/40 mt-1 block">{Math.floor(ep.duration/60)}m</span>}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
