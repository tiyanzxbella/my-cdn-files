import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { AnimeCard } from '../components/AnimeCard';
import { BookmarkMinus } from 'lucide-react';

export default function Bookmarks() {
  const [bookmarks, setBookmarks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const fetchBookmarks = async () => {
      if (!supabase) {
        setLoading(false);
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);

      if (session?.user) {
        const { data, error } = await supabase
          .from('bookmarks')
          .select('*')
          .eq('user_id', session.user.id)
          .order('created_at', { ascending: false });

        if (!error && data) {
          setBookmarks(data);
        }
      }
      setLoading(false);
    };

    fetchBookmarks();
  }, []);

  const removeBookmark = async (animeId: string) => {
    if (!user || !supabase) return;
    
    const { error } = await supabase
      .from('bookmarks')
      .delete()
      .eq('user_id', user.id)
      .eq('anime_id', animeId);

    if (!error) {
      setBookmarks(bookmarks.filter(b => b.anime_id !== animeId));
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <h1 className="text-3xl font-bold mb-4 text-foreground">Bookmarks</h1>
        <p className="text-muted-foreground">Silakan login untuk melihat daftar bookmark Anda.</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold mb-8 text-foreground border-l-4 border-primary pl-4">Anime Tersimpan</h1>
      
      {bookmarks.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          Belum ada anime yang disimpan.
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
          {bookmarks.map((bookmark) => {
            const isDracin = bookmark.anime_id.length < 15 || !isNaN(Number(bookmark.anime_id)); // Basic heuristic for Dracin ID vs Slug
            return (
              <div key={bookmark.id} className="relative group">
                <AnimeCard
                  title={bookmark.title}
                  poster={bookmark.poster}
                  animeId={bookmark.anime_id}
                  isDracin={isDracin}
                />
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    removeBookmark(bookmark.anime_id);
                  }}
                  className="absolute top-2 right-2 bg-red-500/80 hover:bg-red-500 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
                  title="Hapus Bookmark"
                >
                  <BookmarkMinus size={16} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
