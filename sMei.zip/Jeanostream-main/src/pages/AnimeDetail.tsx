import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Play, Bookmark, Star, Calendar, Clock, Tv, Film } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function AnimeDetail() {
  const { slug } = useParams();
  const [anime, setAnime] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [user, setUser] = useState<any>(null);
  
  // Reviews state
  const [reviews, setReviews] = useState<any[]>([]);
  const [newReview, setNewReview] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    if (supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          checkBookmark(session.user.id);
        }
      });
    }

    fetch(`/api/anime/${slug}`)
      .then((res) => res.json())
      .then((json) => {
        setAnime(json.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
      
    fetchReviews();
  }, [slug]);

  const fetchReviews = async () => {
    if (!supabase) return;
    const { data } = await supabase
      .from('reviews')
      .select('*, user_profiles(username, avatar_url)')
      .eq('anime_id', slug)
      .order('created_at', { ascending: false });
    
    if (data) setReviews(data);
  };

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase || !user) return;
    
    setSubmittingReview(true);
    const { error } = await supabase
      .from('reviews')
      .insert([
        {
          user_id: user.id,
          anime_id: slug,
          rating: newRating,
          review_text: newReview
        }
      ]);
      
    setSubmittingReview(false);
    if (!error) {
      setNewReview('');
      setNewRating(5);
      fetchReviews();
    } else {
      alert('Gagal mengirim ulasan. Pastikan tabel reviews sudah dibuat.');
    }
  };

  const checkBookmark = async (userId: string) => {
    if (!supabase) return;
    const { data } = await supabase
      .from('bookmarks')
      .select('*')
      .eq('user_id', userId)
      .eq('anime_id', slug)
      .single();
    
    if (data) setIsBookmarked(true);
  };

  const toggleBookmark = async () => {
    if (!supabase) {
      alert('Fitur bookmark tidak tersedia karena konfigurasi Supabase belum diatur. Silakan tambahkan di menu Secrets.');
      return;
    }

    if (!user) {
      alert('Silakan login untuk menyimpan bookmark.');
      return;
    }

    if (isBookmarked) {
      await supabase
        .from('bookmarks')
        .delete()
        .eq('user_id', user.id)
        .eq('anime_id', slug);
      setIsBookmarked(false);
    } else {
      await supabase
        .from('bookmarks')
        .insert([{ 
          user_id: user.id, 
          anime_id: slug, 
          title: anime.title, 
          poster: anime.poster 
        }]);
      setIsBookmarked(true);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!anime) return <div className="text-center py-12">Anime tidak ditemukan.</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Poster & Actions */}
        <div className="w-full md:w-1/3 lg:w-1/4 flex-shrink-0">
          <div className="bg-card rounded-2xl overflow-hidden shadow-2xl border border-border sticky top-24">
            <img 
              src={anime.poster} 
              alt={anime.title} 
              className="w-full h-auto object-cover aspect-[3/4]"
              referrerPolicy="no-referrer"
            />
            <div className="p-4 space-y-3">
              {anime.episodeList && anime.episodeList.length > 0 && (
                <Link 
                  to={`/episode/${anime.episodeList[0].episodeId}`}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all glow-hover"
                >
                  <Play size={20} fill="currentColor" /> Tonton Sekarang
                </Link>
              )}
              <button 
                onClick={toggleBookmark}
                className={`w-full font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all border ${isBookmarked ? 'bg-accent/20 text-accent border-accent' : 'bg-card text-foreground border-border hover:bg-muted'}`}
              >
                <Bookmark size={20} fill={isBookmarked ? "currentColor" : "none"} /> 
                {isBookmarked ? 'Tersimpan' : 'Simpan Bookmark'}
              </button>
            </div>
          </div>
        </div>

        {/* Info */}
        <div className="w-full md:w-2/3 lg:w-3/4 space-y-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">{anime.title}</h1>
            {anime.japanese && <p className="text-muted-foreground text-lg mb-4">{anime.japanese}</p>}
            
            <div className="flex flex-wrap gap-2 mb-6">
              {anime.genreList?.map((genre: any) => (
                <Link 
                  key={genre.genreId} 
                  to={`/genre/${genre.genreId}`}
                  className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium hover:bg-primary hover:text-primary-foreground transition-colors"
                >
                  {genre.title}
                </Link>
              ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
              <div className="bg-card p-4 rounded-xl border border-border flex flex-col items-center justify-center text-center">
                <Star className="text-yellow-400 mb-1" size={24} />
                <span className="text-sm text-muted-foreground">Score</span>
                <span className="font-bold text-lg">{anime.score || '?'}</span>
              </div>
              <div className="bg-card p-4 rounded-xl border border-border flex flex-col items-center justify-center text-center">
                <Tv className="text-primary mb-1" size={24} />
                <span className="text-sm text-muted-foreground">Status</span>
                <span className="font-bold text-lg">{anime.status}</span>
              </div>
              <div className="bg-card p-4 rounded-xl border border-border flex flex-col items-center justify-center text-center">
                <Film className="text-accent mb-1" size={24} />
                <span className="text-sm text-muted-foreground">Type</span>
                <span className="font-bold text-lg">{anime.type}</span>
              </div>
              <div className="bg-card p-4 rounded-xl border border-border flex flex-col items-center justify-center text-center">
                <Clock className="text-green-500 mb-1" size={24} />
                <span className="text-sm text-muted-foreground">Duration</span>
                <span className="font-bold text-lg">{anime.duration}</span>
              </div>
            </div>

            <div className="bg-card p-6 rounded-2xl border border-border space-y-4">
              <h3 className="text-xl font-bold border-b border-border pb-2">Sinopsis</h3>
              <div className="text-muted-foreground leading-relaxed space-y-2">
                {anime.synopsis?.paragraphs?.map((p: string, i: number) => (
                  <p key={i}>{p}</p>
                ))}
                {(!anime.synopsis?.paragraphs || anime.synopsis.paragraphs.length === 0) && (
                  <p>Sinopsis belum tersedia.</p>
                )}
              </div>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            <div className="bg-card p-6 rounded-2xl border border-border">
              <h3 className="text-xl font-bold border-b border-border pb-2 mb-4">Informasi</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex justify-between"><span className="text-muted-foreground">Aired</span> <span className="font-medium text-right">{anime.aired}</span></li>
                <li className="flex justify-between"><span className="text-muted-foreground">Studios</span> <span className="font-medium text-right">{anime.studios}</span></li>
                <li className="flex justify-between"><span className="text-muted-foreground">Producers</span> <span className="font-medium text-right">{anime.producers}</span></li>
                <li className="flex justify-between"><span className="text-muted-foreground">Episodes</span> <span className="font-medium text-right">{anime.episodes}</span></li>
              </ul>
            </div>
            
            {anime.batch && (
              <div className="bg-card p-6 rounded-2xl border border-border flex flex-col justify-center items-center text-center">
                <h3 className="text-xl font-bold mb-2">Download Batch</h3>
                <p className="text-sm text-muted-foreground mb-4">Download semua episode sekaligus.</p>
                <Link 
                  to={`/batch/${anime.batch.batchId}`}
                  className="bg-accent hover:bg-accent/90 text-white font-bold py-2 px-6 rounded-lg transition-colors"
                >
                  Download Batch
                </Link>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <span className="w-2 h-6 bg-primary rounded-full"></span>
              Daftar Episode
            </h3>
            <div className="bg-card rounded-2xl border border-border overflow-hidden">
              <ul className="divide-y divide-border max-h-[400px] overflow-y-auto custom-scrollbar">
                {anime.episodeList?.map((ep: any) => (
                  <li key={ep.episodeId} className="hover:bg-muted/50 transition-colors">
                    <Link to={`/episode/${ep.episodeId}`} className="flex items-center justify-between p-4">
                      <span className="font-medium text-foreground">{ep.title}</span>
                      <span className="text-xs text-muted-foreground bg-background px-2 py-1 rounded-md">{ep.date}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Reviews Section */}
          <div className="mt-12">
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <span className="w-2 h-6 bg-accent rounded-full"></span>
              Ulasan & Rating
            </h3>
            
            {user ? (
              <form onSubmit={submitReview} className="bg-card p-6 rounded-2xl border border-border mb-8">
                <h4 className="font-bold mb-4">Tulis Ulasan Anda</h4>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-sm text-muted-foreground">Rating:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewRating(star)}
                        className="focus:outline-none"
                      >
                        <Star 
                          size={24} 
                          className={star <= newRating ? "text-yellow-400 fill-yellow-400" : "text-muted-foreground"} 
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <textarea
                  value={newReview}
                  onChange={(e) => setNewReview(e.target.value)}
                  placeholder="Bagaimana pendapat Anda tentang anime ini?"
                  className="w-full bg-background border border-border rounded-xl p-4 mb-4 focus:outline-none focus:border-primary min-h-[100px]"
                  required
                ></textarea>
                <button
                  type="submit"
                  disabled={submittingReview}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-xl font-medium transition-colors disabled:opacity-50"
                >
                  {submittingReview ? 'Mengirim...' : 'Kirim Ulasan'}
                </button>
              </form>
            ) : (
              <div className="bg-card p-6 rounded-2xl border border-border mb-8 text-center">
                <p className="text-muted-foreground mb-4">Silakan login untuk memberikan ulasan.</p>
              </div>
            )}

            <div className="space-y-4">
              {reviews.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">Belum ada ulasan untuk anime ini.</p>
              ) : (
                reviews.map((review) => (
                  <div key={review.id} className="bg-card p-6 rounded-2xl border border-border">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                          {review.user_profiles?.avatar_url ? (
                            <img src={review.user_profiles.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
                          ) : (
                            <span className="font-bold text-muted-foreground">
                              {(review.user_profiles?.username || 'U')[0].toUpperCase()}
                            </span>
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{review.user_profiles?.username || 'User'}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(review.created_at).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 bg-background px-2 py-1 rounded-lg border border-border">
                        <Star size={14} className="text-yellow-400 fill-yellow-400" />
                        <span className="text-sm font-bold">{review.rating}</span>
                      </div>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{review.review_text}</p>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
