import { useState, useEffect } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import { AnimeCard } from '../components/AnimeCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface AnimeListProps {
  type: 'ongoing' | 'completed' | 'genre' | 'search';
}

export default function AnimeList({ type }: AnimeListProps) {
  const { slug, keyword } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const page = parseInt(searchParams.get('page') || '1', 10);
  
  const [animeList, setAnimeList] = useState<any[]>([]);
  const [dracinList, setDracinList] = useState<any[]>([]);
  const [filteredList, setFilteredList] = useState<any[]>([]);
  const [pagination, setPagination] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  useEffect(() => {
    setLoading(true);
    let url = '';
    
    if (type === 'ongoing') {
      url = `/api/ongoing-anime?page=${page}`;
      setTitle('Anime Ongoing');
    } else if (type === 'completed') {
      url = `/api/complete-anime?page=${page}`;
      setTitle('Anime Completed');
    } else if (type === 'genre') {
      url = `/api/genre/${slug}?page=${page}`;
      setTitle(`Genre: ${slug?.replace(/-/g, ' ').toUpperCase()}`);
    } else if (type === 'search') {
      url = `/api/search/${keyword}`;
      setTitle(`Pencarian: ${keyword}`);
    }

    const fetchAnime = fetch(url).then(res => res.json());
    
    let fetchDracin: Promise<any> | null = null;
    if (type === 'search') {
      fetchDracin = fetch(`/api/dracin/search/${keyword}`).then(res => res.json());
    }

    Promise.all([fetchAnime, fetchDracin])
      .then(([animeJson, dracinJson]) => {
        let list = [];
        if (type === 'search') {
          list = animeJson.data?.animeList || [];
        } else if (type === 'genre') {
          list = animeJson.data?.animeList || [];
          setPagination(animeJson.pagination);
        } else if (type === 'ongoing') {
          list = animeJson.data?.animeList || [];
          setPagination(animeJson.pagination);
        } else if (type === 'completed') {
          list = animeJson.data?.animeList || [];
          setPagination(animeJson.pagination);
        }
        setAnimeList(list);
        setFilteredList(list);

        if (dracinJson) {
          const combinedDracin = [...(dracinJson.freereels?.items || []), ...(dracinJson.klikxxi || [])];
          setDracinList(combinedDracin);
        } else {
          setDracinList([]);
        }
        
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [type, slug, keyword, page]);

  useEffect(() => {
    if (statusFilter === 'All') {
      setFilteredList(animeList);
    } else {
      setFilteredList(animeList.filter(anime => 
        anime.status?.toLowerCase() === statusFilter.toLowerCase() || 
        (type === 'ongoing' && statusFilter === 'Ongoing') ||
        (type === 'completed' && statusFilter === 'Completed')
      ));
    }
  }, [statusFilter, animeList, type]);

  const handlePageChange = (newPage: number) => {
    setSearchParams({ page: newPage.toString() });
    window.scrollTo(0, 0);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <h1 className="text-3xl font-bold text-foreground border-l-4 border-primary pl-4">{title}</h1>
        
        {type === 'search' && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Status:</span>
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-card border border-border rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-primary"
            >
              <option value="All">Semua</option>
              <option value="Ongoing">Ongoing</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        )}
      </div>

      {type === 'search' && dracinList.length > 0 && (
        <div className="mb-12">
           <h2 className="text-2xl font-bold text-white mb-6 border-l-4 border-red-500 pl-4">Hasil Dracin</h2>
           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {dracinList.map((drama: any) => (
                <div key={drama.id} className={`tilt-card-wrapper w-full`}>
                  <Link to={`/dracin/${drama.id}?source=${drama.source}`} className="tilt-card relative aspect-[3/4] w-full rounded-2xl md:rounded-3xl overflow-hidden cursor-pointer group bg-darkCard border border-white/5 shadow-2xl block">
                    <img src={drama.poster} alt={drama.title} loading="lazy" referrerPolicy="no-referrer" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-90 group-hover:opacity-100 transition-opacity"></div>
                    {drama.score && <div className="absolute top-3 right-3 bg-yellow-500/90 backdrop-blur px-2 py-1 rounded-lg text-[11px] font-black text-black shadow-[0_0_15px_rgba(234,179,8,0.5)] flex items-center gap-1 tilt-card-content"><i className="fa-solid fa-star text-[9px]"></i> {drama.score}</div>}
                    <div className="absolute bottom-0 left-0 w-full p-4 tilt-card-content pointer-events-none z-20">
                      <div className="text-[10px] md:text-xs font-bold text-red-400 mb-1.5 uppercase tracking-wider bg-red-900/30 w-fit px-2 py-0.5 rounded border border-red-500/20">EP {drama.episodes || '?'}</div>
                      <h3 className="font-bold text-sm md:text-base text-white line-clamp-2 leading-tight">{drama.title}</h3>
                    </div>
                  </Link>
                </div>
              ))}
           </div>
        </div>
      )}

      {type === 'search' && <h2 className="text-2xl font-bold text-white mb-6 border-l-4 border-primary pl-4">Hasil Anime</h2>}
      
      {filteredList.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">Tidak ada anime ditemukan.</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
          {filteredList.map((anime: any) => (
            <AnimeCard
              key={anime.animeId}
              title={anime.title}
              poster={anime.poster}
              animeId={anime.animeId}
              episodes={anime.episodes}
              score={anime.score}
              status={type === 'ongoing' ? 'Ongoing' : type === 'completed' ? 'Completed' : anime.status}
            />
          ))}
        </div>
      )}

      {pagination && pagination.totalPages > 1 && (
        <div className="flex justify-center items-center mt-12 gap-2">
          <button
            onClick={() => handlePageChange(page - 1)}
            disabled={!pagination.hasPrevPage}
            className="p-2 rounded-md bg-card border border-border text-foreground disabled:opacity-50 hover:bg-primary hover:text-primary-foreground transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          <span className="px-4 py-2 bg-card border border-border rounded-md font-medium">
            Halaman {pagination.currentPage} dari {pagination.totalPages}
          </span>
          <button
            onClick={() => handlePageChange(page + 1)}
            disabled={!pagination.hasNextPage}
            className="p-2 rounded-md bg-card border border-border text-foreground disabled:opacity-50 hover:bg-primary hover:text-primary-foreground transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      )}
    </div>
  );
}
