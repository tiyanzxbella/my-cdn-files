/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import Home from './pages/Home';
import Schedule from './pages/Schedule';
import GenreList from './pages/GenreList';
import AnimeList from './pages/AnimeList';
import AnimeDetail from './pages/AnimeDetail';
import EpisodeDetail from './pages/EpisodeDetail';
import Bookmarks from './pages/Bookmarks';
import BatchDetail from './pages/BatchDetail';
import Profile from './pages/Profile';
import Recommendations from './pages/Recommendations';
import DracinDetail from './pages/DracinDetail';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-background text-foreground">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/dracin/:id" element={<DracinDetail />} />
            <Route path="/jadwal" element={<Schedule />} />
            <Route path="/genre" element={<GenreList />} />
            <Route path="/genre/:slug" element={<AnimeList type="genre" />} />
            <Route path="/ongoing" element={<AnimeList type="ongoing" />} />
            <Route path="/completed" element={<AnimeList type="completed" />} />
            <Route path="/search/:keyword" element={<AnimeList type="search" />} />
            <Route path="/anime/:slug" element={<AnimeDetail />} />
            <Route path="/episode/:slug" element={<EpisodeDetail />} />
            <Route path="/batch/:slug" element={<BatchDetail />} />
            <Route path="/bookmarks" element={<Bookmarks />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/recommendations" element={<Recommendations />} />
          </Routes>
        </main>
        <footer className="relative w-full border-t border-white/5 bg-[#030303] pt-20 pb-40 lg:pb-32 overflow-hidden mt-10">
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[200px] bg-purple-600/10 filter blur-[100px] rounded-[100%] pointer-events-none"></div>
          <div className="container mx-auto px-6 md:px-10 relative z-10">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 mb-16">
              <div className="col-span-2 md:col-span-1">
                <a href="#" className="text-2xl font-display font-bold text-white flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 rounded-lg ai-gradient flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.5)]">
                    <i className="fa-solid fa-play text-xs text-white"></i>
                  </div> 
                  JEANOSTREAM
                </a>
                <p className="text-sm text-white/40 leading-relaxed font-medium mb-6 max-w-xs">Platform streaming anime masa depan dengan antarmuka premium dan tanpa iklan mengganggu.</p>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white tracking-widest uppercase mb-6">RESOURCES</h3>
                <ul className="flex flex-col gap-4 text-sm font-medium text-white/50">
                  <li><a href="/ongoing" className="hover:text-white">Daftar Anime</a></li>
                  <li><a href="/jadwal" className="hover:text-white">Jadwal Rilis</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white tracking-widest uppercase mb-6">FOLLOW US</h3>
                <ul className="flex flex-col gap-4 text-sm font-medium text-white/50">
                  <li><a href="https://tiktok.com/jeanoalexanderrr" className="hover:text-white">Tiktok</a></li>
                  <li><a href="https://instagram.com/jeanoalexander" className="hover:text-white">Instagram</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white tracking-widest uppercase mb-6">LEGAL</h3>
                <ul className="flex flex-col gap-4 text-sm font-medium text-white/50">
                  <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                  <li><a href="#" className="hover:text-white">DMCA</a></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
              <p className="text-sm text-white/40 font-medium text-center md:text-left">
                &copy; {new Date().getFullYear()} SVibe&trade;. All Rights Reserved.<br />
                <span className="text-[10px]">Crafted with <i className="fa-solid fa-heart text-pink-500 mx-0.5"></i> by Sanka Vollerei</span>
              </p>
              <div className="flex gap-5 text-white/40">
                <a href="#" className="hover:text-white transition-colors text-lg" aria-label="Facebook"><i className="fa-brands fa-facebook"></i></a>
                <a href="#" className="hover:text-white transition-colors text-lg" aria-label="Discord"><i className="fa-brands fa-discord"></i></a>
                <a href="#" className="hover:text-white transition-colors text-lg" aria-label="Twitter"><i className="fa-brands fa-x-twitter"></i></a>
              </div>
            </div>
          </div>
          <div className="footer-watermark">JEANO Streaming</div>
        </footer>
      </div>
    </Router>
  );
}

