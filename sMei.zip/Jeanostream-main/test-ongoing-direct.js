import fetch from 'node-fetch';

async function test() {
  try {
    const response = await fetch('https://www.sankavollerei.com/anime/ongoing-anime?page=1', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*'
      }
    });
    console.log('Status:', response.status);
    const text = await response.text();
    console.log('Body:', text.substring(0, 500));
  } catch (e) {
    console.error(e);
  }
}

test();
