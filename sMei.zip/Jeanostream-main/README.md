# AniStream - Anime Streaming App

A modern, responsive anime streaming application built with React, Vite, Tailwind CSS, and Node.js Express.

## Features
- View ongoing and completed anime
- Check daily release schedules
- Browse anime by genre
- Search anime by title
- View detailed anime information and episode lists
- Watch episodes directly in the app
- Download batch episodes
- User authentication and bookmarks using Supabase

## Setup & Installation

1. Install dependencies:
   ```bash
   npm install
   ```

2. Configure Environment Variables:
   Copy `.env.example` to `.env` and fill in your Supabase credentials.
   ```bash
   cp .env.example .env
   ```
   
   To get your Supabase credentials:
   - Go to [Supabase](https://supabase.com/) and create a new project.
   - Go to Project Settings -> API.
   - Copy the `Project URL` to `VITE_SUPABASE_URL`.
   - Copy the `anon` `public` key to `VITE_SUPABASE_ANON_KEY`.

3. Configure Supabase Database:
   Create the following tables in your Supabase project using the SQL Editor:

   ```sql
   -- 1. Bookmarks Table
   CREATE TABLE bookmarks (
     id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
     user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
     anime_id TEXT NOT NULL,
     title TEXT NOT NULL,
     poster TEXT NOT NULL,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
   );

   -- 2. Reviews Table
   CREATE TABLE reviews (
     id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
     user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
     anime_id TEXT NOT NULL,
     rating INTEGER CHECK (rating >= 1 AND rating <= 5),
     review_text TEXT,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
   );

   -- 3. Watch History Table
   CREATE TABLE watch_history (
     id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
     user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
     anime_id TEXT NOT NULL,
     episode_id TEXT NOT NULL,
     title TEXT NOT NULL,
     poster TEXT NOT NULL,
     watched_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
     UNIQUE(user_id, episode_id)
   );

   -- 4. User Profiles Table
   CREATE TABLE user_profiles (
     user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
     username TEXT,
     avatar_url TEXT,
     preferences JSONB DEFAULT '{}'::jsonb
   );

   -- Enable RLS
   ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;
   ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
   ALTER TABLE watch_history ENABLE ROW LEVEL SECURITY;
   ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

   -- Policies
   CREATE POLICY "Users can manage their own bookmarks" ON bookmarks FOR ALL USING (auth.uid() = user_id);
   CREATE POLICY "Reviews are viewable by everyone" ON reviews FOR SELECT USING (true);
   CREATE POLICY "Users can manage their own reviews" ON reviews FOR ALL USING (auth.uid() = user_id);
   CREATE POLICY "Users can manage their watch history" ON watch_history FOR ALL USING (auth.uid() = user_id);
   CREATE POLICY "Users can view all profiles" ON user_profiles FOR SELECT USING (true);
   CREATE POLICY "Users can manage their own profile" ON user_profiles FOR ALL USING (auth.uid() = user_id);
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

## Deployment

To deploy the application:

1. Build the project:
   ```bash
   npm run build
   ```

2. Start the production server:
   ```bash
   npm start
   ```

Note: Ensure that your deployment environment has the necessary environment variables configured (`VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`).
