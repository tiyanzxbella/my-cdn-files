import express from 'express';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { FreeReelsAPI, KlikXXIScraper } from './scrapers.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Simple in-memory cache
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

const freeReels = new FreeReelsAPI();
const klikxxi = new KlikXXIScraper();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  const API_BASE = 'https://www.sankavollerei.com/anime';
  
  // Initialize Gemini
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

  // Helper function to fetch and send response with caching
  const fetchAndSend = async (url: string, res: express.Response) => {
    try {
      // Check cache first
      const cached = cache.get(url);
      if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return res.json(cached.data);
      }

      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*'
        }
      });
      
      if (!response.ok) {
        if (response.status === 429 && cached) {
          // If rate limited but we have stale cache, return stale cache
          return res.json(cached.data);
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Check if we got the banned message
      if (data.status === "Forbidden" || data.message?.includes("permanently banned")) {
        throw new Error("API IP Ban");
      }

      // Save to cache
      cache.set(url, { data, timestamp: Date.now() });
      
      res.json(data);
    } catch (error) {
      console.error(`Error fetching ${url}:`, error);
      // Fallback to stale cache if available
      const cached = cache.get(url);
      if (cached) {
        console.log(`Falling back to stale cache for ${url}`);
        return res.json(cached.data);
      }

      // Mock Data Fallback for IP Ban
      if (url.includes('/anime/home')) {
        return res.json({
          data: {
            ongoing: {
              animeList: [
                { title: "Mock Ongoing Anime 1", animeId: "mock-1", poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg", episodes: "12", score: "8.5" },
                { title: "Mock Ongoing Anime 2", animeId: "mock-2", poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg", episodes: "24", score: "9.0" }
              ]
            },
            completed: {
              animeList: [
                { title: "Mock Completed Anime 1", animeId: "mock-c1", poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg", episodes: "12", score: "8.5" }
              ]
            }
          }
        });
      }

      if (url.includes('/anime/ongoing-anime')) {
        return res.json({
          data: {
            animeList: [
              { title: "Mock Ongoing Anime 1", animeId: "mock-1", poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg", episodes: "12", score: "8.5", status: "Ongoing" },
              { title: "Mock Ongoing Anime 2", animeId: "mock-2", poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg", episodes: "24", score: "9.0", status: "Ongoing" }
            ],
            pagination: { currentPage: 1, totalPages: 1, hasNextPage: false, hasPrevPage: false }
          }
        });
      }

      if (url.includes('/anime/complete-anime')) {
        return res.json({
          data: {
            animeList: [
              { title: "Mock Completed Anime 1", animeId: "mock-c1", poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg", episodes: "12", score: "8.5", status: "Completed" }
            ],
            pagination: { currentPage: 1, totalPages: 1, hasNextPage: false, hasPrevPage: false }
          }
        });
      }

      if (url.includes('/anime/search')) {
        return res.json({
          data: {
            animeList: [
              { title: "Mock Search Result", animeId: "mock-s1", poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg", episodes: "12", score: "8.5", status: "Completed" }
            ]
          }
        });
      }

      if (url.includes('/anime/episode/')) {
        return res.json({
          data: {
            title: "Mock Episode Title",
            animeId: "mock-1",
            releaseTime: "Just now",
            defaultStreamingUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
            hasPrevEpisode: false,
            hasNextEpisode: false
          }
        });
      }

      if (url.includes('/anime/') && !url.includes('/episode/') && !url.includes('/genre') && !url.includes('/search')) {
        return res.json({
          data: {
            title: "Mock Anime Detail",
            poster: "https://otakudesu.blog/wp-content/uploads/2020/05/Boruto-Sub-Indo.jpg",
            synopsis: { paragraphs: ["This is a mock synopsis because the API IP is banned."] },
            score: "10.0",
            status: "Ongoing",
            episodeList: [
              { title: "Episode 1", episodeId: "mock-ep-1", date: "Today" }
            ]
          }
        });
      }

      res.status(500).json({ error: 'Failed to fetch data' });
    }
  };

  // Dracin API Routes
  app.get('/api/dracin/home', async (req, res) => {
    try {
      const [dashboard, hotlist] = await Promise.all([
        freeReels.getDashboard(),
        freeReels.getHotlist()
      ]);
      res.json({ dashboard, hotlist });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/dracin/search/:keyword', async (req, res) => {
    try {
      // Search from FreeReels
      const frResults = await freeReels.search(req.params.keyword);
      // Fallback search from KlikXXI
      const kxResults = await klikxxi.search(req.params.keyword);
      res.json({
        freereels: frResults,
        klikxxi: kxResults
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/dracin/detail/:id', async (req, res) => {
    try {
      const id = req.params.id;
      const source = req.query.source as string;
      if (source === 'klikxxi') {
        const detail = await klikxxi.getDetail(id);
        res.json(detail);
      } else {
        const detail = await freeReels.getDramaInfo(id);
        res.json(detail);
      }
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Anime API Routes
  app.get('/api/home', (req, res) => fetchAndSend(`${API_BASE}/home`, res));
  app.get('/api/schedule', (req, res) => fetchAndSend(`${API_BASE}/schedule`, res));
  app.get('/api/anime/:slug', (req, res) => fetchAndSend(`${API_BASE}/anime/${req.params.slug}`, res));
  app.get('/api/episode/:slug', (req, res) => fetchAndSend(`${API_BASE}/episode/${req.params.slug}`, res));
  app.get('/api/genre', (req, res) => fetchAndSend(`${API_BASE}/genre`, res));
  app.get('/api/genre/:slug', (req, res) => fetchAndSend(`${API_BASE}/genre/${req.params.slug}`, res));
  app.get('/api/search/:keyword', (req, res) => fetchAndSend(`${API_BASE}/search/${req.params.keyword}`, res));
  app.get('/api/unlimited', (req, res) => fetchAndSend(`${API_BASE}/unlimited`, res));
  
  app.get('/api/ongoing-anime', (req, res) => {
    const page = req.query.page || 1;
    fetchAndSend(`${API_BASE}/ongoing-anime?page=${page}`, res);
  });
  
  app.get('/api/complete-anime', (req, res) => {
    const page = req.query.page || 1;
    fetchAndSend(`${API_BASE}/complete-anime?page=${page}`, res);
  });

  app.get('/api/batch/:slug', (req, res) => fetchAndSend(`${API_BASE}/batch/${req.params.slug}`, res));

  app.post('/api/recommendations', async (req, res) => {
    try {
      const { watchedAnime } = req.body;
      
      if (!watchedAnime || !Array.isArray(watchedAnime) || watchedAnime.length === 0) {
        return res.json({ recommendations: [] });
      }

      const prompt = `
        Berdasarkan daftar anime yang pernah ditonton atau disimpan oleh pengguna berikut:
        ${watchedAnime.join(', ')}
        
        Berikan 5 rekomendasi anime lain yang mirip atau mungkin disukai pengguna.
        Format respons harus berupa JSON array murni tanpa markdown formatting, seperti ini:
        [
          { "title": "Judul Anime", "reason": "Alasan singkat kenapa direkomendasikan dalam bahasa Indonesia" }
        ]
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const text = response.text;
      if (text) {
        const recommendations = JSON.parse(text);
        res.json({ recommendations });
      } else {
        res.json({ recommendations: [] });
      }
    } catch (error) {
      console.error('Error generating recommendations:', error);
      res.status(500).json({ error: 'Failed to generate recommendations' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, '..', 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
